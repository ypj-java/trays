﻿// TrayS.cpp : 定义应用程序的入口点。
//
#ifdef _WIN64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif

#include "framework.h"
#include "TrayS.h"
#include <commctrl.h>
#include <Commdlg.h>
#include <Shellapi.h>
#include <Oleacc.h>
#pragma comment(lib, "Oleacc.lib")

#define MAX_LOADSTRING 100
#define  WM_IAWENTRAY 8899//通知栏消息
#define  WM_TRAYS WM_USER+8888
// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
HWND hMain;
HWND hSetting;
HWND hForeground;
HICON iMain;
HANDLE hMutex;
WCHAR szShellTray[] = L"Shell_TrayWnd";
WCHAR szSecondaryTray[] = L"Shell_SecondaryTrayWnd";
WCHAR szSubKey[]= L"SOFTWARE\\TrayS";
WCHAR szAppName[] = L"TrayS";
// 此代码模块中包含的函数的前向声明:
BOOL                InitInstance(HINSTANCE, int);
INT_PTR CALLBACK    MainProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    SettingProc(HWND, UINT, WPARAM, LPARAM);
BOOL AutoRun(BOOL GetSet, BOOL bAuto);
typedef enum _WINDOWCOMPOSITIONATTRIB
{
	WCA_UNDEFINED = 0,
	WCA_NCRENDERING_ENABLED = 1,
	WCA_NCRENDERING_POLICY = 2,
	WCA_TRANSITIONS_FORCEDISABLED = 3,
	WCA_ALLOW_NCPAINT = 4,
	WCA_CAPTION_BUTTON_BOUNDS = 5,
	WCA_NONCLIENT_RTL_LAYOUT = 6,
	WCA_FORCE_ICONIC_REPRESENTATION = 7,
	WCA_EXTENDED_FRAME_BOUNDS = 8,
	WCA_HAS_ICONIC_BITMAP = 9,
	WCA_THEME_ATTRIBUTES = 10,
	WCA_NCRENDERING_EXILED = 11,
	WCA_NCADORNMENTINFO = 12,
	WCA_EXCLUDED_FROM_LIVEPREVIEW = 13,
	WCA_VIDEO_OVERLAY_ACTIVE = 14,
	WCA_FORCE_ACTIVEWINDOW_APPEARANCE = 15,
	WCA_DISALLOW_PEEK = 16,
	WCA_CLOAK = 17,
	WCA_CLOAKED = 18,
	WCA_ACCENT_POLICY = 19,
	WCA_FREEZE_REPRESENTATION = 20,
	WCA_EVER_UNCLOAKED = 21,
	WCA_VISUAL_OWNER = 22,
	WCA_LAST = 23
} WINDOWCOMPOSITIONATTRIB;

typedef struct _WINDOWCOMPOSITIONATTRIBDATA
{
	WINDOWCOMPOSITIONATTRIB Attrib;
	PVOID pvData;
	SIZE_T cbData;
} WINDOWCOMPOSITIONATTRIBDATA;

typedef enum _ACCENT_STATE
{
	ACCENT_DISABLED = 0,
	ACCENT_ENABLE_GRADIENT = 1,
	ACCENT_ENABLE_TRANSPARENTGRADIENT = 2,
	ACCENT_ENABLE_BLURBEHIND = 3,
	ACCENT_ENABLE_ACRYLICBLURBEHIND = 4,
	ACCENT_INVALID_STATE = 5,
	ACCENT_ENABLE_TRANSPARENT = 6
} ACCENT_STATE;

typedef struct _ACCENT_POLICY
{
	ACCENT_STATE AccentState;
	DWORD AccentFlags;
	DWORD GradientColor;
	DWORD AnimationId;
} ACCENT_POLICY;

ACCENT_STATE aMode = ACCENT_ENABLE_TRANSPARENTGRADIENT;
int iPos = 1;
DWORD dAlphaColor=0x01111111;
DWORD bAlpha = 255;
BOOL bTrayIcon = TRUE;
WCHAR szMode[] = L"StyleMode";
WCHAR szTrayIcon[] = L"TrayIcon";
WCHAR szPos[] = L"Pos";
WCHAR szAlphaColor[] = L"AlphaColor";
WCHAR szAlpha[] = L"Alpha";
NOTIFYICONDATA nid;//通知栏传入结构
BOOL SetWindowCompositionAttribute(HWND, ACCENT_STATE, DWORD);//设置磨砂
BOOL GetWindowCompositionAttribute(HWND, ACCENT_POLICY *);//获取磨砂
void SetTaskBarPos(HWND, HWND, HWND, HWND);
INT_PTR CALLBACK    ColorButtonProc(HWND, UINT, WPARAM, LPARAM);//颜色按钮子类化过程
WNDPROC oldColorButtonPoroc;//原来的颜色按钮控件过程
void ReadReg()
{
	HKEY pKey;
	DWORD dwDisposition;
	RegCreateKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, NULL, REG_OPTION_NON_VOLATILE, NULL, NULL, &pKey, &dwDisposition);
	if (dwDisposition == REG_CREATED_NEW_KEY)
	{

	}
	else
	{
		RegCloseKey(pKey);
		RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
		if (pKey)
		{
			DWORD dType = REG_DWORD;
			DWORD cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szMode, NULL, &dType, (BYTE*)&aMode, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szPos, NULL, &dType, (BYTE*)&iPos, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szTrayIcon, NULL, &dType, (BYTE*)&bTrayIcon, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szAlphaColor, NULL, &dType, (BYTE*)&dAlphaColor, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szAlpha, NULL, &dType, (BYTE*)&bAlpha, &cbData);
			RegCloseKey(pKey);
		}
	}
}
void WriteReg()
{
	HKEY pKey;
	RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	if (pKey)
	{
		RegSetValueEx(pKey, szMode, NULL, REG_DWORD, (BYTE*)&aMode, sizeof(aMode));
		RegSetValueEx(pKey, szPos, NULL, REG_DWORD, (BYTE*)&iPos, sizeof(iPos));
		RegSetValueEx(pKey, szTrayIcon, NULL, REG_DWORD, (BYTE*)&bTrayIcon, sizeof(bTrayIcon));
		RegSetValueEx(pKey, szAlphaColor, NULL, REG_DWORD, (BYTE*)&dAlphaColor, sizeof(dAlphaColor));
		RegSetValueEx(pKey, szAlpha, NULL, REG_DWORD, (BYTE*)&bAlpha, sizeof(bAlpha));
		RegCloseKey(pKey);
	}

}
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
	iMain = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TRAYS));
	hInst = hInstance; // 将实例句柄存储在全局变量中
	ReadReg();
	hMutex = CreateMutex(NULL, TRUE, L"_TrayS_");
	if (hMutex != NULL)
	{
		if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			hMain = FindWindow(NULL, L"_TrayS_");
			if (FindWindow(NULL, L"TrayS"))
				return 0;
			nid.cbSize = sizeof NOTIFYICONDATA;
			nid.uID = WM_IAWENTRAY;
			nid.hWnd = hMain;
			nid.hIcon = iMain;
			nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
			nid.uCallbackMessage = WM_IAWENTRAY;
			LoadString(hInst, IDS_TIPS, nid.szTip, 88);
			hSetting = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_SETTING), NULL, (DLGPROC)SettingProc);
			if (!hSetting)
			{
				return FALSE;
			}
			SendMessage(hSetting, WM_SETICON, ICON_BIG, (LPARAM)(HICON)iMain);
			SendMessage(hSetting, WM_SETICON, ICON_SMALL, (LPARAM)(HICON)iMain);
			if (aMode == ACCENT_DISABLED)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_DEFAULT);
			else if (aMode == ACCENT_ENABLE_TRANSPARENTGRADIENT)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_TRANSPARENT);
			else if (aMode == ACCENT_ENABLE_BLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_BLURBEHIND);
			else if (aMode == ACCENT_ENABLE_ACRYLICBLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_ACRYLIC);
			if (iPos == 0)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_LEFT);
			if (iPos == 1)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_CENTER);
			if (iPos == 2)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_RIGHT);
			CheckDlgButton(hSetting, IDC_CHECK_TRAYICON, bTrayIcon);
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETRANGE, 0, MAKELPARAM(0, 255));
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETPOS, TRUE, bAlpha);
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETRANGE, 0, MAKELPARAM(1, 255));
			BYTE bAlphaB = dAlphaColor >> 24;
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETPOS, TRUE, bAlphaB);
			SendDlgItemMessage(hSetting, IDC_CHECK_AUTORUN, BM_SETCHECK, AutoRun(FALSE, FALSE), NULL);
			oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
			ShowWindow(hSetting, SW_SHOW);
			UpdateWindow(hSetting);
			MSG msg;
			// 主消息循环:
			while (GetMessage(&msg, nullptr, 0, 0))
			{
				if (!IsDialogMessage(hSetting, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			DestroyWindow(hSetting);
		}
		else
		{
			// 执行应用程序初始化:
			if (!InitInstance(hInstance, nCmdShow))
			{
				return FALSE;
			}
			//////////////////////////////////////////////////////////////////////////////////设置通知栏图标
			nid.cbSize = sizeof NOTIFYICONDATA;
			nid.uID = WM_IAWENTRAY;
			nid.hWnd = hMain;
			nid.hIcon = iMain;
			nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
			nid.uCallbackMessage = WM_IAWENTRAY;
			LoadString(hInst, IDS_TIPS, nid.szTip, 88);
			if (bTrayIcon)
				::Shell_NotifyIcon(NIM_ADD, &nid);
			MSG msg;
			// 主消息循环:
			while (GetMessage(&msg, nullptr, 0, 0))
			{
				if (!IsDialogMessage(hMain, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			Shell_NotifyIcon(NIM_DELETE, &nid);
			CloseHandle(hMutex);
			DestroyWindow(hMain);
		}
	}	
	
    // 初始化全局字符串
//   LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
//   LoadStringW(hInstance, IDC_TRAYS, szWindowClass, MAX_LOADSTRING);		
	DestroyIcon(iMain);
    return (int) 0;
}


//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hMain = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainProc);
   if (!hMain)
   {
      return FALSE;
   }   
   SetTimer(hMain, 3, 33, NULL);
   if(iPos)
	   SetTimer(hMain, 6, 1000, NULL);
   SetTimer(hMain, 11, 2000, NULL);
   return TRUE;
}
BOOL Find(
	IAccessible* paccParent,
	int iRole,
	IAccessible** paccChild,
	VARIANT* pvarChild)
{

	HRESULT hr;
	long numChildren;
	unsigned long numFetched;
	VARIANT varChild;
	int indexCount;
	IAccessible* pCAcc = NULL;
	IAccessible* pChild = NULL;
	IEnumVARIANT* pEnum = NULL;
	IDispatch* pDisp = NULL;
	BOOL found = false;

	//Get the IEnumVARIANT interface
	hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

	if (pEnum)
		pEnum->Reset();

	// Get child count
	paccParent->get_accChildCount(&numChildren);

	for (indexCount = 1; indexCount <= numChildren && !found; indexCount++)
	{
		pCAcc = NULL;

		// Get next child
		if (pEnum)
			hr = pEnum->Next(1, &varChild, &numFetched);
		else
		{
			varChild.vt = VT_I4;
			varChild.lVal = indexCount;
		}

		// Get IDispatch interface for the child
		if (varChild.vt == VT_I4)
		{
			pDisp = NULL;
			hr = paccParent->get_accChild(varChild, &pDisp);
		}
		else
			pDisp = varChild.pdispVal;

		// Get IAccessible interface for the child
		if (pDisp)
		{
			hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
			hr = pDisp->Release();
		}

		// Get information about the child
		if (pCAcc)
		{
			VariantInit(&varChild);
			varChild.vt = VT_I4;
			varChild.lVal = CHILDID_SELF;

			*paccChild = pCAcc;
			pChild = pCAcc;
		}
		else
		{
			*paccChild = paccParent;
			pChild = paccParent;
		}

		// Skip invisible and unavailable objects and their children
		VARIANT varRole;
		pChild->get_accRole(varChild, &varRole);
		if (varRole.lVal==iRole)
		{
			found = true;
			*pvarChild = varChild;
			break;
		}
		if (!found && pCAcc)
		{
			// Go deeper
//			found = Find(pCAcc, iRole, paccChild, pvarChild);
//			if (*paccChild != pCAcc)
				pCAcc->Release();
		}
	}

	// Clean up
	if (pEnum)
		pEnum->Release();

	return found;
}
void SetTaskBarPos(HWND hTaskListWnd,HWND hTrayWnd,HWND hTaskWnd,HWND hReBarWnd)
{
	IAccessible *pAcc = NULL;
	AccessibleObjectFromWindow(hTaskListWnd, OBJID_WINDOW, IID_IAccessible, (void**)&pAcc);
	IAccessible *paccChlid = NULL;
	VARIANT varChild;
	if (pAcc)
	{
		if (Find(pAcc, 22, &paccChlid, &varChild) == FALSE)
		{
			pAcc->Release();
			return;
		}
		pAcc->Release();
	}
	else
		return;
	long childCount;
	long returnCount;
	LONG left, top, width, height;
	LONG ol=0,ot=0;
	int tWidth = 0;
	int tHeight = 0;
	if (paccChlid)
	{
		if (paccChlid->get_accChildCount(&childCount) == S_OK && childCount != 0)
		{
			VARIANT *pArray = new VARIANT[childCount];
			if (AccessibleChildren(paccChlid, 0L, childCount, pArray, &returnCount) == S_OK)
			{
				// Iterate through children.
				for (int x = 0; x < returnCount; x++)
				{
					VARIANT vtChild = pArray[x];
					{
						VARIANT varRole;
						paccChlid->get_accRole(vtChild, &varRole);
						if (varRole.iVal == 0x2b || varRole.iVal == 0x39)
						{
							paccChlid->accLocation(&left, &top, &width, &height, vtChild);
							if (ol != left)
							{
								tWidth += width;
								ol = left;
							}
							if (ot != top)
							{
								tHeight += height;
								ot = top;
							}
						}
					}
					// Else it's a child element so we have to call accNavigate on the parent,
					//   and we don't recurse since child elements can't have children.
				}
			}
			delete[] pArray;
		}
		paccChlid->Release();
	}
	else
		return;
	
	RECT lrc, src, rrc;
	GetWindowRect(hTaskListWnd, &lrc);
	GetWindowRect(hTrayWnd, &src);
	GetWindowRect(hTaskWnd, &rrc);
	BOOL Vertical = FALSE;
	if (src.right - src.left < src.bottom - src.top)
		Vertical = TRUE;
	SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
	int lr,tb;
	if (Vertical)
	{
		int t = rrc.left - src.left;
		int b = src.bottom - rrc.bottom;
		if (t > b)
			tb = t-b;
		else
			tb = b-t;
	}
	else
	{
		int l = rrc.left - src.left;
		int r = src.right - rrc.right;
		if (l > r)
			lr = l-r;
		else
			lr = r-l;
	}
	if (iPos == 2 || (tWidth >= rrc.right - rrc.left - lr && Vertical == FALSE) || (Vertical&&tHeight >= rrc.bottom - rrc.top - tb))
	{
		if (Vertical)
			SetWindowPos(hTaskListWnd, 0, 0, rrc.bottom - rrc.top - tHeight, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
		else
			SetWindowPos(hTaskListWnd, 0, rrc.right - rrc.left - tWidth, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	else if (iPos == 0)
	{
		SetWindowPos(hTaskListWnd, 0, 0, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
		KillTimer(hMain, 6);
		SetTimer(hMain, 11, 500, NULL);
	}
	else if (iPos == 1)
	{
		if (Vertical)
			SetWindowPos(hTaskListWnd, 0, 0, src.top+(src.bottom - src.top) / 2 - rrc.top - 2 - tHeight / 2, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
		else
			SetWindowPos(hTaskListWnd, 0, src.left+(src.right - src.left) / 2 - rrc.left - 2 - tWidth / 2, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	if (iPos != 0)
		SendMessage(hReBarWnd, WM_SETREDRAW, FALSE, 0);
	ShowWindow(hTaskWnd, SW_SHOWNOACTIVATE);
}
// “关于”框的消息处理程序。
INT_PTR CALLBACK MainProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_CLOSE:
		PostQuitMessage(0);
		break;
	case WM_TRAYS:
		ReadReg();
		if (bTrayIcon)
		{
			if (Shell_NotifyIcon(NIM_MODIFY, &nid) == FALSE)
				Shell_NotifyIcon(NIM_ADD, &nid);
		}
		else
			Shell_NotifyIcon(NIM_DELETE, &nid);
		if (iPos)
			SetTimer(hDlg,6, 1000, NULL);
		break;
	case WM_TIMER:
	{
		if (wParam == 11)
		{
			KillTimer(hDlg, wParam);
			HANDLE hProcess = GetCurrentProcess();
			SetProcessWorkingSetSize(hProcess, -1, -1);
			//			EmptyWorkingSet(hProcess);
		}
		else if (wParam == 6)
		{
			HWND hTray = FindWindow(szShellTray, NULL);
			HWND hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
			HWND hTaskWnd = FindWindowEx(hReBarWnd, NULL, L"MSTaskSwWClass", NULL);
			HWND hTaskListWnd = FindWindowEx(hTaskWnd, NULL, L"MSTaskListWClass", NULL);
			SetTaskBarPos(hTaskListWnd, hTray, hTaskWnd, hReBarWnd);
			HWND hSecondaryTray;
			hSecondaryTray = FindWindow(szSecondaryTray, NULL);
			while (hSecondaryTray)
			{
				HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
				if (hSReBarWnd)
				{
					HWND hSTaskListWnd = FindWindowEx(hSReBarWnd, NULL, L"MSTaskListWClass", NULL);
					if (hSTaskListWnd)
					{
						SetTaskBarPos(hSTaskListWnd, hSReBarWnd, hSReBarWnd, hSReBarWnd);
						
					}
				}
				hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
			}
		}
		else if (wParam == 3)
		{
			//			HWND hFocus = GetForegroundWindow();
			//			if (hFocus != hForeground)
			{
				//				hForeground = hFocus;				
				HWND hTray = FindWindow(szShellTray, NULL);
				if (hTray)
				{
					SetWindowCompositionAttribute(hTray, aMode, dAlphaColor);
					LONG_PTR exStyle = GetWindowLongPtr(hTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hTray, 0, bAlpha, LWA_ALPHA);
				}
				HWND hSecondaryTray = FindWindow(szSecondaryTray, NULL);
				while (hSecondaryTray)
				{
					SetWindowCompositionAttribute(hSecondaryTray, aMode, dAlphaColor);
					LONG_PTR exStyle = GetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hSecondaryTray, 0, bAlpha, LWA_ALPHA);
					hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
				}
			}
		}
	}
	break;
	case WM_IAWENTRAY://////////////////////////////////////////////////////////////////////////////////通知栏左右键处理
	{
		if (wParam == WM_IAWENTRAY)
		{
			if (lParam == WM_LBUTTONDOWN || lParam == WM_RBUTTONDOWN)
			{
				STARTUPINFO StartInfo;
				PROCESS_INFORMATION procStruct;
				memset(&StartInfo, 0, sizeof(STARTUPINFO));
				StartInfo.cb = sizeof(STARTUPINFO);
				WCHAR szExe[MAX_PATH];
				GetModuleFileName(NULL, szExe, MAX_PATH);
				CreateProcess(szExe,// RUN_TEST.bat位于工程所在目录下
					NULL,
					NULL,
					NULL,
					FALSE,
					NULL,// 这里不为该进程创建一个控制台窗口
					NULL,
					NULL,
					&StartInfo, &procStruct);
				CloseHandle(procStruct.hProcess);
				CloseHandle(procStruct.hThread);
			}
		}
		break;
	}
	break;
	}
	return FALSE;
}
INT_PTR CALLBACK SettingProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR)lParam)->code)
		{
		case NM_CLICK:
		case NM_RETURN:
		{
			HWND g_hLink = GetDlgItem(hDlg, IDC_SYSLINK);
			PNMLINK pNMLink = (PNMLINK)lParam;
			LITEM item = pNMLink->item;
			if ((((LPNMHDR)lParam)->hwndFrom == g_hLink) && (item.iLink == 0))
			{
				CloseHandle(ShellExecute(NULL, L"open", L"mailto:cgbsmy@live.com?subject=TrayS", NULL, NULL, SW_SHOW));
			}
			break;
		}
		}
		break;
	case WM_HSCROLL://////////////////////////////////////////////////////////////////////////////////透明度处理
	{
		HWND hSlider = GetDlgItem(hDlg, IDC_SLIDER_ALPHA);
		HWND hSliderB = GetDlgItem(hDlg, IDC_SLIDER_ALPHA_B);
		if (hSlider == (HWND)lParam)
		{
			bAlpha = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA, TBM_GETPOS, 0, 0);
//			SetLayeredWindowAttributes(hFocus, 0, bFocusAlpha, LWA_ALPHA);
		}
		else if (hSliderB == (HWND)lParam)
		{
			DWORD bAlphaB= (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
			bAlphaB = bAlphaB << 24;
			dAlphaColor = bAlphaB + (dAlphaColor & 0xffffff);
		}
		WriteReg();
		SendMessage(hMain, WM_TRAYS, NULL, NULL);
		break;
	}
    case WM_COMMAND:
		if (LOWORD(wParam) >= IDC_RADIO_DEFAULT && LOWORD(wParam) <= IDC_RADIO_ACRYLIC)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_DEFAULT))
				aMode = ACCENT_DISABLED;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_TRANSPARENT))
				aMode = ACCENT_ENABLE_TRANSPARENTGRADIENT;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_BLURBEHIND))
				aMode = ACCENT_ENABLE_BLURBEHIND;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_ACRYLIC))
				aMode = ACCENT_ENABLE_ACRYLICBLURBEHIND;
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) >= IDC_RADIO_LEFT && LOWORD(wParam) <= IDC_RADIO_RIGHT)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_LEFT))
			{
				iPos = 0;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_CENTER))
			{
				iPos = 1;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_RIGHT))
			{
				iPos = 2;
			}
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		if (LOWORD(wParam) == IDC_CHECK_TRAYICON)
		{
			bTrayIcon = IsDlgButtonChecked(hDlg, IDC_CHECK_TRAYICON);
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) == IDC_CHECK_AUTORUN)
		{
			if (IsDlgButtonChecked(hDlg, IDC_CHECK_AUTORUN))
				AutoRun(TRUE, TRUE);
			else
				AutoRun(TRUE, FALSE);
		}
		else if(LOWORD(wParam) == IDCANCEL)
        {			
			DestroyWindow(hDlg);
			PostQuitMessage(0);
            return (INT_PTR)TRUE;
        }
		else if (LOWORD(wParam) == IDC_CLOSE)
		{
			SendMessage(hMain, WM_CLOSE, NULL, NULL);
			DestroyWindow(hDlg);
			HWND hTray = FindWindow(szShellTray, NULL);
			HWND hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
			SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
			HWND hSecondaryTray;
			hSecondaryTray = FindWindow(szSecondaryTray, NULL);
			while (hSecondaryTray)
			{
				HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
				SendMessage(hSReBarWnd, WM_SETREDRAW, TRUE, 0);
				ShowWindow(hSReBarWnd, SW_SHOWNOACTIVATE);
				hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
			}
			PostQuitMessage(0);
		}
		else if (LOWORD(wParam) == IDC_BUTTON_COLOR)
		{
			COLORREF rgb = RGB(255, 255, 255);
			CHOOSECOLOR stChooseColor;
			stChooseColor.lStructSize = sizeof(CHOOSECOLOR);
			stChooseColor.hwndOwner = hDlg;
			stChooseColor.rgbResult = dAlphaColor;
			stChooseColor.lpCustColors = (LPDWORD)&dAlphaColor;
			stChooseColor.Flags = CC_RGBINIT | CC_FULLOPEN;
			stChooseColor.lCustData = 0;
			stChooseColor.lpfnHook = NULL;
			stChooseColor.lpTemplateName = NULL;
			if (ChooseColor(&stChooseColor))
			{
				dAlphaColor = stChooseColor.rgbResult;
//				if (dAlphaColor==0)
//					dAlphaColor = 0x010101;
				DWORD bAlphaB = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
				bAlphaB = bAlphaB << 24;
				dAlphaColor = bAlphaB + (dAlphaColor & 0xffffff);
				::InvalidateRect(GetDlgItem(hMain, IDC_BUTTON_COLOR), NULL, FALSE);
			}
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
        break;
    }
    return (INT_PTR)FALSE;
}
typedef BOOL(WINAPI*pfnSetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
BOOL SetWindowCompositionAttribute(HWND hWnd, ACCENT_STATE mode, DWORD AlphaColor)
{
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnSetWindowCompositionAttribute setWindowCompositionAttribute = (pfnSetWindowCompositionAttribute)GetProcAddress(hUser, "SetWindowCompositionAttribute");
		if (setWindowCompositionAttribute)
		{
			ACCENT_POLICY accent = { mode, 0, AlphaColor, 0 };
			_WINDOWCOMPOSITIONATTRIBDATA data;
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = &accent;
			data.cbData = sizeof(accent);
			ret = setWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
typedef BOOL(WINAPI*pfnGetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
/*
BOOL GetWindowCompositionAttribute(HWND hWnd, ACCENT_POLICY * accent)
{
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnGetWindowCompositionAttribute getWindowCompositionAttribute = (pfnGetWindowCompositionAttribute)GetProcAddress(hUser, "GetWindowCompositionAttribute");
		if (getWindowCompositionAttribute)
		{
			_WINDOWCOMPOSITIONATTRIBDATA data;
			ACCENT_POLICY acc[2];
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = acc;
			data.cbData = sizeof ACCENT_POLICY * 2;
			ret = getWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
*/
BOOL AutoRun(BOOL GetSet, BOOL bAuto)//读取、设置开机启动、关闭开机启动
{
	BOOL ret = FALSE;
	WCHAR sFileName[MAX_PATH];
	GetModuleFileName(NULL, sFileName, MAX_PATH);
	HKEY pKey;
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
	if (!pKey)
		RegOpenKeyEx(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
	if (pKey)
	{
		if (GetSet)
		{
			if (bAuto)
			{
				RegSetValueEx(pKey, szAppName, NULL, REG_SZ, (BYTE*)sFileName, MAX_PATH * sizeof(WCHAR));
			}
			else
			{
				RegDeleteValue(pKey, szAppName);
			}
			ret = TRUE;
		}
		else
		{
			WCHAR nFileName[MAX_PATH];
			DWORD cbData = MAX_PATH * sizeof WCHAR;
			DWORD dType = REG_SZ;
			if (RegQueryValueEx(pKey, szAppName, NULL, &dType, (LPBYTE)nFileName, &cbData) == ERROR_SUCCESS)
			{
				if (wcscmp(sFileName, nFileName) == 0)
					ret = TRUE;
				else
					ret = FALSE;
			}
		}
		RegCloseKey(pKey);
	}
	return ret;
}
INT_PTR CALLBACK ColorButtonProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)//颜色按钮控件右键处理
{
	switch (message)
	{
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		RECT rc;
		GetClientRect(hWnd, &rc);
		HBRUSH hb;
		hb = CreateSolidBrush(dAlphaColor&0xffffff);
		FillRect(hdc, &rc, hb);
		DeleteObject(hb);
		EndPaint(hWnd, &ps);
		return TRUE;
	}
	}
	return CallWindowProc(oldColorButtonPoroc, hWnd, message, wParam, lParam);
}