﻿// TrayS.cpp : 定义应用程序的入口点。
//
#ifdef _WIN64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif

#include "framework.h"
#include "TrayS.h"
#include <commctrl.h>
#include <Commdlg.h>
#include <Shellapi.h>
#include <Oleacc.h>
#pragma comment(lib, "Oleacc.lib")
#include <Iphlpapi.h>
#pragma comment(lib, "Iphlpapi.lib")
#define MAX_LOADSTRING 100
#define  WM_IAWENTRAY WM_USER+8//通知栏消息
#define  WM_TRAYS WM_USER+8888
// 全局变量:
HINSTANCE hInst;                                // 当前实例
HWND hMain;//主窗口句柄
HWND hSetting;//设置窗口句柄
HWND hTaskBar;//工具窗口句柄
//HWND hForeground;
HICON iMain;//窗口图标
HANDLE hMutex;//只能运行一个程序
WCHAR szShellTray[] = L"Shell_TrayWnd";//主任务栏类名
WCHAR szSecondaryTray[] = L"Shell_SecondaryTrayWnd";//副任务栏类名
WCHAR szSubKey[]= L"SOFTWARE\\TrayS";//程序注册表键名
WCHAR szAppName[] = L"TrayS";//程序名
WCHAR szNetCpl[] = L" cncpa.cpl";
MIB_IFTABLE *mi;
PIP_ADAPTER_INFO ipinfo;
DWORD m_last_in_bytes = 0;
DWORD m_last_out_bytes = 0;
DWORD s_in_byte=0;
DWORD s_out_byte=0;
int mWidth = 98;
int mHeight = 60;
BOOL V = FALSE;
// 此代码模块中包含的函数的前向声明:
BOOL                InitInstance(HINSTANCE, int);
INT_PTR CALLBACK    MainProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    SettingProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    TaskBarProc(HWND, UINT, WPARAM, LPARAM);
BOOL AutoRun(BOOL GetSet, BOOL bAuto);
typedef enum _WINDOWCOMPOSITIONATTRIB
{
	WCA_UNDEFINED = 0,
	WCA_NCRENDERING_ENABLED = 1,
	WCA_NCRENDERING_POLICY = 2,
	WCA_TRANSITIONS_FORCEDISABLED = 3,
	WCA_ALLOW_NCPAINT = 4,
	WCA_CAPTION_BUTTON_BOUNDS = 5,
	WCA_NONCLIENT_RTL_LAYOUT = 6,
	WCA_FORCE_ICONIC_REPRESENTATION = 7,
	WCA_EXTENDED_FRAME_BOUNDS = 8,
	WCA_HAS_ICONIC_BITMAP = 9,
	WCA_THEME_ATTRIBUTES = 10,
	WCA_NCRENDERING_EXILED = 11,
	WCA_NCADORNMENTINFO = 12,
	WCA_EXCLUDED_FROM_LIVEPREVIEW = 13,
	WCA_VIDEO_OVERLAY_ACTIVE = 14,
	WCA_FORCE_ACTIVEWINDOW_APPEARANCE = 15,
	WCA_DISALLOW_PEEK = 16,
	WCA_CLOAK = 17,
	WCA_CLOAKED = 18,
	WCA_ACCENT_POLICY = 19,
	WCA_FREEZE_REPRESENTATION = 20,
	WCA_EVER_UNCLOAKED = 21,
	WCA_VISUAL_OWNER = 22,
	WCA_LAST = 23
} WINDOWCOMPOSITIONATTRIB;

typedef struct _WINDOWCOMPOSITIONATTRIBDATA
{
	WINDOWCOMPOSITIONATTRIB Attrib;
	PVOID pvData;
	SIZE_T cbData;
} WINDOWCOMPOSITIONATTRIBDATA;

typedef enum _ACCENT_STATE
{
	ACCENT_DISABLED = 0,
	ACCENT_ENABLE_GRADIENT = 1,
	ACCENT_ENABLE_TRANSPARENTGRADIENT = 2,
	ACCENT_ENABLE_BLURBEHIND = 3,
	ACCENT_ENABLE_ACRYLICBLURBEHIND = 4,
	ACCENT_INVALID_STATE = 5,
	ACCENT_ENABLE_TRANSPARENT = 6
} ACCENT_STATE;

typedef struct _ACCENT_POLICY
{
	ACCENT_STATE AccentState;
	DWORD AccentFlags;
	DWORD GradientColor;
	DWORD AnimationId;
} ACCENT_POLICY;

ACCENT_STATE aMode = ACCENT_ENABLE_TRANSPARENTGRADIENT;
int iPos = 1;
DWORD dAlphaColor=0x01111111;
DWORD bAlpha = 255;
BOOL bTrayIcon = FALSE;
BOOL bMonitor = TRUE;
BOOL bMonitorLeft = FALSE;
WCHAR szMode[] = L"StyleMode";
WCHAR szTrayIcon[] = L"TrayIcon";
WCHAR szPos[] = L"Pos";
WCHAR szAlphaColor[] = L"AlphaColor";
WCHAR szAlpha[] = L"Alpha";
WCHAR szMonitor[] = L"Monitor";
WCHAR szMonitorLeft[] = L"MonitorLeft";
NOTIFYICONDATA nid = { 0 };//通知栏传入结构
//RTL_OSVERSIONINFOW rovi;
BOOL SetWindowCompositionAttribute(HWND, ACCENT_STATE, DWORD);//设置磨砂
BOOL GetWindowCompositionAttribute(HWND, ACCENT_POLICY *);//获取磨砂
void SetTaskBarPos(HWND, HWND, HWND, HWND, BOOL);
INT_PTR CALLBACK    ColorButtonProc(HWND, UINT, WPARAM, LPARAM);//颜色按钮子类化过程
WNDPROC oldColorButtonPoroc;//原来的颜色按钮控件过程

int iCPU;
/////////////////////////////////////////////////////////////////////////////CPU占用率
FILETIME pre_idleTime;
FILETIME pre_kernelTime;
FILETIME pre_userTime;
__int64 CompareFileTime(FILETIME time1, FILETIME time2)
{
	__int64 a = time1.dwHighDateTime;
	a = a << 32 | time1.dwLowDateTime;
	__int64 b = time2.dwHighDateTime;
	b = b << 32 | time2.dwLowDateTime;
	return (b - a);
}
int GetCPUUseRate()
{
	{
		int nCPUUseRate = -1;
		FILETIME idleTime;//空闲时间 
		FILETIME kernelTime;//核心态时间 
		FILETIME userTime;//用户态时间 
		GetSystemTimes(&idleTime, &kernelTime, &userTime);

		__int64 idle = CompareFileTime(pre_idleTime, idleTime);
		__int64 kernel = CompareFileTime(pre_kernelTime, kernelTime);
		__int64 user = CompareFileTime(pre_userTime, userTime);
		nCPUUseRate = (int)((kernel + user - idle) * 100 / (kernel + user));
		pre_idleTime = idleTime;
		pre_kernelTime = kernelTime;
		pre_userTime = userTime;
		if (nCPUUseRate < 1)
			nCPUUseRate = iCPU;
		else if (nCPUUseRate > 100)
			nCPUUseRate = 100;
		return nCPUUseRate;
	}
}
void ReadReg()//读取设置
{
	HKEY pKey;
	DWORD dwDisposition;
	RegCreateKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, NULL, REG_OPTION_NON_VOLATILE, NULL, NULL, &pKey, &dwDisposition);
	if (dwDisposition == REG_CREATED_NEW_KEY)
	{

	}
	else
	{
		RegCloseKey(pKey);
		RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
		if (pKey)
		{
			DWORD dType = REG_DWORD;
			DWORD cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szMode, NULL, &dType, (BYTE*)&aMode, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szPos, NULL, &dType, (BYTE*)&iPos, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szTrayIcon, NULL, &dType, (BYTE*)&bTrayIcon, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szAlphaColor, NULL, &dType, (BYTE*)&dAlphaColor, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szAlpha, NULL, &dType, (BYTE*)&bAlpha, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szMonitor, NULL, &dType, (BYTE*)&bMonitor, &cbData);
			dType = REG_DWORD;
			cbData = sizeof(DWORD);
			RegQueryValueEx(pKey, szMonitorLeft, NULL, &dType, (BYTE*)&bMonitorLeft, &cbData);
			RegCloseKey(pKey);
		}
	}
}
void WriteReg()//写入设置
{
	HKEY pKey;
	RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	if (pKey)
	{
		RegSetValueEx(pKey, szMode, NULL, REG_DWORD, (BYTE*)&aMode, sizeof(aMode));
		RegSetValueEx(pKey, szPos, NULL, REG_DWORD, (BYTE*)&iPos, sizeof(iPos));
		RegSetValueEx(pKey, szTrayIcon, NULL, REG_DWORD, (BYTE*)&bTrayIcon, sizeof(bTrayIcon));
		RegSetValueEx(pKey, szAlphaColor, NULL, REG_DWORD, (BYTE*)&dAlphaColor, sizeof(dAlphaColor));
		RegSetValueEx(pKey, szAlpha, NULL, REG_DWORD, (BYTE*)&bAlpha, sizeof(bAlpha));
		RegSetValueEx(pKey, szMonitor, NULL, REG_DWORD, (BYTE*)&bMonitor, sizeof(bMonitor));
		RegSetValueEx(pKey, szMonitorLeft, NULL, REG_DWORD, (BYTE*)&bMonitorLeft, sizeof(bMonitorLeft));
		RegCloseKey(pKey);
	}

}
void RunProcess(LPWSTR sz)
{
	
	STARTUPINFO StartInfo;
	PROCESS_INFORMATION procStruct;
	memset(&StartInfo, 0, sizeof(STARTUPINFO));
	StartInfo.cb = sizeof(STARTUPINFO);
	WCHAR szExe[MAX_PATH];
	WCHAR szCommandLine[MAX_PATH];
	szCommandLine[0] = L'\0';
	if (sz)
		wcscpy_s(szCommandLine, MAX_PATH, sz);
	GetModuleFileName(NULL, szExe, MAX_PATH);
	CreateProcess(szExe,// RUN_TEST.bat位于工程所在目录下
		szCommandLine,
		NULL,
		NULL,
		FALSE,
		NULL,// 这里不为该进程创建一个控制台窗口
		NULL,
		NULL,
		&StartInfo, &procStruct);
	CloseHandle(procStruct.hProcess);
	CloseHandle(procStruct.hThread);
}
HWND hTaskWnd;
HWND hReBarWnd;
void OpenTaskBar()
{
	if (IsWindow(hTaskBar) == FALSE)
	{
		hTaskBar = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_TASKBAR), NULL, (DLGPROC)TaskBarProc);
		if (hTaskBar)
		{
			HWND hTray = FindWindow(szShellTray, NULL);
			hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
			hTaskWnd = FindWindowEx(hReBarWnd, NULL, L"MSTaskSwWClass", NULL);
			SetParent(hTaskBar, hReBarWnd);
/*
			if (rovi.dwMajorVersion < 10)
			{
				SetWindowLongPtr(hTaskBar, GWL_EXSTYLE, GetWindowLongPtr(hTaskBar, GWL_EXSTYLE) | WS_EX_LAYERED);
				SetLayeredWindowAttributes(hTaskBar, RGB(128, 128, 129), 0, LWA_COLORKEY);
			}
*/
			ShowWindow(hTaskBar, SW_SHOW);
			SetTimer(hTaskBar, 3, 1000, NULL);
//			SetTimer(hTaskBar, 6, 100, NULL);
		}
	}
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
	
	if (lpCmdLine[0] == L'c')
	{
		CloseHandle(ShellExecute(NULL, L"open",L"control.exe", &lpCmdLine[1], NULL, SW_SHOW));
		return 0;
	}

	iMain = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TRAYS));
	hInst = hInstance; // 将实例句柄存储在全局变量中
	ReadReg();
/*
	typedef WINUSERAPI DWORD WINAPI RTLGETVERSION(PRTL_OSVERSIONINFOW  lpVersionInformation);
	rovi.dwOSVersionInfoSize = sizeof(rovi);
	RTLGETVERSION *RtlGetVersion = (RTLGETVERSION*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
	if (RtlGetVersion)
		RtlGetVersion(&rovi);
*/
	hMutex = CreateMutex(NULL, TRUE, L"_TrayS_");
	if (hMutex != NULL)
	{
		if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			CloseHandle(hMutex);
			hMain = FindWindow(NULL, L"_TrayS_");
			if (FindWindow(NULL, L"TrayS"))
				return 0;
			hSetting = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_SETTING), NULL, (DLGPROC)SettingProc);
			if (!hSetting)
			{
				return FALSE;
			}
			SendMessage(hSetting, WM_SETICON, ICON_BIG, (LPARAM)(HICON)iMain);
			SendMessage(hSetting, WM_SETICON, ICON_SMALL, (LPARAM)(HICON)iMain);
			if (aMode == ACCENT_DISABLED)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_DEFAULT);
			else if (aMode == ACCENT_ENABLE_TRANSPARENTGRADIENT)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_TRANSPARENT);
			else if (aMode == ACCENT_ENABLE_BLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_BLURBEHIND);
			else if (aMode == ACCENT_ENABLE_ACRYLICBLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_ACRYLIC);
			if (iPos == 0)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_LEFT);
			if (iPos == 1)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_CENTER);
			if (iPos == 2)
				CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_RIGHT);
			CheckDlgButton(hSetting, IDC_CHECK_TRAYICON, bTrayIcon);
			CheckDlgButton(hSetting, IDC_CHECK_MONITOR, bMonitor);
			CheckDlgButton(hSetting, IDC_CHECK_MONITOR_LEFT, bMonitorLeft);
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETRANGE, 0, MAKELPARAM(0, 255));
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETPOS, TRUE, bAlpha);
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETRANGE, 0, MAKELPARAM(1, 255));
			BYTE bAlphaB = dAlphaColor >> 24;
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETPOS, TRUE, bAlphaB);
			SendDlgItemMessage(hSetting, IDC_CHECK_AUTORUN, BM_SETCHECK, AutoRun(FALSE, FALSE), NULL);
			oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
			ShowWindow(hSetting, SW_SHOW);
			UpdateWindow(hSetting);
			MSG msg;
			// 主消息循环:
			while (GetMessage(&msg, nullptr, 0, 0))
			{
				if (!IsDialogMessage(hSetting, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			
			DestroyWindow(hSetting);
		}
		else
		{
			// 执行应用程序初始化:
			if (!InitInstance(hInstance, nCmdShow))
			{
				return FALSE;
			}
			//////////////////////////////////////////////////////////////////////////////////设置通知栏图标
			nid.cbSize = sizeof NOTIFYICONDATA;
			nid.uID = WM_IAWENTRAY;
			nid.hWnd = hMain;
			nid.hIcon = iMain;
			nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
			nid.uCallbackMessage = WM_IAWENTRAY;
//			nid.dwInfoFlags = NIIF_INFO;
			LoadString(hInst, IDS_TIPS, nid.szTip, 88);
			if (bTrayIcon)
				::Shell_NotifyIcon(NIM_ADD, &nid);
			if (bMonitor)
				OpenTaskBar();
			MSG msg;
			// 主消息循环:
			while (GetMessage(&msg, nullptr, 0, 0))
			{
				if (!IsDialogMessage(hMain, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			DestroyWindow(hTaskBar);
			DestroyWindow(hMain);
			Shell_NotifyIcon(NIM_DELETE, &nid);
			free(mi);
			free(ipinfo);
			CloseHandle(hMutex);
			
		}
	}	
	
    // 初始化全局字符串
//   LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
//   LoadStringW(hInstance, IDC_TRAYS, szWindowClass, MAX_LOADSTRING);		
	DestroyIcon(iMain);
    return (int) 0;
}
//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hMain = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainProc);
   if (!hMain)
   {
      return FALSE;
   }   
   SetTimer(hMain, 3, 33, NULL);
   if(iPos||bMonitor)
	   SetTimer(hMain, 6, 1000, NULL);
   SetTimer(hMain, 11, 2000, NULL);
//   ShowWindow(hMain,SW_SHOW);
   return TRUE;
}
BOOL Find(IAccessible* paccParent,int iRole,IAccessible** paccChild)
{
	HRESULT hr;
	long numChildren;
	unsigned long numFetched;
	VARIANT varChild;
	int indexCount;
	IAccessible* pChild = NULL;
	IEnumVARIANT* pEnum = NULL;
	IDispatch* pDisp = NULL;
	BOOL found = false;
	//Get the IEnumVARIANT interface
	hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);
	if (pEnum)
		pEnum->Reset();
	// Get child count
	paccParent->get_accChildCount(&numChildren);
	for (indexCount = 1; indexCount <= numChildren && !found; indexCount++)
	{
		pChild = NULL;
		if (pEnum)
			hr = pEnum->Next(1, &varChild, &numFetched);
		else
		{
			varChild.vt = VT_I4;
			varChild.lVal = indexCount;
		}
		if (varChild.vt == VT_I4)
		{
			pDisp = NULL;
			hr = paccParent->get_accChild(varChild, &pDisp);
		}
		else
			pDisp = varChild.pdispVal;
		if (pDisp)
		{
			hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pChild);
			hr = pDisp->Release();
		}
		if (pChild)
		{
			VariantInit(&varChild);
			varChild.vt = VT_I4;
			varChild.lVal = CHILDID_SELF;
			*paccChild = pChild;
		}
		VARIANT varState;
		pChild->get_accState(varChild, &varState);
		if ((varState.intVal&STATE_SYSTEM_INVISIBLE) == 0)
		{
			VARIANT varRole;
			pChild->get_accRole(varChild, &varRole);
			if (varRole.lVal == iRole)
			{
				paccParent->Release();
				found = true;
				break;
			}
		}
		if (!found && pChild)
		{
//			found = Find(pCAcc, iRole, paccChild);
//			if (*paccChild != pCAcc)
			pChild->Release();
		}
	}
	if (pEnum)
		pEnum->Release();
	return found;
}
int oleft=0, otop=0;
void SetTaskBarPos(HWND hTaskListWnd,HWND hTrayWnd,HWND hTaskWnd,HWND hReBarWnd,BOOL bMainTray)
{
	IAccessible *pAcc = NULL;
	AccessibleObjectFromWindow(hTaskListWnd, OBJID_WINDOW, IID_IAccessible, (void**)&pAcc);
	IAccessible *paccChlid = NULL;
	if (pAcc)
	{
		if (Find(pAcc, 22, &paccChlid) == FALSE)
		{
			return;
		}
	}
	else
		return;
	long childCount;
	long returnCount;
	LONG left, top, width, height;
	LONG ol=0,ot=0;
	int tWidth = 0;
	int tHeight = 0;
	if (paccChlid)
	{
		if (paccChlid->get_accChildCount(&childCount) == S_OK && childCount != 0)
		{
			VARIANT *pArray = new VARIANT[childCount];
			if (AccessibleChildren(paccChlid, 0L, childCount, pArray, &returnCount) == S_OK)
			{
				for (int x = 0; x < returnCount; x++)
				{
					VARIANT vtChild = pArray[x];
					{
						
						VARIANT varState;						
						paccChlid->get_accState(vtChild, &varState);
						if ((varState.intVal&STATE_SYSTEM_INVISIBLE) == 0)
						{
							VARIANT varRole;
							paccChlid->get_accRole(vtChild, &varRole);
							if (varRole.intVal == 0x2b || varRole.intVal == 0x39)
							{
								paccChlid->accLocation(&left, &top, &width, &height, vtChild);
								if (ol != left)
								{
									tWidth += width;
									ol = left;
								}
								if (ot != top)
								{
									tHeight += height;
									ot = top;
								}
							}
						}
					}
				}
			}
			delete[] pArray;
		}
		paccChlid->Release();
	}
	else
		return;
	
	RECT lrc, src, trc;
	GetWindowRect(hTaskListWnd, &lrc);
	GetWindowRect(hTrayWnd, &src);
	GetWindowRect(hTaskWnd, &trc);
	BOOL Vertical = FALSE;
	if (src.right - src.left < src.bottom - src.top)
		Vertical = TRUE;
	SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
	int lr,tb;
	if (Vertical)
	{
		int t = trc.left - src.left;
		int b = src.bottom - trc.bottom;
		if (bMainTray&&bMonitor)
		{
			if (bMonitorLeft == FALSE)
				b += mHeight;
			else
				t += mHeight;
		}
		if (t > b)
			tb = t-b;
		else
			tb = b-t;		
	}
	else
	{
		int l = trc.left - src.left;
		int r = src.right - trc.right;
		if (bMonitor&&bMainTray)
		{
			if (bMonitorLeft == FALSE)
				r += mWidth;
			else
				l += mWidth;
		}
		if (l > r)
			lr = l-r;
		else
			lr = r-l;
	}
	int nleft,ntop;
	if ((iPos == 2 || (tWidth >= trc.right - trc.left - lr && Vertical == FALSE) || (Vertical&&tHeight >= trc.bottom - trc.top - tb))&&iPos!=0)
	{
		if (Vertical)
		{
			ntop = trc.bottom - trc.top - tHeight;
			if (bMonitorLeft == FALSE&&bMonitor&&bMainTray)
				ntop -= mHeight+2;
		}
		else
		{
			nleft = trc.right - trc.left - tWidth;
			if (bMonitorLeft == FALSE&&bMonitor&&bMainTray)
				nleft -= mWidth+2;
		}		
	}
	else if (iPos == 0)
	{
		if (bMonitorLeft&&bMonitor&&bMainTray)
		{
			nleft = mWidth;
			ntop = mHeight;
		}
		else
		{
			nleft = 0;
			ntop = 0;
			if (bMonitor==FALSE)
			{
				KillTimer(hMain, 6);
				SetTimer(hMain, 11, 500, NULL);
			}
		}
	}
	else if (iPos == 1)
	{
		if (Vertical)
			ntop = src.top + (src.bottom - src.top) / 2 - trc.top  - tHeight / 2;
		else
			nleft= src.left + (src.right - src.left) / 2 - trc.left  - tWidth / 2;
	}
	if (Vertical)
	{
		lrc.top = otop;
		otop = ntop;
		while (ntop!=lrc.top)
		{
			if (ntop > lrc.top)
				++lrc.top;
			else
				--lrc.top;
			SetWindowPos(hTaskListWnd, 0, 0, lrc.top, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
		}
		SetWindowPos(hTaskListWnd, 0, 0, lrc.top, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	else
	{
		lrc.left = oleft;
		oleft= nleft;
		while (nleft != lrc.left)
		{
			if (nleft > lrc.left)
				++lrc.left;
			else
				--lrc.left;
			SetWindowPos(hTaskListWnd, 0, lrc.left, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
		}
		SetWindowPos(hTaskListWnd, 0, lrc.left, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	if (iPos != 0)
		SendMessage(hReBarWnd, WM_SETREDRAW, FALSE, 0);
	ShowWindow(hTaskWnd, SW_SHOWNOACTIVATE);
}
void AdjustWindowPos()
{
	if (IsWindow(hTaskBar) == FALSE)
		OpenTaskBar();
	RECT rrc,trc;
	GetWindowRect(hReBarWnd, &rrc);
	GetWindowRect(hTaskWnd, &trc);
	if (rrc.right - rrc.left > rrc.bottom - rrc.top)
		V = FALSE;
	else
		V = TRUE;
	if(V==FALSE)
	{
		if (bMonitorLeft)
		{
			MoveWindow(hTaskBar, trc.left-rrc.left, 2, mWidth, trc.bottom - trc.top-4, FALSE);
			//		MoveWindow(hTaskWnd, mWidth + 2,0, rrc.right - rrc.left - mWidth, rrc.bottom - rrc.top, FALSE);
		}
		else
		{
			MoveWindow(hTaskBar, trc.right - trc.left - mWidth+(trc.left-rrc.left), 2, mWidth, trc.bottom - trc.top-4, FALSE);
			//		MoveWindow(hTaskWnd, 0, 0, rrc.right - rrc.left - mWidth, rrc.bottom - rrc.top, FALSE);
		}
	}
	else
	{
		if (bMonitorLeft)
		{
			MoveWindow(hTaskBar, 2, trc.top-rrc.top, trc.right-trc.left-4, mHeight, FALSE);
			//		MoveWindow(hTaskWnd, mWidth + 2,0, rrc.right - rrc.left - mWidth, rrc.bottom - rrc.top, FALSE);
		}
		else
		{
			MoveWindow(hTaskBar, 2,trc.bottom-trc.top-mHeight+(trc.top-rrc.top),trc.right-trc.left-4,mHeight, FALSE);
			//		MoveWindow(hTaskWnd, 0, 0, rrc.right - rrc.left - mWidth, rrc.bottom - rrc.top, FALSE);
		}
	}
}
INT_PTR CALLBACK TaskBarProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case  WM_RBUTTONDOWN:
		RunProcess(szNetCpl);
		break;
	case WM_LBUTTONDOWN:
	{
		RunProcess(NULL);
	}
		break;
	case WM_TIMER:
		if (wParam == 3)
		{
			iCPU = GetCPUUseRate();
			DWORD dwIPSize = 0;
			if (GetAdaptersInfo(ipinfo, &dwIPSize) == ERROR_BUFFER_OVERFLOW)
			{
				free(ipinfo);
				ipinfo = (PIP_ADAPTER_INFO)malloc(dwIPSize);
				GetAdaptersInfo(ipinfo, &dwIPSize);
			}
			DWORD dwMISize = 0;
			if (GetIfTable(mi, &dwMISize, FALSE) == ERROR_INSUFFICIENT_BUFFER)
			{
				free(mi);
				mi = (MIB_IFTABLE*)malloc(dwMISize);
				GetIfTable(mi, &dwMISize, FALSE);
			}
			DWORD m_in_bytes = 0;
			DWORD m_out_bytes = 0;
			for (DWORD i = 0; i < mi->dwNumEntries; i++)
			{
				if (mi->table[i].dwOperStatus == MIB_IF_OPER_STATUS_OPERATIONAL&&mi->table[i].dwType== MIB_IF_TYPE_ETHERNET)
				{
					for (size_t l = 0; l < dwIPSize / sizeof IP_ADAPTER_INFO; l++)
					{
						if(ipinfo[l].Index==mi->table[i].dwIndex)
						{
							m_in_bytes += mi->table[i].dwInOctets;
							m_out_bytes += mi->table[i].dwOutOctets;
						}
					}
				}
			}
			if (m_last_in_bytes != 0)
			{
				s_in_byte = m_in_bytes - m_last_in_bytes;
				s_out_byte = m_out_bytes - m_last_out_bytes;
			}
			m_last_out_bytes = m_out_bytes;
			m_last_in_bytes = m_in_bytes;			
		}
		else if (wParam == 6)
		{
		}
		break;
	case WM_ERASEBKGND:
	{
		//		PAINTSTRUCT ps;
		HDC hdc = (HDC)wParam;//BeginPaint(hDlg, &ps);
		RECT rc;
		GetClientRect(hDlg, &rc);
		HDC mdc = CreateCompatibleDC(hdc);
		HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, rc.right - rc.left, rc.bottom - rc.top);
		HBITMAP oldBmp = (HBITMAP)SelectObject(mdc, hMemBmp);
/*
		if (rovi.dwMajorVersion < 10)
		{
			HBRUSH hb;
			hb = CreateSolidBrush(RGB(128, 128, 129));
			FillRect(mdc, &rc, hb);
			DeleteObject(hb);
		}
*/
		if (V)
		{
			int s = (rc.right - rc.left - 52) / 2;
			rc.left += s;
			rc.right -= s;
		}
		else
		{
			InflateRect(&rc, -1, 0);
		}
		LOGFONT fontRect;
		memset(&fontRect, 0, sizeof(LOGFONT));
		fontRect.lfHeight = -12; //字体的高度
		fontRect.lfWeight = FW_NORMAL;//字体的粗细
		lstrcpy(fontRect.lfFaceName, L"微软雅黑");
		HFONT hFont = CreateFontIndirect(&fontRect); //创建字体
		HFONT oldFont = (HFONT)SelectObject(mdc, hFont);
		WCHAR sz[16];
		SetBkMode(mdc, TRANSPARENT);
		COLORREF rgb;
		if (s_out_byte < 10485760)
			rgb = RGB(128, 128, 128);
		else if (s_out_byte < 66666666)
			rgb = RGB(192, 192, 192);
		else
			rgb = RGB(255, 255, 255);
		SetTextColor(mdc, rgb);
		if (s_out_byte < 1024)
			swprintf_s(sz, 16, L"↑:%dB", s_out_byte);
		else if (s_out_byte < 1048576)
			swprintf_s(sz, 16, L"↑:%dK", s_out_byte / 1024);
		else
			swprintf_s(sz, 16, L"↑:%dM", s_out_byte / 1024 / 1024);
		size_t sLen = wcslen(sz);
		if (V)
		{
			rc.bottom /= 4;
			DrawText(mdc, sz, (int)sLen, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
		else
		{
			rc.bottom /= 2;
			DrawText(mdc, sz, (int)sLen, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}		
		if (iCPU <= 33)
			rgb = RGB(0, 168, 0);
		else if (iCPU <= 66)
			rgb = RGB(168, 168, 0);
		else
			rgb = RGB(168, 0, 0);
		SetTextColor(mdc, rgb);
		swprintf_s(sz, 16, L"CPU:%.2d%%", iCPU);
		sLen = wcslen(sz);
		if (V)
		{
			OffsetRect(&rc, 0, (rc.bottom - rc.top) * 2);
			DrawText(mdc, sz, (int)sLen, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
		else
			DrawText(mdc, sz, (int)sLen, &rc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);

		if (s_in_byte < 10485760)
			rgb = RGB(128, 128, 128);
		else if (s_in_byte < 66666666)
			rgb = RGB(192, 192, 192);
		else
			rgb = RGB(255, 255, 255);
		SetTextColor(mdc, rgb);
		if (s_in_byte < 1024)
			swprintf_s(sz, 16, L"↓:%dB", s_in_byte);
		else if (s_in_byte < 1048576)
			swprintf_s(sz, 16, L"↓:%dK", s_in_byte / 1024);
		else
			swprintf_s(sz, 16, L"↓:%dM", s_in_byte / 1024 / 1024);
		sLen = wcslen(sz);
		if (V)
			OffsetRect(&rc, 0, -(rc.bottom - rc.top));
		else
		{
			rc.top = rc.bottom;
			rc.bottom *= 2;
		}
		DrawText(mdc, sz, (int)sLen, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

		MEMORYSTATUS MemoryStatus;
		MemoryStatus.dwLength = sizeof MEMORYSTATUS;
		GlobalMemoryStatus(&MemoryStatus);
		swprintf_s(sz, 16, L"内存:%.2d%%", MemoryStatus.dwMemoryLoad);
		sLen = wcslen(sz);
		if (MemoryStatus.dwMemoryLoad <= 33)
			rgb = RGB(0, 168, 0);
		else if (MemoryStatus.dwMemoryLoad <= 66)
			rgb = RGB(168, 168, 0);
		else
			rgb = RGB(168, 0, 0);
		SetTextColor(mdc, rgb);
		if (V)
		{
			OffsetRect(&rc, 0, (rc.bottom - rc.top) * 2);
			DrawText(mdc, sz, (int)sLen, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
		else
			DrawText(mdc, sz, (int)sLen, &rc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
		rc.top = 0;
		SelectObject(mdc, oldFont);
		DeleteObject(hFont);
		GetClientRect(hDlg, &rc);
		BitBlt(hdc, 0, 0, rc.right - rc.left, rc.bottom - rc.top, mdc, 0, 0, SRCCOPY);
		SelectObject(mdc, oldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(mdc);
		//		EndPaint(hDlg, &ps);
		return TRUE;
	}
	break;
	}
	return FALSE;
}
// “关于”框的消息处理程序。
INT_PTR CALLBACK MainProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_CLOSE:
	{
		KillTimer(hDlg, 6);
		KillTimer(hDlg, 3);
		HWND hTray = FindWindow(szShellTray, NULL);
		HWND hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
		SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
		HWND hSecondaryTray;
		hSecondaryTray = FindWindow(szSecondaryTray, NULL);
		while (hSecondaryTray)
		{
			HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
			SendMessage(hSReBarWnd, WM_SETREDRAW, TRUE, 0);
			ShowWindow(hSReBarWnd, SW_SHOWNOACTIVATE);
			hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
		}
		PostQuitMessage(0);
	}
		break;
	case WM_TRAYS:
	{
		BOOL bIcon = bTrayIcon;
		ReadReg();
		if (iPos || bMonitor)
			SetTimer(hDlg, 6, 1000, NULL);
		if (bIcon != bTrayIcon)
		{
			DestroyWindow(hTaskBar);
			if (bTrayIcon)
				Shell_NotifyIcon(NIM_ADD, &nid);
			else
				Shell_NotifyIcon(NIM_DELETE, &nid);
		}
		if (bMonitor)
			OpenTaskBar();
		else
			DestroyWindow(hTaskBar);
	}
		break;
	case WM_TIMER:
	{
		if (wParam == 11)
		{
			KillTimer(hDlg, wParam);
			HANDLE hProcess = GetCurrentProcess();
			SetProcessWorkingSetSize(hProcess, -1, -1);
			//			EmptyWorkingSet(hProcess);
		}
		else if (wParam == 6)
		{
			HWND hTray = FindWindow(szShellTray, NULL);
			HWND hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
			HWND hTaskWnd = FindWindowEx(hReBarWnd, NULL, L"MSTaskSwWClass", NULL);
			HWND hTaskListWnd = FindWindowEx(hTaskWnd, NULL, L"MSTaskListWClass", NULL);
			if (bMonitor)
			{
				AdjustWindowPos();
				::InvalidateRect(hTaskBar, NULL, TRUE);
			}
			SetTaskBarPos(hTaskListWnd, hTray, hTaskWnd, hReBarWnd,TRUE);
			HWND hSecondaryTray;
			hSecondaryTray = FindWindow(szSecondaryTray, NULL);
			while (hSecondaryTray)
			{
				HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
				if (hSReBarWnd)
				{
					HWND hSTaskListWnd = FindWindowEx(hSReBarWnd, NULL, L"MSTaskListWClass", NULL);
					if (hSTaskListWnd)
					{
						SetTaskBarPos(hSTaskListWnd, hSecondaryTray, hSReBarWnd, hSReBarWnd,FALSE);
						
					}
				}
				hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
			}
		}
		else if (wParam == 3)
		{
			//			HWND hFocus = GetForegroundWindow();
			//			if (hFocus != hForeground)
			{
				//				hForeground = hFocus;				
				HWND hTray = FindWindow(szShellTray, NULL);
				if (hTray)
				{
					SetWindowCompositionAttribute(hTray, aMode, dAlphaColor);
					LONG_PTR exStyle = GetWindowLongPtr(hTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hTray, 0, bAlpha, LWA_ALPHA);
				}
				HWND hSecondaryTray = FindWindow(szSecondaryTray, NULL);
				while (hSecondaryTray)
				{
					SetWindowCompositionAttribute(hSecondaryTray, aMode, dAlphaColor);
					LONG_PTR exStyle = GetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hSecondaryTray, 0, bAlpha, LWA_ALPHA);
					hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
				}
			}
		}
	}
	break;
	case WM_IAWENTRAY://////////////////////////////////////////////////////////////////////////////////通知栏左右键处理
	{
		if (wParam == WM_IAWENTRAY)
		{
			if (lParam == WM_LBUTTONDOWN || lParam == WM_RBUTTONDOWN)
			{
				RunProcess(NULL);
			}
		}
		break;
	}
	break;
	}
	return FALSE;
}
INT_PTR CALLBACK SettingProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR)lParam)->code)
		{
		case NM_CLICK:
		case NM_RETURN:
		{
			HWND g_hLink = GetDlgItem(hDlg, IDC_SYSLINK);
			PNMLINK pNMLink = (PNMLINK)lParam;
			LITEM item = pNMLink->item;
			if ((((LPNMHDR)lParam)->hwndFrom == g_hLink) && (item.iLink == 0))
			{
				CloseHandle(ShellExecute(NULL, L"open", L"https://gitee.com/cgbsmy/TrayS", NULL, NULL, SW_SHOW));
				//mailto:cgbsmy@live.com?subject=TrayS
			}
			else
			{
				CloseHandle(ShellExecute(NULL, L"open", L"https://www.52pojie.cn/thread-1182669-1-1.html", NULL, NULL, SW_SHOW));
			}
			break;
		}
		}
		break;
	case WM_HSCROLL://////////////////////////////////////////////////////////////////////////////////透明度处理
	{
		HWND hSlider = GetDlgItem(hDlg, IDC_SLIDER_ALPHA);
		HWND hSliderB = GetDlgItem(hDlg, IDC_SLIDER_ALPHA_B);
		if (hSlider == (HWND)lParam)
		{
			bAlpha = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA, TBM_GETPOS, 0, 0);
//			SetLayeredWindowAttributes(hFocus, 0, bFocusAlpha, LWA_ALPHA);
		}
		else if (hSliderB == (HWND)lParam)
		{
			DWORD bAlphaB= (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
			bAlphaB = bAlphaB << 24;
			dAlphaColor = bAlphaB + (dAlphaColor & 0xffffff);
		}
		WriteReg();
		SendMessage(hMain, WM_TRAYS, NULL, NULL);
		break;
	}
    case WM_COMMAND:
		if (LOWORD(wParam) >= IDC_RADIO_DEFAULT && LOWORD(wParam) <= IDC_RADIO_ACRYLIC)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_DEFAULT))
				aMode = ACCENT_DISABLED;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_TRANSPARENT))
				aMode = ACCENT_ENABLE_TRANSPARENTGRADIENT;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_BLURBEHIND))
				aMode = ACCENT_ENABLE_BLURBEHIND;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_ACRYLIC))
				aMode = ACCENT_ENABLE_ACRYLICBLURBEHIND;
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) >= IDC_RADIO_LEFT && LOWORD(wParam) <= IDC_RADIO_RIGHT)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_LEFT))
			{
				iPos = 0;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_CENTER))
			{
				iPos = 1;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_RIGHT))
			{
				iPos = 2;
			}
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		if (LOWORD(wParam) == IDC_CHECK_TRAYICON)
		{
			bTrayIcon = IsDlgButtonChecked(hDlg, IDC_CHECK_TRAYICON);
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR)
		{
			bMonitor = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR);
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR_LEFT)
		{
			bMonitorLeft = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR_LEFT);
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
		else if (LOWORD(wParam) == IDC_CHECK_AUTORUN)
		{
			if (IsDlgButtonChecked(hDlg, IDC_CHECK_AUTORUN))
				AutoRun(TRUE, TRUE);
			else
				AutoRun(TRUE, FALSE);
		}
		else if(LOWORD(wParam) == IDCANCEL)
        {
			SendMessage(hMain, WM_TIMER, 11, 0);
			DestroyWindow(hDlg);
			PostQuitMessage(0);
            return (INT_PTR)TRUE;
        }
		else if (LOWORD(wParam) == IDC_CLOSE)
		{
			SendMessage(hMain, WM_CLOSE, NULL, NULL);
			DestroyWindow(hDlg);
			PostQuitMessage(0);
		}
		else if (LOWORD(wParam) == IDC_BUTTON_COLOR)
		{
			COLORREF rgb = RGB(255, 255, 255);
			CHOOSECOLOR stChooseColor;
			stChooseColor.lStructSize = sizeof(CHOOSECOLOR);
			stChooseColor.hwndOwner = hDlg;
			stChooseColor.rgbResult = dAlphaColor;
			stChooseColor.lpCustColors = (LPDWORD)&dAlphaColor;
			stChooseColor.Flags = CC_RGBINIT | CC_FULLOPEN;
			stChooseColor.lCustData = 0;
			stChooseColor.lpfnHook = NULL;
			stChooseColor.lpTemplateName = NULL;
			if (ChooseColor(&stChooseColor))
			{
				dAlphaColor = stChooseColor.rgbResult;
//				if (dAlphaColor==0)
//					dAlphaColor = 0x010101;
				DWORD bAlphaB = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
				bAlphaB = bAlphaB << 24;
				dAlphaColor = bAlphaB + (dAlphaColor & 0xffffff);
				::InvalidateRect(GetDlgItem(hMain, IDC_BUTTON_COLOR), NULL, FALSE);
			}
			WriteReg();
			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
        break;
    }
    return (INT_PTR)FALSE;
}
typedef BOOL(WINAPI*pfnSetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
BOOL SetWindowCompositionAttribute(HWND hWnd, ACCENT_STATE mode, DWORD AlphaColor)
{
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnSetWindowCompositionAttribute setWindowCompositionAttribute = (pfnSetWindowCompositionAttribute)GetProcAddress(hUser, "SetWindowCompositionAttribute");
		if (setWindowCompositionAttribute)
		{
			ACCENT_POLICY accent = { mode, 0, AlphaColor, 0 };
			_WINDOWCOMPOSITIONATTRIBDATA data;
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = &accent;
			data.cbData = sizeof(accent);
			ret = setWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
typedef BOOL(WINAPI*pfnGetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
/*
BOOL GetWindowCompositionAttribute(HWND hWnd, ACCENT_POLICY * accent)
{
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnGetWindowCompositionAttribute getWindowCompositionAttribute = (pfnGetWindowCompositionAttribute)GetProcAddress(hUser, "GetWindowCompositionAttribute");
		if (getWindowCompositionAttribute)
		{
			_WINDOWCOMPOSITIONATTRIBDATA data;
			ACCENT_POLICY acc[2];
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = acc;
			data.cbData = sizeof ACCENT_POLICY * 2;
			ret = getWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
*/
BOOL AutoRun(BOOL GetSet, BOOL bAuto)//读取、设置开机启动、关闭开机启动
{
	BOOL ret = FALSE;
	WCHAR sFileName[MAX_PATH];
	GetModuleFileName(NULL, sFileName, MAX_PATH);
	HKEY pKey;
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
	if (!pKey)
		RegOpenKeyEx(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
	if (pKey)
	{
		if (GetSet)
		{
			if (bAuto)
			{
				RegSetValueEx(pKey, szAppName, NULL, REG_SZ, (BYTE*)sFileName, MAX_PATH * sizeof(WCHAR));
			}
			else
			{
				RegDeleteValue(pKey, szAppName);
			}
			ret = TRUE;
		}
		else
		{
			WCHAR nFileName[MAX_PATH];
			DWORD cbData = MAX_PATH * sizeof WCHAR;
			DWORD dType = REG_SZ;
			if (RegQueryValueEx(pKey, szAppName, NULL, &dType, (LPBYTE)nFileName, &cbData) == ERROR_SUCCESS)
			{
				if (wcscmp(sFileName, nFileName) == 0)
					ret = TRUE;
				else
					ret = FALSE;
			}
		}
		RegCloseKey(pKey);
	}
	return ret;
}
INT_PTR CALLBACK ColorButtonProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)//颜色按钮控件右键处理
{
	switch (message)
	{
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		RECT rc;
		GetClientRect(hWnd, &rc);
		HBRUSH hb;
		hb = CreateSolidBrush(dAlphaColor&0xffffff);
		FillRect(hdc, &rc, hb);
		DeleteObject(hb);
		EndPaint(hWnd, &ps);
		return TRUE;
	}
	}
	return CallWindowProc(oldColorButtonPoroc, hWnd, message, wParam, lParam);
}