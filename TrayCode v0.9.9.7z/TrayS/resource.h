﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 TrayS.rc 使用
//
#define IDC_MYICON                      2
#define IDD_TRAYS_DIALOG                102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDD_MAIN                        103
#define IDS_TIPS                        104
#define IDD_SETTING                     105
#define IDI_TRAYS                       107
#define IDC_TRAYS                       109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     130
#define IDD_TASKBAR                     131
#define IDD_TIPS                        132
#define IDR_MENU                        134
#define IDC_RADIO_DEFAULT               1001
#define IDC_RADIO_TRANSPARENT           1002
#define IDC_RADIO_BLURBEHIND            1003
#define IDC_RADIO_ACRYLIC               1004
#define IDC_BUTTON_COLOR                1005
#define IDC_SLIDER_ALPHA_B              1006
#define IDC_SLIDER_ALPHA                1007
#define IDC_CLOSE                       1008
#define IDC_CHECK_AUTORUN               1009
#define IDC_RADIO_LEFT                  1010
#define IDC_RADIO_CENTER                1011
#define IDC_RADIO_RIGHT                 1012
#define IDC_CHECK_TRAYICON              1013
#define IDC_SYSLINK                     1014
#define IDC_CHECK_MONITOR               1015
#define IDC_CHECK_MONITOR_LEFT          1016
#define IDC_SYSLINK_52PJ                1017
#define IDC_RADIO_NORMAL                1018
#define IDC_RADIO_MAXIMIZE              1019
#define IDC_CHECK_MONITOR_FLOAT         1020
#define IDC_CHECK_MONITOR_FLOAT2        1021
#define IDC_CHECK_TRANSPARENT           1021
#define IDC_CHECK_TRAFFIC               1022
#define IDC_CHECK_USAGE                 1023
#define IDC_CHECK_TEMPERATURE           1024
#define IDC_BUTTON_COLOR_BACKGROUND     1025
#define IDC_BUTTON_COLOR_TRAFFIC_LOW    1026
#define IDC_BUTTON_COLOR_TRAFFIC_MEDIUM 1027
#define IDC_BUTTON_COLOR_TRAFFIC_HIGH   1028
#define IDC_BUTTON_COLOR_LOW            1029
#define IDC_BUTTON_COLOR_MEDUIM         1030
#define IDC_BUTTON_COLOR_HIGH           1031
#define IDC_RADIO_BYTE                  1032
#define IDC_RADIO_BIT                   1033
#define IDC_RADIO_AUTO                  1034
#define IDC_RADIO_KB                    1035
#define IDC_RADIO_MB                    1036
#define IDC_CHECK_MONITOR_PDH           1037
#define IDC_EDIT1                       1038
#define IDC_EDIT2                       1039
#define IDC_EDIT3                       1040
#define IDC_EDIT4                       1041
#define IDC_EDIT5                       1042
#define IDC_EDIT6                       1043
#define IDC_EDIT7                       1044
#define IDC_EDIT8                       1045
#define IDC_EDIT9                       1046
#define IDC_EDIT10                      1047
#define IDC_EDIT11                      1048
#define IDC_EDIT12                      1049
#define IDC_CHECK_SOUND                 1050
#define IDC_CHECK_USAGE2                1051
#define IDC_CHECK_MONITOR_SIMPLE        1051
#define IDC_CLOSE2                      1052
#define IDC_RESTORE_DEFAULT             1052
#define IDC_EDIT13                      1053
#define IDC_EDIT_TIME                   1053
#define IDC_CHECK_TIPS                  1054
#define IDC_BUTTON_FONT                 1055
#define IDC_BUTTON_TIPS_FONT            1056
#define IDC_EDIT14                      1057
#define IDC_EDIT15                      1058
#define IDC_EDIT16                      1059
#define IDC_EDIT17                      1060
#define IDC_EDIT18                      1063
#define IDC_EDIT19                      1064
#define IDC_EDIT20                      1075
#define IDC_EDIT21                      1076
#define IDC_EDIT22                      1077
#define IDC_EDIT23                      1078
#define IDC_SELECT_ALL                  32773
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
