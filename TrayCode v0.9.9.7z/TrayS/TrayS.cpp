﻿// TrayS.cpp : 定义应用程序的入口点。
//
#ifdef _WIN64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif

#include "framework.h"
#include "TrayS.h"
int DPI(int pixel)
{
	return pixel * iDPI / 96;
}
////////////////////////////////////////////////////动态运行函数
HINSTANCE ShellExecute(_In_opt_ HWND hwnd, _In_opt_ LPCWSTR lpOperation, _In_ LPCWSTR lpFile, _In_opt_ LPCWSTR lpParameters,_In_opt_ LPCWSTR lpDirectory, _In_ INT nShowCmd)
{
	HINSTANCE hInstance = NULL;
	typedef HINSTANCE(WINAPI* pfnShellExecute)(_In_opt_ HWND hwnd, _In_opt_ LPCWSTR lpOperation, _In_ LPCWSTR lpFile, _In_opt_ LPCWSTR lpParameters,_In_opt_ LPCWSTR lpDirectory, _In_ INT nShowCmd);
	HMODULE hShell32 = LoadLibrary(L"shell32.dll");
	if (hShell32)
	{
		pfnShellExecute ShellExecuteW =(pfnShellExecute)GetProcAddress(hShell32, "ShellExecuteW");
		if(ShellExecuteW)
			hInstance = ShellExecuteW(hwnd, lpOperation, lpFile, lpParameters, lpDirectory, nShowCmd);
		FreeLibrary(hShell32);
	}
	return hInstance;
}
BOOL Shell_NotifyIcon(DWORD dwMessage, _In_ PNOTIFYICONDATAW lpData)
{
	typedef BOOL(WINAPI* pfnShell_NotifyIcon)(DWORD dwMessage, _In_ PNOTIFYICONDATAW lpData);
	HMODULE hShell32 = LoadLibrary(L"shell32.dll");
	BOOL ret=FALSE;
	if (hShell32)
	{
		pfnShell_NotifyIcon Shell_NotifyIconW = (pfnShell_NotifyIcon)GetProcAddress(hShell32, "Shell_NotifyIconW");
		if (Shell_NotifyIconW)
			ret = Shell_NotifyIconW(dwMessage,lpData);
		FreeLibrary(hShell32);
	}
	return ret;
}
BOOL WTSQueryUserToken(ULONG SessionId,PHANDLE phToken)
{
	BOOL ret=FALSE;
	typedef BOOL (WINAPI* pfnWTSQueryUserToken)(ULONG SessionId, PHANDLE phToken);
	HMODULE hWTSAPI32 = LoadLibrary(L"wtsapi32.dll");
	if (hWTSAPI32)
	{
		pfnWTSQueryUserToken WTSQueryUserToken = (pfnWTSQueryUserToken)GetProcAddress(hWTSAPI32, "WTSQueryUserToken");
		if (WTSQueryUserToken)
			ret = WTSQueryUserToken(SessionId,phToken);
		FreeLibrary(hWTSAPI32);
	}
	return ret;
}
BOOL CreateEnvironmentBlock(_At_((PZZWSTR*)lpEnvironment, _Outptr_)LPVOID* lpEnvironment, _In_opt_ HANDLE  hToken, _In_ BOOL bInherit)
{
	BOOL ret = FALSE;
	typedef BOOL(WINAPI* pfnCreateEnvironmentBlock)(_At_((PZZWSTR*)lpEnvironment, _Outptr_)LPVOID* lpEnvironment, _In_opt_ HANDLE  hToken, _In_ BOOL bInherit);
	HMODULE hUserenv = LoadLibrary(L"userenv.dll");
	if (hUserenv)
	{
		pfnCreateEnvironmentBlock CreateEnvironmentBlock = (pfnCreateEnvironmentBlock)GetProcAddress(hUserenv, "CreateEnvironmentBlock");
		if (CreateEnvironmentBlock)
			ret = CreateEnvironmentBlock(lpEnvironment,hToken,bInherit);
		FreeLibrary(hUserenv);
	}
	return ret;
}
ULONG CallNtPowerInformation(_In_ POWER_INFORMATION_LEVEL InformationLevel,_In_reads_bytes_opt_(InputBufferLength) PVOID InputBuffer,_In_ ULONG InputBufferLength,_Out_writes_bytes_opt_(OutputBufferLength) PVOID OutputBuffer,_In_ ULONG OutputBufferLength)
{
	ULONG ret=-1;
	typedef BOOL(WINAPI* pfnCallNtPowerInformation)(_In_ POWER_INFORMATION_LEVEL InformationLevel, _In_reads_bytes_opt_(InputBufferLength) PVOID InputBuffer, _In_ ULONG InputBufferLength, _Out_writes_bytes_opt_(OutputBufferLength) PVOID OutputBuffer, _In_ ULONG OutputBufferLength);
	HMODULE hPowrptof = LoadLibrary(L"powrprof.dll");
	if (hPowrptof)
	{
		pfnCallNtPowerInformation CallNtPowerInformation = (pfnCallNtPowerInformation)GetProcAddress(hPowrptof, "CallNtPowerInformation");
		if (CallNtPowerInformation)
			ret = CallNtPowerInformation(InformationLevel,InputBuffer,InputBufferLength,OutputBuffer,OutputBufferLength);
		FreeLibrary(hPowrptof);
	}
	return ret;
}
BOOL CALLBACK FindWindowFunc(HWND hWnd, LPARAM lpAram)
{
	WCHAR szText[16];
	GetWindowText(hWnd, szText, 16);
	if (wcscmp(szText, L"_TrayS_") == 0)
	{
		SendMessage(hWnd, WM_TRAYS, 0, 0);
		return FALSE;
	}
	return TRUE;
}
BOOL CALLBACK IsZoomedFunc(HWND hWnd, LPARAM lpAram)
{
	if (::IsWindowVisible(hWnd) && IsZoomed(hWnd))
	{
		if (MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST) == (HMONITOR)lpAram)
		{
			BOOL Attribute = FALSE;
			if (DwmGetWindowAttribute)
				DwmGetWindowAttribute(hWnd, 14, &Attribute, sizeof(BOOL));
			if (Attribute == FALSE)
			{
				iWindowMode = 1;
				return FALSE;
			}
		}
	}
	return TRUE;
}
BOOL IsUserAdmin()//判断是以管理员权限运行
{
	//	IsUserAnAdmin();
	BOOL b;
	SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
	PSID AdministratorsGroup;
	b = AllocateAndInitializeSid(&NtAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &AdministratorsGroup);
	if (b)
	{
		if (!CheckTokenMembership(NULL, AdministratorsGroup, &b))
		{
			b = FALSE;
		}
		FreeSid(AdministratorsGroup);
	}
	return(b);
}
/*
BOOL CreateProcessByExplorer(LPCWSTR process, LPCWSTR szDir, LPCWSTR cmd)
{
	BOOL ret = FALSE;

	HANDLE hProcess = 0, hToken = 0, hDuplicatedToken = 0;
	LPVOID lpEnv = NULL;
	do
	{
		HWND hTrayWnd = ::FindWindow(szShellTray, NULL);
		DWORD explorerPid;
		GetWindowThreadProcessId(hTrayWnd, &explorerPid);// 获取explorer进程号，自行实现

		if (explorerPid == NULL)
			break;
		hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, TRUE, explorerPid);
		if (INVALID_HANDLE_VALUE == hProcess)
			break;

		if (!OpenProcessToken(hProcess, TOKEN_ALL_ACCESS, &hToken))
			break;

		DuplicateTokenEx(hToken, MAXIMUM_ALLOWED, NULL, SecurityIdentification, TokenPrimary, &hDuplicatedToken);
		CreateEnvironmentBlock(&lpEnv, hDuplicatedToken, FALSE);

		/ *
			WCHAR szDir[MAX_PATH] = L"\"";
		wcscpy_s(&szDir[2], MAX_PATH, process);
		int iLen = wcslen(szDir);
		if (NULL != cmd)
		{
			wcscpy_s(&szDir[iLen], MAX_PATH, L"\" \"");
			iLen = wcslen(szDir);
			wcscpy_s(&szDir[iLen], MAX_PATH, cmd);
		}
		iLen = wcslen(szDir);
		wcscpy_s(&szDir[iLen], MAX_PATH, L"\"");
		* /

			STARTUPINFO si = { 0 };
		PROCESS_INFORMATION pi = { 0 };
		si.cb = sizeof(STARTUPINFO);
		si.lpDesktop = (LPWSTR)L"winsta0\\default";
		si.dwFlags = STARTF_USESHOWWINDOW;
		si.wShowWindow = SW_HIDE;
		if (!CreateProcessAsUser(hToken, process, NULL / *const_cast<LPWSTR>(szDir) * / , 0, 0, FALSE, CREATE_UNICODE_ENVIRONMENT, lpEnv, NULL, &si, &pi))
			break;
		ret = TRUE;
	} while (0);
	if (INVALID_HANDLE_VALUE != hProcess)
		CloseHandle(hProcess);
	if (INVALID_HANDLE_VALUE != hToken)
		CloseHandle(hToken);
	if (INVALID_HANDLE_VALUE != hDuplicatedToken)
		CloseHandle(hDuplicatedToken);
	if (NULL != lpEnv)
		DestroyEnvironmentBlock(lpEnv);
	return ret;
}
*/
BOOL LaunchAppIntoDifferentSession(WCHAR* szExe, WCHAR* szDir)//以SYSTEM运行程序并可以交互窗口
{
	PROCESS_INFORMATION pi;
	STARTUPINFO si;
	BOOL bResult = FALSE;

	DWORD winlogonPid;
	ULONG dwSessionId;
	HANDLE hUserToken, hUserTokenDup = NULL, hPToken = NULL, hProcess;
	DWORD dwCreationFlags;

	// Log the client on to the local computer.

	dwSessionId = WTSGetActiveConsoleSessionId();

	//////////////////////////////////////////
	   // Find the winlogon process
	////////////////////////////////////////

	PROCESSENTRY32 procEntry;

	HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hSnap == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}

	procEntry.dwSize = sizeof(PROCESSENTRY32);

	if (!Process32First(hSnap, &procEntry))
	{
		return FALSE;
	}

	do
	{
		if (_wcsicmp(procEntry.szExeFile, L"winlogon.exe") == 0)
		{
			// We found a winlogon process...
		// make sure it's running in the console session
			DWORD winlogonSessId = 0;
			if (ProcessIdToSessionId(procEntry.th32ProcessID, &winlogonSessId)
				&& winlogonSessId == dwSessionId)
			{
				winlogonPid = procEntry.th32ProcessID;
				break;
			}
		}

	} while (Process32Next(hSnap, &procEntry));

	////////////////////////////////////////////////////////////////////////

	WTSQueryUserToken(dwSessionId, &hUserToken);
	dwCreationFlags = NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE;
	ZeroMemory(&si, sizeof(STARTUPINFO));
	si.cb = sizeof(STARTUPINFO);
	si.lpDesktop = (LPWSTR)L"winsta0\\default";
	ZeroMemory(&pi, sizeof(pi));
	TOKEN_PRIVILEGES tp;
	LUID luid;
	hProcess = OpenProcess(MAXIMUM_ALLOWED, FALSE, winlogonPid);
	if (hProcess)
	{
		if (!::OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY
			| TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_ADJUST_SESSIONID
			| TOKEN_READ | TOKEN_WRITE, &hPToken))
		{
			//			int abcd = GetLastError();
						//		printf("Process token open Error: %u\n", GetLastError());
		}

		if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &luid))
		{
			//		printf("Lookup Privilege value Error: %u\n", GetLastError());
		}
		tp.PrivilegeCount = 1;
		tp.Privileges[0].Luid = luid;
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

		DuplicateTokenEx(hPToken, MAXIMUM_ALLOWED, NULL,
			SecurityIdentification, TokenPrimary, &hUserTokenDup);
		int dup = GetLastError();

		//Adjust Token privilege
		SetTokenInformation(hUserTokenDup,
			TokenSessionId, (LPVOID)dwSessionId, sizeof(ULONG));

		if (!AdjustTokenPrivileges(hUserTokenDup, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
			(PTOKEN_PRIVILEGES)NULL, NULL))
		{
			//			int abc = GetLastError();
						//		printf("Adjust Privilege value Error: %u\n", GetLastError());
		}

		if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)
		{
			//		printf("Token does not have the provilege\n");
		}

		LPVOID pEnv = NULL;

		if (CreateEnvironmentBlock(&pEnv, hUserTokenDup, TRUE))
		{
			dwCreationFlags |= CREATE_UNICODE_ENVIRONMENT;
		}
		else
			pEnv = NULL;

		// Launch the process in the client's logon session.

		bResult = CreateProcessAsUser(
			hUserTokenDup,                     // client's access token
			szExe,    // file to execute
			NULL,                 // command line
			NULL,            // pointer to process SECURITY_ATTRIBUTES
			NULL,               // pointer to thread SECURITY_ATTRIBUTES
			FALSE,              // handles are not inheritable
			dwCreationFlags,     // creation flags
			pEnv,               // pointer to new environment block
			szDir,               // name of current directory
			&si,               // pointer to STARTUPINFO structure
			&pi                // receives information about new process
		);
	}
	if (hProcess)
	{
		CloseHandle(hProcess);
		CloseHandle(hUserToken);
		CloseHandle(hUserTokenDup);
		CloseHandle(hPToken);
	}
	return bResult;
}
//////////////////////////////////////////////////////////////////////////服务函数
BOOL bInstallService;
SERVICE_STATUS_HANDLE hServiceStatus;
SERVICE_STATUS status;
void WINAPI ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
HANDLE hEvent = INVALID_HANDLE_VALUE;
void WINAPI ServiceStrl(DWORD dwOpcode)//服务控制函数
{
	switch (dwOpcode)
	{
	case SERVICE_CONTROL_STOP:
		status.dwCurrentState = SERVICE_STOP_PENDING;
		SetServiceStatus(hServiceStatus, &status);
		//告诉服务线程停止工作
		::SetEvent(hEvent);
		break;
	case SERVICE_CONTROL_PAUSE:
		break;
	case SERVICE_CONTROL_CONTINUE:
		break;
	case SERVICE_CONTROL_INTERROGATE:
		break;
	case SERVICE_CONTROL_SHUTDOWN:
		break;
	default:
		break;
	}
}
void WINAPI ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv)//服务主线程入口
{
	// Register the control request handler
	status.dwCurrentState = SERVICE_START_PENDING;
	status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	//注册服务控制
	hServiceStatus = RegisterServiceCtrlHandler(szAppName, ServiceStrl);
	if (hServiceStatus == NULL)
	{
		return;
	}
	SetServiceStatus(hServiceStatus, &status);
	//如下代码可以为启动服务前的准备工作
	hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	if (hEvent == NULL)
	{
		status.dwCurrentState = SERVICE_STOPPED;
		SetServiceStatus(hServiceStatus, &status);
		return;
	}
	//更改服务状态为启动
	status.dwWin32ExitCode = S_OK;
	status.dwCheckPoint = 0;
	status.dwWaitHint = 0;
	status.dwCurrentState = SERVICE_RUNNING;
	SetServiceStatus(hServiceStatus, &status);
	//等待用户选择停止服务，
	//当然你也可以把你的服务代码用线程来执行，
	//此时这里只需等待线程结束既可。
//	CloseHandle(CreateFile(L"d:\\topc.txt", GENERIC_READ, FILE_SHARE_READ, NULL, CREATE_ALWAYS, NULL, NULL));
	WCHAR szExe[MAX_TEXT];
	HINSTANCE hInst = GetModuleHandle(NULL);
	GetModuleFileName(hInst, szExe, MAX_TEXT);
	size_t iLen = wcslen(szExe);
	szExe[iLen] = L'\0';
	//	CreateProcessByExplorer(szExe, NULL, NULL);
	LaunchAppIntoDifferentSession(szExe, NULL);
	while (WaitForSingleObject(hEvent, 1000) != WAIT_OBJECT_0)
	{
	}
	//停止服务
	status.dwCurrentState = SERVICE_STOPPED;
	SetServiceStatus(hServiceStatus, &status);
}
DWORD ServiceRunState()//服务运行状态
{
	BOOL bResult = FALSE;
	//打开服务控制管理器
	SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (hSCM != NULL)
	{
		//打开服务
		SC_HANDLE hService = ::OpenService(hSCM, szAppName, SERVICE_QUERY_STATUS);
		if (hService != NULL)
		{
			SERVICE_STATUS ss;
			QueryServiceStatus(hService, &ss);
			bResult = ss.dwCurrentState;
			::CloseServiceHandle(hService);
		}
		::CloseServiceHandle(hSCM);
	}
	return bResult;
}
BOOL IsServiceInstalled()//服务是否已经安装
{
	BOOL bResult = FALSE;
	//打开服务控制管理器
	SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (hSCM != NULL)
	{
		//打开服务
		SC_HANDLE hService = ::OpenService(hSCM, szAppName, SERVICE_QUERY_CONFIG);
		if (hService != NULL)
		{
			bResult = TRUE;
			::CloseServiceHandle(hService);
		}
		::CloseServiceHandle(hSCM);
	}
	return bResult;
}
BOOL InstallService()//安装服务
{
	if (IsServiceInstalled())
		return TRUE;
	//打开服务控制管理器
	SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (hSCM == NULL)
	{
		return FALSE;
	}
	// Get the executable file path
	TCHAR szFilePath[MAX_TEXT];
	::GetModuleFileName(NULL, szFilePath, MAX_TEXT);
	//创建服务
	SC_HANDLE hService = ::CreateService(
		hSCM,
		szAppName,
		szAppName,
		SERVICE_ALL_ACCESS,
		SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS,
		SERVICE_AUTO_START, //如果为SERVICE_DEMAND_START则表示此服务需手工启动
		SERVICE_ERROR_NORMAL,
		szFilePath,
		NULL,
		NULL,
		_T(""),
		NULL,
		NULL);
	if (hService == NULL)
	{
		::CloseServiceHandle(hSCM);
		return FALSE;
	}
	::CloseServiceHandle(hService);
	::CloseServiceHandle(hSCM);
	return TRUE;
}
BOOL UninstallService()//卸载服务
{
	if (!IsServiceInstalled())
		return TRUE;
	SC_HANDLE hSCM = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (hSCM == NULL)
	{
		return FALSE;
	}
	SC_HANDLE hService = ::OpenService(hSCM, szAppName, SERVICE_STOP | DELETE);
	if (hService == NULL)
	{
		::CloseServiceHandle(hSCM);
		return FALSE;
	}
	SERVICE_STATUS status;
	::ControlService(hService, SERVICE_CONTROL_STOP, &status);
	//删除服务
	BOOL bDelete = ::DeleteService(hService);
	::CloseServiceHandle(hService);
	::CloseServiceHandle(hSCM);
	if (bDelete)
		return TRUE;
	return FALSE;
}
void Init()//初始化服务参数
{
	hServiceStatus = NULL;
	status.dwServiceType = SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS;
	status.dwCurrentState = SERVICE_STOPPED;
	status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	status.dwWin32ExitCode = 0;
	status.dwServiceSpecificExitCode = 0;
	status.dwCheckPoint = 0;
	status.dwWaitHint = 0;
}
BOOL ServiceCtrlStart()//开启服务
{
	BOOL bRet;
	SC_HANDLE hSCM;
	SC_HANDLE hService;
	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM != NULL)
	{
		//		hService = OpenService(hSCM, szServiceName, SERVICE_START);
		hService = OpenService(hSCM, szAppName, SERVICE_ALL_ACCESS);
		if (hService != NULL)
		{
			TCHAR szFilePath[MAX_TEXT];
			::GetModuleFileName(NULL, szFilePath, MAX_TEXT);
			ChangeServiceConfig(hService, SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS, SERVICE_AUTO_START, SERVICE_NO_CHANGE, szFilePath, NULL, NULL, NULL, NULL, NULL, NULL);
			//开始Service
			bRet = StartService(hService, 0, NULL);
			CloseServiceHandle(hService);
		}
		else
		{
			bRet = FALSE;
		}
		CloseServiceHandle(hSCM);
	}
	else
	{
		bRet = FALSE;
	}
	return bRet;
}
BOOL ServiceCtrlStop()//停止服务
{
	BOOL bRet;
	SC_HANDLE hSCM;
	SC_HANDLE hService;
	SERVICE_STATUS ServiceStatus;
	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (hSCM != NULL)
	{
		hService = OpenService(hSCM, szAppName, SERVICE_STOP | SERVICE_QUERY_STATUS);
		if (hService != NULL)
		{
			QueryServiceStatus(hService, &ServiceStatus);
			if (ServiceStatus.dwCurrentState == SERVICE_RUNNING)
			{
				bRet = ControlService(hService, SERVICE_CONTROL_STOP, &ServiceStatus);
			}
			else
			{
				bRet = FALSE;
			}
			CloseServiceHandle(hService);
		}
		else
		{
			bRet = FALSE;
		}
		CloseServiceHandle(hSCM);
	}
	else
	{
		bRet = FALSE;
	}
	return bRet;
}
/*
//包含处理器数量的系统结构体
typedef struct SYSTEM_BASIC { DWORD dwUnknown1; ULONG uKeMaximumIncrement; ULONG uPageSize; ULONG uMmNumberOfPhysicalPages; ULONG uMmLowestPhysicalPage; ULONG uMmHighestPhysicalPage; ULONG uAllocationGranularity; PVOID pLowestUserAddress; PVOID pMmHighestUserAddress; ULONG uKeActiveProcessors; BYTE bKeNumberProcessors; BYTE bUnknown2; WORD wUnknown3; }SYSTEM_BASIC_INFORMATION; //包含处理器使用量的系统结构体typedef struct SYSTEM_PROCESSOR_PERFORMANCE{__int64 i64IdleTime;__int64 i64KernelTime;__int64 i64UserTime;__int64 i64DpcTime;__int64 i64InterruptTime;long lInterruptCount;}SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION;


//计算CPU使用率
int CalProcessorsUses()
{
	__int64	nIdleTime = 0, nKernelTime = 0, nUserTime = 0, nDpcTime = 0, nInterruptTime = 0, nTotalTime = 0;

	int status = NtQuerySystemInformation(SystemProcessorPerformanceInformation, m_ProcessInfo, sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION) * m_nNumberProcessors, 0);
	if (status != NO_ERROR)
		return -1;

	for (int i = 0; i < m_nNumberProcessors; i++)
	{
		nIdleTime = m_ProcessInfo[i].i64IdleTime - m_vProcess[i].nOidleTime;
		nAllIdleTime += nIdleTime;
		nKernelTime = m_ProcessInfo[i].i64KernelTime - m_vProcess[i].nOkerenelTime;
		nUserTime = m_ProcessInfo[i].i64UserTime - m_vProcess[i].nOuserTime;
		nDpcTime = m_ProcessInfo[i].i64DpcTime - m_vProcess[i].nOdpctTime;
		nInterruptTime = m_ProcessInfo[i].i64InterruptTime - m_vProcess[i].nOinterruptTime;

		nTotalTime = nKernelTime + nUserTime + nDpcTime + nInterruptTime;
		nAllTotalTime += nTotalTime;
		if (nTotalTime != 0)
		{
			m_vProcess[i].nUsage = 100 * (nTotalTime - nIdleTime) / nTotalTime;	//计算CPU使用率
		}
		else
		{
			m_vProcess[i].nUsage = 0;
		}


		m_vProcess[i].nOidleTime = m_ProcessInfo[i].i64IdleTime;
		m_vProcess[i].nOkerenelTime = m_ProcessInfo[i].i64KernelTime;
		m_vProcess[i].nOuserTime = m_ProcessInfo[i].i64UserTime;
		m_vProcess[i].nOdpctTime = m_ProcessInfo[i].i64DpcTime;
		m_vProcess[i].nOinterruptTime = m_ProcessInfo[i].i64InterruptTime;
	}

	return 1;
}

typedef struct struct_Process
{
	int nUsage;//每个CPU的使用率
	__int64 nOidleTime;	//旧的CPU使用量的值，用于计算CPU使用率
	__int64 nOkerenelTime;
	__int64 nOuserTime;
	__int64 nOdpctTime;
	__int64 nOinterruptTime;
	struct_Process()
	{
		nUsage = 0;
		nOidleTime = 0;
		nOkerenelTime = 0;
		nOuserTime = 0;
		nOdpctTime = 0;
		nOinterruptTime = 0;
	}
}PROCESS;
std::vector<PROCESS> m_vProcess;//每一个处理器的信息，包含了绘制区域，使用率，,老的CPU使用量


//@brief 获取进程的Cpu占用率
//@param [in]    hProcess            进程句柄
//@param [in]    dwElepsedTime        取样间隔时间（毫秒）
//@return 成功 : cpu占用率    失败 : -1
//
int GetProcessCpuPercent(const HANDLE hProcess, const DWORD dwElepsedTime)
{
	int nProcCpuPercent = 0;
	BOOL bRetCode = FALSE;

	FILETIME CreateTime, ExitTime, KernelTime, UserTime;
	LARGE_INTEGER lgKernelTime;
	LARGE_INTEGER lgUserTime;
	LARGE_INTEGER lgCurTime;

	bRetCode = GetProcessTimes(hProcess, &CreateTime, &ExitTime, &KernelTime, &UserTime);
	if (bRetCode)
	{
		lgKernelTime.HighPart = KernelTime.dwHighDateTime;
		lgKernelTime.LowPart = KernelTime.dwLowDateTime;

		lgUserTime.HighPart = UserTime.dwHighDateTime;
		lgUserTime.LowPart = UserTime.dwLowDateTime;

		lgCurTime.QuadPart = (lgKernelTime.QuadPart + lgUserTime.QuadPart) / 10000;
		nProcCpuPercent = (int)((lgCurTime.QuadPart - g_slgProcessTimeOld.QuadPart) * 100 / dwElepsedTime);
		g_slgProcessTimeOld = lgCurTime;
		nProcCpuPercent = nProcCpuPercent / g_sdwProcessorCoreNum;
	}
	else
	{
		nProcCpuPercent = -1;
	}

	return nProcCpuPercent;
*/
DWORD iCPU;
/////////////////////////////////////////////////////////////////////////////CPU占用率
FILETIME pre_idleTime;
FILETIME pre_kernelTime;
FILETIME pre_userTime;
__int64 CompareFileTime(FILETIME time1, FILETIME time2)
{
	__int64 a = time1.dwHighDateTime;
	a = a << 32 | time1.dwLowDateTime;
	__int64 b = time2.dwHighDateTime;
	b = b << 32 | time2.dwLowDateTime;
	return (b - a);
}
typedef struct _PDH_RAW_COUNTER {
	volatile DWORD CStatus;
	FILETIME    TimeStamp;
	LONGLONG    FirstValue;
	LONGLONG    SecondValue;
	DWORD       MultiCount;
} PDH_RAW_COUNTER, * PPDH_RAW_COUNTER;
PDH_RAW_COUNTER m_last_rawData;
BOOL m_first_get_CPU_utility=TRUE;
int GetCPUUseRate()
{
	if (TraySave.bMonitorPDH)
	{
#define PDH_FMT_RAW          ((DWORD) 0x00000010)
#define PDH_FMT_ANSI         ((DWORD) 0x00000020)
#define PDH_FMT_UNICODE      ((DWORD) 0x00000040)
#define PDH_FMT_LONG         ((DWORD) 0x00000100)
#define PDH_FMT_DOUBLE       ((DWORD) 0x00000200)
#define PDH_FMT_LARGE        ((DWORD) 0x00000400)
#define PDH_FMT_NOSCALE      ((DWORD) 0x00001000)
#define PDH_FMT_1000         ((DWORD) 0x00002000)
#define PDH_FMT_NODATA       ((DWORD) 0x00004000)
#define PDH_FMT_NOCAP100     ((DWORD) 0x00008000)
#define PERF_DETAIL_COSTLY   ((DWORD) 0x00010000)
#define PERF_DETAIL_STANDARD ((DWORD) 0x0000FFFF)
		typedef HANDLE       PDH_HCOUNTER;
		typedef HANDLE       PDH_HQUERY;
		typedef HANDLE       PDH_HLOG;

		typedef PDH_HCOUNTER HCOUNTER;
		typedef PDH_HQUERY   HQUERY;

		typedef struct _PDH_FMT_COUNTERVALUE {
			DWORD    CStatus;
			union {
				LONG        longValue;
				double      doubleValue;
				LONGLONG    largeValue;
				LPCSTR      AnsiStringValue;
				LPCWSTR     WideStringValue;
			};
		} PDH_FMT_COUNTERVALUE, * PPDH_FMT_COUNTERVALUE;
		//获取CPU使用率
		HQUERY hQuery;
		HCOUNTER hCounter;
		DWORD counterType;
		PDH_RAW_COUNTER rawData;
		typedef ULONG(WINAPI* pfnPdhOpenQuery)(_In_opt_ LPCWSTR szDataSource,_In_ DWORD_PTR dwUserData,_Out_ PDH_HQUERY* phQuery);
		typedef ULONG(WINAPI* pfnPdhAddCounter)(_In_ PDH_HQUERY hQuery,_In_ LPCWSTR szFullCounterPath,_In_ DWORD_PTR dwUserData,_Out_ PDH_HCOUNTER* phCounter);
		typedef ULONG(WINAPI* pfnPdhCollectQueryData)(PDH_HQUERY hQuery);
		typedef ULONG(WINAPI* pfnPdhGetRawCounterValue)(PDH_HCOUNTER hCounter, LPDWORD lpdwType, PPDH_RAW_COUNTER pValue);
		typedef ULONG(WINAPI* pfnPdhCalculateCounterFromRawValue)(PDH_HCOUNTER hCounter, DWORD dwFormat, PPDH_RAW_COUNTER rawValue1, PPDH_RAW_COUNTER rawValue2, PPDH_FMT_COUNTERVALUE fmtValue);
		typedef ULONG(WINAPI* pfnPdhCloseQuery)(PDH_HQUERY hQuery);
		if(hPDH==NULL)
			hPDH = LoadLibrary(L"pdh.dll");
		if (hPDH)
		{
			pfnPdhOpenQuery PdhOpenQuery = (pfnPdhOpenQuery)GetProcAddress(hPDH, "PdhOpenQueryW");
			pfnPdhAddCounter PdhAddCounter = (pfnPdhAddCounter)GetProcAddress(hPDH, "PdhAddCounterW");
			pfnPdhCollectQueryData PdhCollectQueryData = (pfnPdhCollectQueryData)GetProcAddress(hPDH, "PdhCollectQueryData");
			pfnPdhGetRawCounterValue PdhGetRawCounterValue = (pfnPdhGetRawCounterValue)GetProcAddress(hPDH, "PdhGetRawCounterValue");
			pfnPdhCalculateCounterFromRawValue PdhCalculateCounterFromRawValue = (pfnPdhCalculateCounterFromRawValue)GetProcAddress(hPDH, "PdhCalculateCounterFromRawValue");
			pfnPdhCloseQuery PdhCloseQuery = (pfnPdhCloseQuery)GetProcAddress(hPDH, "PdhCloseQuery");
			if (PdhCloseQuery != NULL && PdhAddCounter != NULL && PdhCollectQueryData != NULL && PdhGetRawCounterValue != NULL && PdhCalculateCounterFromRawValue != NULL && PdhCloseQuery != NULL)
			{
				PdhOpenQuery(NULL, 0, &hQuery);//开始查询
				const wchar_t* query_str{};

				query_str = L"\\Processor Information(_Total)\\% Processor Utility";
				PdhAddCounter(hQuery, query_str, NULL, &hCounter);
				PdhCollectQueryData(hQuery);
				PdhGetRawCounterValue(hCounter, &counterType, &rawData);
				PDH_FMT_COUNTERVALUE fmtValue;
				PdhCalculateCounterFromRawValue(hCounter, PDH_FMT_DOUBLE, &rawData, &m_last_rawData, &fmtValue);//计算使用率
				iCPU = (int)fmtValue.doubleValue;//传出数据
				if (iCPU > 100)
					iCPU = 100;
				m_last_rawData = rawData;//保存上一次数据
				PdhCloseQuery(hQuery);//关闭查询
			}
		}
		return iCPU;
	}
	else
	{
		if (hPDH)
		{
			FreeLibrary(hPDH);
			hPDH = NULL;
		}
		int nCPUUseRate = -1;
		FILETIME idleTime;//空闲时间 
		FILETIME kernelTime;//核心态时间 
		FILETIME userTime;//用户态时间 
		GetSystemTimes(&idleTime, &kernelTime, &userTime);

		__int64 idle = CompareFileTime(pre_idleTime, idleTime);
		__int64 kernel = CompareFileTime(pre_kernelTime, kernelTime);
		__int64 user = CompareFileTime(pre_userTime, userTime);
		nCPUUseRate = (int)((kernel + user - idle) * 100 / (kernel + user));
		pre_idleTime = idleTime;
		pre_kernelTime = kernelTime;
		pre_userTime = userTime;
		if (nCPUUseRate < 1)
			nCPUUseRate = iCPU;
		else if (nCPUUseRate > 100)
			nCPUUseRate = 100;
		return nCPUUseRate;
	}
}
void ReadReg()//读取设置
{
	WCHAR szDir[MAX_PATH];
	GetModuleFileName(NULL, szDir, MAX_PATH);
	size_t len = wcslen(szDir);
	for (size_t i = len - 1; i > 0; i--)
	{
		if (szDir[i] == '\\')
		{
			szDir[i] = 0;
			SetCurrentDirectory(szDir);
			break;
		}
	}

	HANDLE hFile = CreateFile(szTraySave, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, NULL);
	if (hFile)
	{
		DWORD dwBytes;
		ReadFile(hFile, &TraySave, sizeof TraySave, &dwBytes, NULL);
		CloseHandle(hFile);
	}
/*
	HKEY pKey;
	if(IsUserAdmin())
		RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	else
		RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	if (pKey)
	{
		DWORD dType = REG_BINARY;
		DWORD cbData = sizeof(aMode);
		RegQueryValueEx(pKey, szMode, NULL, &dType, (BYTE*)aMode, &cbData);
		dType = REG_BINARY;
		cbData = sizeof(dAlphaColor);
		RegQueryValueEx(pKey, szAlphaColor, NULL, &dType, (BYTE*)dAlphaColor, &cbData);
		dType = REG_BINARY;
		cbData = sizeof(bAlpha);
		RegQueryValueEx(pKey, szAlpha, NULL, &dType, (BYTE*)bAlpha, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szPos, NULL, &dType, (BYTE*)&iPos, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szUnit, NULL, &dType, (BYTE*)&iUnit, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szTrayIcon, NULL, &dType, (BYTE*)&bTrayIcon, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitor, NULL, &dType, (BYTE*)&bMonitor, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorLeft, NULL, &dType, (BYTE*)&bMonitorLeft, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorFloat, NULL, &dType, (BYTE*)&bMonitorFloat, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorTransparent, NULL, &dType, (BYTE*)&bMonitorTransparent, &cbData);
		dType = REG_BINARY;
		cbData = sizeof(dMonitorPoint);
		RegQueryValueEx(pKey, szMonitorPoint, NULL, &dType, (BYTE*)&dMonitorPoint, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorTraffic, NULL, &dType, (BYTE*)&bMonitorTraffic, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorTemperature, NULL, &dType, (BYTE*)&bMonitorTemperature, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorUsage, NULL, &dType, (BYTE*)&bMonitorUsage, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szSound, NULL, &dType, (BYTE*)&bSound, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorPDH, NULL, &dType, (BYTE*)&bMonitorPDH, &cbData);
		dType = REG_DWORD;
		cbData = sizeof(DWORD);
		RegQueryValueEx(pKey, szMonitorSimple, NULL, &dType, (BYTE*)&bMonitorSimple, &cbData);
		dType = REG_BINARY;
		cbData = sizeof(cMonitorColor);
		RegQueryValueEx(pKey, szMonitorColor, NULL, &dType, (BYTE*)cMonitorColor, &cbData);
		dType = REG_BINARY;
		cbData = sizeof(dNumValues);
		RegQueryValueEx(pKey, szNumValues, NULL, &dType, (BYTE*)dNumValues, &cbData);
		dType = REG_BINARY;
		cbData = 38;
		RegQueryValueEx(pKey, szAdapterName, NULL, &dType, (BYTE*)AdpterName, &cbData);
		RegCloseKey(pKey);
	}
*/
}
void WriteReg()//写入设置
{
	WCHAR szDir[MAX_PATH];
	GetModuleFileName(NULL, szDir, MAX_PATH);
	size_t len = wcslen(szDir);
	for (size_t i = len - 1; i > 0; i--)
	{
		if (szDir[i] == '\\')
		{
			szDir[i] = 0;
			SetCurrentDirectory(szDir);
			break;
		}
	}
	HANDLE hFile = CreateFile(szTraySave, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_ARCHIVE, NULL);
	if (hFile)
	{
		DWORD dwBytes;
		WriteFile(hFile, &TraySave, sizeof TraySave, &dwBytes, NULL);
//		ReadFile(hFile, &TraySave, sizeof TraySave, &dwBytes, NULL);
		CloseHandle(hFile);
	}
/*
	HKEY pKey;
	if (IsUserAdmin())
	{
		RegCreateKey(HKEY_LOCAL_MACHINE, szSubKey, &pKey);
		RegCloseKey(pKey);
		RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	}
	else
	{
		RegCreateKey(HKEY_CURRENT_USER, szSubKey, &pKey);
		RegCloseKey(pKey);
		RegOpenKeyEx(HKEY_CURRENT_USER, szSubKey, NULL, KEY_ALL_ACCESS, &pKey);
	}
	if (pKey)
	{
		RegSetValueEx(pKey, szMode, NULL, REG_BINARY, (BYTE*)aMode, sizeof(aMode));
		RegSetValueEx(pKey, szAlphaColor, NULL, REG_BINARY, (BYTE*)dAlphaColor, sizeof(dAlphaColor));
		RegSetValueEx(pKey, szAlpha, NULL, REG_BINARY, (BYTE*)bAlpha, sizeof(bAlpha));
		RegSetValueEx(pKey, szPos, NULL, REG_DWORD, (BYTE*)&iPos, sizeof(iPos));
		RegSetValueEx(pKey, szUnit, NULL, REG_DWORD, (BYTE*)&iUnit, sizeof(iUnit));
		RegSetValueEx(pKey, szTrayIcon, NULL, REG_DWORD, (BYTE*)&bTrayIcon, sizeof(bTrayIcon));
		RegSetValueEx(pKey, szMonitor, NULL, REG_DWORD, (BYTE*)&bMonitor, sizeof(bMonitor));
		RegSetValueEx(pKey, szMonitorLeft, NULL, REG_DWORD, (BYTE*)&bMonitorLeft, sizeof(bMonitorLeft));
		RegSetValueEx(pKey, szMonitorFloat, NULL, REG_DWORD, (BYTE*)&bMonitorFloat, sizeof(bMonitorFloat));
		RegSetValueEx(pKey, szMonitorTransparent, NULL, REG_DWORD, (BYTE*)&bMonitorTransparent, sizeof(bMonitorTransparent));
		RegSetValueEx(pKey, szMonitorPoint, NULL, REG_BINARY, (BYTE*)&dMonitorPoint, sizeof(dMonitorPoint));
		RegSetValueEx(pKey, szMonitorTraffic, NULL, REG_DWORD, (BYTE*)&bMonitorTraffic, sizeof(bMonitorTraffic));
		RegSetValueEx(pKey, szMonitorTemperature, NULL, REG_DWORD, (BYTE*)&bMonitorTemperature, sizeof(bMonitorTemperature));
		RegSetValueEx(pKey, szMonitorUsage, NULL, REG_DWORD, (BYTE*)&bMonitorUsage, sizeof(bMonitorUsage));
		RegSetValueEx(pKey, szMonitorPDH, NULL, REG_DWORD, (BYTE*)&bMonitorPDH, sizeof(bMonitorPDH));
		RegSetValueEx(pKey, szMonitorSimple, NULL, REG_DWORD, (BYTE*)&bMonitorSimple, sizeof(bMonitorSimple));
		RegSetValueEx(pKey, szSound, NULL, REG_DWORD, (BYTE*)&bSound, sizeof(bSound));
		RegSetValueEx(pKey, szMonitorColor, NULL, REG_BINARY, (BYTE*)cMonitorColor, sizeof(cMonitorColor));
		RegSetValueEx(pKey, szNumValues, NULL, REG_BINARY, (BYTE*)dNumValues, sizeof(dNumValues));
		RegSetValueEx(pKey, szAdapterName, NULL, REG_BINARY, (BYTE*)AdpterName, 38);
		RegCloseKey(pKey);
	}
*/
}
void RunProcess(LPWSTR sz)
{
	
	STARTUPINFO StartInfo;
	PROCESS_INFORMATION procStruct;
	memset(&StartInfo, 0, sizeof(STARTUPINFO));
	StartInfo.cb = sizeof(STARTUPINFO);
	WCHAR szExe[MAX_PATH];
	WCHAR szCommandLine[MAX_PATH];
	szCommandLine[0] = L'\0';
	if (sz)
		wcscpy_s(szCommandLine, MAX_PATH, sz);
	GetModuleFileName(NULL, szExe, MAX_PATH);
	CreateProcess(szExe,// RUN_TEST.bat位于工程所在目录下
		szCommandLine,
		NULL,
		NULL,
		FALSE,
		NULL,// 这里不为该进程创建一个控制台窗口
		NULL,
		NULL,
		&StartInfo, &procStruct);
	CloseHandle(procStruct.hProcess);
	CloseHandle(procStruct.hThread);
	SetTimer(hMain, 11, 1000, NULL);
}

void OpenTaskBar()
{
	if (IsWindow(hTaskBar) == FALSE)
	{
		hTaskBar = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_TASKBAR), NULL, (DLGPROC)TaskBarProc);
		if (hTaskBar)
		{
			while (hTray==NULL)
			{
				hTray = FindWindow(szShellTray, NULL);
				if(hTray==NULL)
					Sleep(100);
			}
			while (hReBarWnd==NULL)
			{
				hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
				if (hReBarWnd == NULL)
					Sleep(100);
			}
			
			hTaskWnd = FindWindowEx(hReBarWnd, NULL, L"MSTaskSwWClass", NULL);
			if (TraySave.bMonitorFloat)
			{
				LONG exStyle = WS_EX_LAYERED | WS_EX_TOPMOST;
				if (TraySave.bMonitorTransparent)
					exStyle |= WS_EX_TRANSPARENT;
				SetWindowLongPtr(hTaskBar, GWL_EXSTYLE, GetWindowLongPtr(hTaskBar, GWL_EXSTYLE) | exStyle);
				SetLayeredWindowAttributes(hTaskBar,RGB(0,0,1), 198,LWA_ALPHA|LWA_COLORKEY);
				SetParent(hTaskBar, NULL);				
			}
			else
				SetParent(hTaskBar, hReBarWnd);
			SetWH();
/*
			if (rovi.dwMajorVersion < 10)
			{
				SetWindowLongPtr(hTaskBar, GWL_EXSTYLE, GetWindowLongPtr(hTaskBar, GWL_EXSTYLE) | WS_EX_LAYERED);
				SetLayeredWindowAttributes(hTaskBar, RGB(128, 128, 129), 0, LWA_COLORKEY);
			}
*/
			ShowWindow(hTaskBar, SW_SHOW);
			SetTimer(hTaskBar, 3, 1000, NULL);
//			SetTimer(hTaskBar, 6, 100, NULL);
		}
	}
	else
	{
		if(TraySave.bMonitorTransparent)
			SetWindowLongPtr(hTaskBar, GWL_EXSTYLE, GetWindowLongPtr(hTaskBar, GWL_EXSTYLE) | WS_EX_TRANSPARENT);
		else
			SetWindowLongPtr(hTaskBar, GWL_EXSTYLE, GetWindowLongPtr(hTaskBar, GWL_EXSTYLE) & ~WS_EX_TRANSPARENT);
	}
}
#define MISC_CONTROL_3 0x3+((0x18)<<3)
int GetCpuTemp(DWORD Core)
{
	if (bRing0)
	{
		SetThreadAffinityMask(GetCurrentThread(), Core);
		DWORD eax = 0, ebx, ecx, edx;
		if (!bIntel)
		{
			Cpuid(1, &eax, &ebx, &ecx, &edx);
			int family = ((eax >> 20) & 0xFF) + ((eax >> 8) & 0xF);
			if (family > 0xf)
			{
//				DWORD pciDevAddr = FindPciDeviceById(0x1022, 0x1203, 0);
				DWORD miscReg;
				ReadPciConfigDwordEx(MISC_CONTROL_3, 0xa4, &miscReg);
				return (miscReg >> 21) >> 3;
			}
			else
			{
//				DWORD pciDevAddr = FindPciDeviceById(0x1022, 0x1103, 0);
				DWORD miscReg;
				ReadPciConfigDwordEx(MISC_CONTROL_3, 0xe4, &miscReg);
				return ((miscReg & 0xFF0000) >> 16)-49;
//				return (miscReg >> 16) & 0xFF;
			}
		}
		else
		{			
			DWORD IAcore;
			int Tjunction=100;
			Rdmsr(0x1A2, &eax, &edx);
			if (eax & 0x20000000)
				Tjunction = 85;
			Rdmsr(0x19C, &eax, &edx);
			IAcore = eax;
			IAcore &= 0xFF0000;
			IAcore = IAcore >> 16;
			return Tjunction - IAcore;
		}
	}
	return 0;
}
void LoadTemperatureDLL()
{
	if (!InitOpenLibSys(&m_hOpenLibSys))
		bRing0 = FALSE;
	else
	{
		bRing0 = TRUE;
		DWORD eax, ebx, ecx, edx;
		Cpuid(0, &eax, &ebx, &ecx, &edx);
		bIntel = TRUE;
		if (ebx == 0x68747541)
		{
			bIntel = FALSE;
		}
	}
#ifdef _WIN64
	hNVDLL = LoadLibrary(L"nvapi64.dll");
#else
	hNVDLL = LoadLibrary(L"nvapi.dll");
#endif
	if (hNVDLL)
	{
		NvAPI_QueryInterface = (NvAPI_QueryInterface_t)GetProcAddress(hNVDLL, "nvapi_QueryInterface");
		if (NvAPI_QueryInterface)
		{
			NvAPI_Initialize_t NvAPI_Initialize = (NvAPI_Initialize_t)NvAPI_QueryInterface(ID_NvAPI_Initialize);
			NvAPI_EnumPhysicalGPUs_t NvAPI_EnumPhysicalGPUs = (NvAPI_EnumPhysicalGPUs_t)NvAPI_QueryInterface(ID_NvAPI_EnumPhysicalGPUs);
			NvAPI_GPU_GetThermalSettings = (NvAPI_GPU_GetThermalSettings_t)NvAPI_QueryInterface(ID_NvAPI_GPU_GetThermalSettings);
			if (NvAPI_Initialize != NULL && NvAPI_EnumPhysicalGPUs != NULL && NvAPI_GPU_GetThermalSettings != NULL)
			{
				if (NvAPI_Initialize() == 0)
				{
					for (NvU32 PhysicalGpuIndex = 0; PhysicalGpuIndex < 4; PhysicalGpuIndex++)
					{
						hPhysicalGpu[PhysicalGpuIndex] = 0;
					}
					int physicalGpuCount;
					NvAPI_EnumPhysicalGPUs(hPhysicalGpu, &physicalGpuCount);
				}
				else
				{
					FreeLibrary(hNVDLL);
					hNVDLL = NULL;
				}
			}
			else
			{
				FreeLibrary(hNVDLL);
				hNVDLL = NULL;
			}
		}
		else
		{
			FreeLibrary(hNVDLL);
			hNVDLL = NULL;
		}
	}
#ifdef _WIN64
	hATIDLL = LoadLibrary(L"atiadlxx.dll");
#else
	hATIDLL = LoadLibrary(L"atiadlxy.dll");
#endif
	if (hATIDLL)
	{
		ADL_Main_Control_Create = (ADL_MAIN_CONTROL_CREATE)GetProcAddress(hATIDLL, "ADL_Main_Control_Create");
		ADL_Main_Control_Destroy = (ADL_MAIN_CONTROL_DESTROY)GetProcAddress(hATIDLL, "ADL_Main_Control_Destroy");
		ADL_Overdrive5_Temperature_Get = (ADL_OVERDRIVE5_TEMPERATURE_GET)GetProcAddress(hATIDLL, "ADL_Overdrive5_Temperature_Get");
		if (NULL != ADL_Main_Control_Create &&
			NULL != ADL_Main_Control_Destroy
			)
		{
			if (ADL_OK != ADL_Main_Control_Create(ADL_Main_Memory_Alloc, 1))
			{
				FreeLibrary(hATIDLL);
				hATIDLL = NULL;
			}
		}
		else
		{
			FreeLibrary(hATIDLL);
			hATIDLL = NULL;
		}
	}
}
void FreeTemperatureDLL()
{
	if (hATIDLL)
	{
		ADL_Main_Control_Destroy();
		FreeLibrary(hATIDLL);
		hATIDLL = NULL;
	}
	if (hNVDLL)
	{
		FreeLibrary(hNVDLL);
		hNVDLL = NULL;
	}
	if (m_hOpenLibSys)
		DeinitOpenLibSys(&m_hOpenLibSys);
	m_hOpenLibSys = NULL;
}
void OpenSetting()
{
	if (IsWindow(hSetting))
	{
		SetForegroundWindow(hSetting);
		return;
	}
	hSetting = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_SETTING), NULL, (DLGPROC)SettingProc);
	if (!hSetting)
	{
		return;
	}
	SendMessage(hSetting, WM_SETICON, ICON_BIG, (LPARAM)(HICON)iMain);
	SendMessage(hSetting, WM_SETICON, ICON_SMALL, (LPARAM)(HICON)iMain);
	CheckRadioButton(hSetting, IDC_RADIO_NORMAL, IDC_RADIO_MAXIMIZE, IDC_RADIO_NORMAL);
	iProject = iWindowMode;
	if(iProject==0)
		CheckRadioButton(hSetting, IDC_RADIO_NORMAL, IDC_RADIO_MAXIMIZE, IDC_RADIO_NORMAL);
	else
		CheckRadioButton(hSetting, IDC_RADIO_NORMAL, IDC_RADIO_MAXIMIZE, IDC_RADIO_MAXIMIZE);
	if (TraySave.aMode[iProject] == ACCENT_DISABLED)
		CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_DEFAULT);
	else if (TraySave.aMode[iProject] == ACCENT_ENABLE_TRANSPARENTGRADIENT)
		CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_TRANSPARENT);
	else if (TraySave.aMode[iProject] == ACCENT_ENABLE_BLURBEHIND)
		CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_BLURBEHIND);
	else if (TraySave.aMode[iProject] == ACCENT_ENABLE_ACRYLICBLURBEHIND)
		CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_ACRYLIC);
	if (TraySave.iPos == 0)
		CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_LEFT);
	else if (TraySave.iPos == 1)
		CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_CENTER);
	else if (TraySave.iPos == 2)
		CheckRadioButton(hSetting, IDC_RADIO_LEFT, IDC_RADIO_RIGHT, IDC_RADIO_RIGHT);
	if (LOWORD(TraySave.iUnit) == 0)
		CheckRadioButton(hSetting, IDC_RADIO_AUTO, IDC_RADIO_MB, IDC_RADIO_AUTO);
	else if (LOWORD(TraySave.iUnit) == 1)
		CheckRadioButton(hSetting, IDC_RADIO_AUTO, IDC_RADIO_MB, IDC_RADIO_KB);
	else if (LOWORD(TraySave.iUnit) == 2)
		CheckRadioButton(hSetting, IDC_RADIO_AUTO, IDC_RADIO_MB, IDC_RADIO_MB);
	if (HIWORD(TraySave.iUnit) == 0)
		CheckRadioButton(hSetting, IDC_RADIO_BYTE, IDC_RADIO_BIT, IDC_RADIO_BYTE);
	else
		CheckRadioButton(hSetting, IDC_RADIO_BYTE, IDC_RADIO_BIT, IDC_RADIO_BIT);
	CheckDlgButton(hSetting, IDC_CHECK_TRAYICON, TraySave.bTrayIcon);
	CheckDlgButton(hSetting, IDC_CHECK_MONITOR, TraySave.bMonitor);
	CheckDlgButton(hSetting, IDC_CHECK_TRAFFIC, TraySave.bMonitorTraffic);
	CheckDlgButton(hSetting, IDC_CHECK_TEMPERATURE, TraySave.bMonitorTemperature);
	CheckDlgButton(hSetting, IDC_CHECK_USAGE, TraySave.bMonitorUsage);
	CheckDlgButton(hSetting, IDC_CHECK_SOUND, TraySave.bSound);
	CheckDlgButton(hSetting, IDC_CHECK_MONITOR_PDH, TraySave.bMonitorPDH);
	CheckDlgButton(hSetting, IDC_CHECK_MONITOR_SIMPLE, TraySave.iMonitorSimple);
	CheckDlgButton(hSetting, IDC_CHECK_MONITOR_LEFT, TraySave.bMonitorLeft);
	CheckDlgButton(hSetting, IDC_CHECK_MONITOR_FLOAT, TraySave.bMonitorFloat);
	CheckDlgButton(hSetting, IDC_CHECK_TRANSPARENT, TraySave.bMonitorTransparent);
	CheckDlgButton(hSetting, IDC_CHECK_TIPS, TraySave.bMonitorTips);
	SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETRANGE, 0, MAKELPARAM(0, 255));
	SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETPOS, TRUE, TraySave.bAlpha[iProject]);
	SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETRANGE, 0, MAKELPARAM(0, 255));
	BYTE bAlphaB = TraySave.dAlphaColor[iProject] >> 24;
	SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETPOS, TRUE, bAlphaB);
	SendDlgItemMessage(hSetting, IDC_CHECK_AUTORUN, BM_SETCHECK, AutoRun(FALSE, FALSE), NULL);
	bSettingInit = TRUE;
	SetDlgItemInt(hSetting, IDC_EDIT1, TraySave.dNumValues[0] / 1048576, 0);
	SetDlgItemInt(hSetting, IDC_EDIT2, TraySave.dNumValues[1] / 1048576, 0);
	SetDlgItemInt(hSetting, IDC_EDIT3, TraySave.dNumValues[2], 0);
	SetDlgItemInt(hSetting, IDC_EDIT4, TraySave.dNumValues[3], 0);
	SetDlgItemInt(hSetting, IDC_EDIT5, TraySave.dNumValues[4], 0);
	SetDlgItemInt(hSetting, IDC_EDIT6, TraySave.dNumValues[5], 0);
	SetDlgItemInt(hSetting, IDC_EDIT7, TraySave.dNumValues[6], 0);
	SetDlgItemInt(hSetting, IDC_EDIT8, TraySave.dNumValues[7], 0);
	SetDlgItemInt(hSetting, IDC_EDIT9, TraySave.dNumValues[8] / 1048576, 0);
	SetDlgItemInt(hSetting, IDC_EDIT10, TraySave.dNumValues[9], 0);
	SetDlgItemInt(hSetting, IDC_EDIT11, TraySave.dNumValues[10], 0);
	SetDlgItemInt(hSetting, IDC_EDIT12, TraySave.dNumValues[11], 0);
	SetDlgItemInt(hSetting, IDC_EDIT_TIME, TraySave.FlushTime, 0);
	SetDlgItemText(hSetting, IDC_EDIT14, TraySave.szTrafficOut);
	SetDlgItemText(hSetting, IDC_EDIT15, TraySave.szTrafficIn);
	SetDlgItemText(hSetting, IDC_EDIT16, TraySave.szTemperatureCPU);
	SetDlgItemText(hSetting, IDC_EDIT17, TraySave.szTemperatureGPU);
	SetDlgItemText(hSetting, IDC_EDIT18, TraySave.szTemperatureCPUUnit);
	SetDlgItemText(hSetting, IDC_EDIT19, TraySave.szTemperatureGPUUnit);
	SetDlgItemText(hSetting, IDC_EDIT20, TraySave.szUsageCPU);
	SetDlgItemText(hSetting, IDC_EDIT21, TraySave.szUsageMEM);
	SetDlgItemText(hSetting, IDC_EDIT22, TraySave.szUsageCPUUnit);
	SetDlgItemText(hSetting, IDC_EDIT23, TraySave.szUsageMEMUnit);
	bSettingInit = FALSE;
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_BACKGROUND), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_TRAFFIC_LOW), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_TRAFFIC_MEDIUM), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_TRAFFIC_HIGH), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_LOW), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_MEDUIM), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	oldColorButtonPoroc = (WNDPROC)SetWindowLongPtr(GetDlgItem(hSetting, IDC_BUTTON_COLOR_HIGH), GWLP_WNDPROC, (LONG_PTR)ColorButtonProc);
	ShowWindow(hSetting, SW_SHOW);
	UpdateWindow(hSetting);
	SetForegroundWindow(hSetting);
}
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
	

	if (lpCmdLine[0] == L'c')
	{
		CloseHandle(ShellExecute(NULL, L"open",L"control.exe", &lpCmdLine[1], NULL, SW_SHOW));
		return 0;
	}
	else if (lpCmdLine[0] == L'o')
	{
		CloseHandle(ShellExecute(NULL, L"open", &lpCmdLine[1], NULL, NULL, SW_SHOW));
		return 0;
	}
	if (IsUserAdmin())
	{
		Init();
		SERVICE_TABLE_ENTRY st[] =
		{
			{ szAppName, (LPSERVICE_MAIN_FUNCTION)ServiceMain},
			{ NULL, NULL }
		};
		if (_wcsicmp(lpCmdLine, L"/install") == 0)
		{
			InstallService();
			return 0;
		}
		else if (_wcsicmp(lpCmdLine, L"/uninstall") == 0)
		{
			UninstallService();
			return 0;
		}
		else if (_wcsicmp(lpCmdLine, L"/start") == 0)
		{
			ServiceCtrlStart();
			return 0;
		}
		else if (_wcsicmp(lpCmdLine, L"/stop") == 0)
		{
			ServiceCtrlStop();
			return 0;
		}
		if (ServiceRunState() != SERVICE_RUNNING)
		{
			if (IsServiceInstalled())
			{
				if (ServiceRunState() == SERVICE_STOPPED)
					ServiceCtrlStart();
				StartServiceCtrlDispatcher(st);
				return 0;
			}
		}
		ServiceCtrlStop();
	}	
	while (hTray == NULL)
	{
		hTray = FindWindow(szShellTray, NULL);
		if (hTray == NULL)
			Sleep(100);
	}
	hInst = hInstance; // 将实例句柄存储在全局变量中
	ReadReg();
/*
	typedef WINUSERAPI DWORD WINAPI RTLGETVERSION(PRTL_OSVERSIONINFOW  lpVersionInformation);
	rovi.dwOSVersionInfoSize = sizeof(rovi);
	RTLGETVERSION *RtlGetVersion = (RTLGETVERSION*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
	if (RtlGetVersion)
		RtlGetVersion(&rovi);
*/
	hMutex = CreateMutex(NULL, TRUE, L"_TrayS_");
	if (hMutex != NULL)
	{
		if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			CloseHandle(hMutex);
			if (FindWindow(NULL, szAppName))
				return 0;
			EnumWindows((WNDENUMPROC)FindWindowFunc, 0);
		}
		else
		{
			iMain = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TRAYS));			
			hDwmapi = LoadLibrary(L"dwmapi.dll");
			if (hDwmapi)
			{
				DwmGetWindowAttribute = (pfnDwmGetWindowAttribute)GetProcAddress(hDwmapi, "DwmGetWindowAttribute");
			}

			SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
			if(TraySave.bMonitorTemperature)
				LoadTemperatureDLL();
			pProcessTime = NULL;
			EnableDebugPrivilege(TRUE);
			SYSTEM_INFO si;
			GetSystemInfo(&si);
			dNumProcessor = si.dwNumberOfProcessors;
			ppmu[0] = &pmu[0];
			ppmu[1] = &pmu[1];
			ppmu[2] = &pmu[2];
			ppcu[0] = &pcu[0];
			ppcu[1] = &pcu[1];
			ppcu[2] = &pcu[2];
			// 执行应用程序初始化:
			if (!InitInstance(hInstance, nCmdShow))
			{
				return FALSE;
			}			
			MSG msg;
			// 主消息循环:
			while (GetMessage(&msg, nullptr, 0, 0))
			{
				if (!IsDialogMessage(hMain, &msg)&&!IsDialogMessage(hSetting,&msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			DestroyWindow(hTaskBar);
			DestroyWindow(hTaskTips);
			DestroyWindow(hMain);
			Shell_NotifyIcon(NIM_DELETE, &nid);
			DestroyIcon(iMain);
			DeleteObject(hFont);
			//free(ipinfo);
			FreeLibrary(hDwmapi);
			FreeLibrary(hIphlpapi);
			FreeLibrary(hOleacc);
			FreeLibrary(hPDH);
			free(mi);			
			free(piaa);
			free(traffic);
			if(hMutex)
				CloseHandle(hMutex);
			FreeTemperatureDLL();
		}
	}	
	
    // 初始化全局字符串
//   LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
//   LoadStringW(hInstance, IDC_TRAYS, szWindowClass, MAX_LOADSTRING);			
    return (int) 0;
}
//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hMain = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainProc);
   if (!hMain)
   {
      return FALSE;
   }
   ChangeWindowMessageFilter(WM_TRAYS, MSGFLT_ADD);
   //////////////////////////////////////////////////////////////////////////////////设置通知栏图标
   nid.cbSize = sizeof NOTIFYICONDATA;
   nid.uID = WM_IAWENTRAY;
   nid.hWnd = hMain;
   nid.hIcon = iMain;
   nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
   nid.uCallbackMessage = WM_IAWENTRAY;
   //			nid.dwInfoFlags = NIIF_INFO;
   LoadString(hInst, IDS_TIPS, nid.szTip, 88);
   if (TraySave.bTrayIcon)
	   ::Shell_NotifyIcon(NIM_ADD, &nid);

   MemoryStatusEx.dwLength = sizeof MEMORYSTATUSEX;
   ////////////////////////////////////////////////////////////当前DPI
   HDC hdc = GetDC(hMain);
   iDPI = GetDeviceCaps(hdc, LOGPIXELSY);
   ::ReleaseDC(hMain, hdc);
   if (TraySave.bMonitor)//创建任务信息窗口
   {
	   OpenTaskBar();
   }
   if (TraySave.aMode[0] != ACCENT_DISABLED || TraySave.aMode[1] != ACCENT_DISABLED)
	SetTimer(hMain, 3, TraySave.FlushTime, NULL);
   if(TraySave.iPos|| TraySave.bMonitor)
	   SetTimer(hMain, 6, 1000, NULL);
   SetTimer(hMain, 11, 6000, NULL);
//   ShowWindow(hMain,SW_SHOW);
   return TRUE;
}
BOOL Find(IAccessible* paccParent,int iRole,IAccessible** paccChild)//查找任务图标UI
{
	HRESULT hr;
	long numChildren;
	unsigned long numFetched;
	VARIANT varChild;
	int indexCount;
	IAccessible* pChild = NULL;
	IEnumVARIANT* pEnum = NULL;
	IDispatch* pDisp = NULL;
	BOOL found = false;
	//Get the IEnumVARIANT interface
	hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);
	if (pEnum)
		pEnum->Reset();
	// Get child count
	paccParent->get_accChildCount(&numChildren);
	for (indexCount = 1; indexCount <= numChildren && !found; indexCount++)
	{
		pChild = NULL;
		if (pEnum)
			hr = pEnum->Next(1, &varChild, &numFetched);
		else
		{
			varChild.vt = VT_I4;
			varChild.lVal = indexCount;
		}
		if (varChild.vt == VT_I4)
		{
			pDisp = NULL;
			hr = paccParent->get_accChild(varChild, &pDisp);
		}
		else
			pDisp = varChild.pdispVal;
		if (pDisp)
		{
			hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pChild);
			hr = pDisp->Release();
		}
		if (pChild)
		{
			VariantInit(&varChild);
			varChild.vt = VT_I4;
			varChild.lVal = CHILDID_SELF;
			*paccChild = pChild;
		}
		VARIANT varState;
		pChild->get_accState(varChild, &varState);
		if ((varState.intVal&STATE_SYSTEM_INVISIBLE) == 0)
		{
			VARIANT varRole;
			pChild->get_accRole(varChild, &varRole);
			if (varRole.lVal == iRole)
			{
				paccParent->Release();
				found = true;
				break;
			}
		}
		if (!found && pChild)
		{
//			found = Find(pCAcc, iRole, paccChild);
//			if (*paccChild != pCAcc)
			pChild->Release();
		}
	}
	if (pEnum)
		pEnum->Release();
	return found;
}
int oleft=0, otop=0;
void SetTaskBarPos(HWND hTaskListWnd,HWND hTrayWnd,HWND hTaskWnd,HWND hReBarWnd,BOOL bMainTray)//设置任务栏图标位置
{
	if (hOleacc == NULL)
	{
		hOleacc = LoadLibrary(L"oleacc.dll");
		if (hOleacc)
		{
			AccessibleObjectFromWindowT = (pfnAccessibleObjectFromWindow)GetProcAddress(hOleacc, "AccessibleObjectFromWindow");
			AccessibleChildrenT = (pfnAccessibleChildren)GetProcAddress(hOleacc, "AccessibleChildren");
		}
	}
	if (hOleacc == NULL)
		return;
	IAccessible *pAcc = NULL;
	AccessibleObjectFromWindowT(hTaskListWnd, OBJID_WINDOW, IID_IAccessible, (void**)&pAcc);
	IAccessible *paccChlid = NULL;
	if (pAcc)
	{
		if (Find(pAcc, 22, &paccChlid) == FALSE)
		{
			return;
		}
	}
	else
		return;
	long childCount;
	long returnCount;
	LONG left, top, width, height;
	LONG ol=0,ot=0;
	int tWidth = 0;
	int tHeight = 0;
	if (paccChlid)
	{
		if (paccChlid->get_accChildCount(&childCount) == S_OK && childCount != 0)
		{
			VARIANT *pArray = new VARIANT[childCount];
			if (AccessibleChildrenT(paccChlid, 0L, childCount, pArray, &returnCount) == S_OK)
			{
				for (int x = 0; x < returnCount; x++)
				{
					VARIANT vtChild = pArray[x];
					{
						
						VARIANT varState;						
						paccChlid->get_accState(vtChild, &varState);
						if ((varState.intVal&STATE_SYSTEM_INVISIBLE) == 0)
						{
							VARIANT varRole;
							paccChlid->get_accRole(vtChild, &varRole);
							if (varRole.intVal == 0x2b || varRole.intVal == 0x39)
							{
								paccChlid->accLocation(&left, &top, &width, &height, vtChild);
								if (ol != left)
								{
									tWidth += width;
									ol = left;
								}
								if (ot != top)
								{
									tHeight += height;
									ot = top;
								}
							}
						}
					}
				}
			}
			delete[] pArray;
		}
		paccChlid->Release();
	}
	else
		return;
	
	RECT lrc, src, trc;
	GetWindowRect(hTaskListWnd, &lrc);
	GetWindowRect(hTrayWnd, &src);
	GetWindowRect(hTaskWnd, &trc);
	BOOL Vertical = FALSE;
	if (src.right - src.left < src.bottom - src.top)
		Vertical = TRUE;
	SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
	int lr,tb;
	if (Vertical)
	{
		int t = trc.left - src.left;
		int b = src.bottom - trc.bottom;
		if (bMainTray&& TraySave.bMonitor&& TraySave.bMonitorFloat==FALSE)
		{
			if (TraySave.bMonitorLeft == FALSE)
				b += mHeight;
			else
				t += mHeight;
		}
		if (t > b)
			tb = t;
		else
			tb = b;
	}
	else
	{
		int l = trc.left - src.left;
		int r = src.right - trc.right;
		if (TraySave.bMonitor&&bMainTray&& TraySave.bMonitorFloat==FALSE)
		{
			if (TraySave.bMonitorLeft == FALSE)
				r += mWidth;
			else
				l += mWidth;
		}
		if (l > r)
			lr = l;
		else
			lr = r;
	}
	int nleft,ntop;
	if ((TraySave.iPos == 2 || (Vertical == FALSE&&tWidth >= trc.right - trc.left - lr ) || (Vertical&&tHeight >= trc.bottom - trc.top - tb))&& TraySave.iPos!=0)
	{
		if (Vertical)
		{
			ntop = trc.bottom - trc.top - tHeight;
			if (TraySave.bMonitorLeft == FALSE&& TraySave.bMonitor&&bMainTray&& TraySave.bMonitorFloat==FALSE)
				ntop -= mHeight+2;
		}
		else
		{
			nleft = trc.right - trc.left - tWidth;
			if (TraySave.bMonitorLeft == FALSE&& TraySave.bMonitor&&bMainTray&& TraySave.bMonitorFloat==FALSE)
				nleft -= mWidth+2;
		}		
	}
	else if (TraySave.iPos == 0)
	{
		if (TraySave.bMonitorLeft&& TraySave.bMonitor&&bMainTray&& TraySave.bMonitorFloat==FALSE)
		{
			nleft = mWidth;
			ntop = mHeight;
		}
		else
		{
			nleft = 0;
			ntop = 0;
			if (TraySave.bMonitor==FALSE)
			{
				KillTimer(hMain, 6);
				SetTimer(hMain, 11, 1000, NULL);
			}
		}
	}
	else if (TraySave.iPos == 1)
	{
		if (Vertical)
			ntop = src.top + (src.bottom - src.top) / 2 - trc.top  - tHeight / 2;
		else
			nleft= src.left + (src.right - src.left) / 2 - trc.left  - tWidth / 2;
		if (bMainTray)
		{
			if(Vertical)
				ntop -= 2;
			else
				nleft -= 2;
		}
	}
	if (Vertical)
	{
		if (bMainTray)
		{
			if (otop == 0)
				lrc.top = ntop;
			else
				lrc.top = otop;
			otop = ntop;
			while (ntop != lrc.top)
			{
				if (ntop > lrc.top)
					++lrc.top;
				else
					--lrc.top;
				SetWindowPos(hTaskListWnd, 0, 0, lrc.top, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
			}
		}
		SetWindowPos(hTaskListWnd, 0, 0, ntop, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	else
	{
		if (bMainTray)
		{
			if (oleft == 0)
				lrc.left = nleft;
			else
				lrc.left = oleft;
			oleft = nleft;
			while (nleft != lrc.left)
			{
				if (nleft > lrc.left)
					++lrc.left;
				else
					--lrc.left;
				SetWindowPos(hTaskListWnd, 0, lrc.left, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
			}
		}
		SetWindowPos(hTaskListWnd, 0, nleft, 0, lrc.right - lrc.left, lrc.bottom - lrc.top, SWP_NOSIZE | SWP_ASYNCWINDOWPOS | SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOSENDCHANGING);
	}
	if (TraySave.iPos != 0)
		SendMessage(hReBarWnd, WM_SETREDRAW, FALSE, 0);
	ShowWindow(hTaskWnd, SW_SHOWNOACTIVATE);
}
int otleft, ottop;
void SetWH()
{
	mWidth = 0;
	mHeight = 0;
	HDC mdc = GetDC(hMain);
	TraySave.TraybarFont.lfHeight = DPI(TraySave.TraybarFontSize);
	DeleteObject(hFont);
	hFont = CreateFontIndirect(&TraySave.TraybarFont); //创建字体
	HFONT oldFont = (HFONT)SelectObject(mdc, hFont);
	SIZE tSize;
	WCHAR sz[16];
	if (TraySave.bMonitorTraffic)
	{
		if (TraySave.iMonitorSimple == 1)
			::GetTextExtentPoint(mdc, L"↓:8.88M", wcslen(L"↓:8.88M"), &tSize);
		else if (TraySave.iMonitorSimple == 2)
			::GetTextExtentPoint(mdc, L"8.88M", wcslen(L"8.88M"), &tSize);
		else
		{
			swprintf_s(sz, 16, L"%s8.88M", TraySave.szTrafficOut);
			::GetTextExtentPoint(mdc, sz, wcslen(sz), &tSize);
		}
		wTraffic = tSize.cx + tSize.cy/4;
		mWidth += wTraffic;
		mHeight += tSize.cy * 2;
		wHeight = tSize.cy;
	}
	if (TraySave.bMonitorTemperature)
	{
		if (TraySave.iMonitorSimple == 1)
			::GetTextExtentPoint(mdc, L"88℃", wcslen(L"88℃"), &tSize);
		else if (TraySave.iMonitorSimple == 2)
			::GetTextExtentPoint(mdc, L"88", wcslen(L"88"), &tSize);
		else
		{
			swprintf_s(sz, 16, L"%s88%s", TraySave.szTemperatureGPU,TraySave.szTemperatureGPUUnit);
			::GetTextExtentPoint(mdc, sz, wcslen(sz), &tSize);
		}
		wTemperature = tSize.cx + tSize.cy / 4;
		mWidth += wTemperature;
		wHeight = tSize.cy;
		if (bRing0)
			mHeight += tSize.cy * 2;
		else
			mHeight += tSize.cy;
	}
	if (TraySave.bMonitorUsage)
	{
		if (TraySave.iMonitorSimple == 1)
			::GetTextExtentPoint(mdc, L"88%", wcslen(L"88%"), &tSize);
		else if (TraySave.iMonitorSimple == 2)
			::GetTextExtentPoint(mdc, L"88", wcslen(L"88"), &tSize);
		else
		{
			swprintf_s(sz, 16, L"%s88%s", TraySave.szUsageMEM, TraySave.szUsageMEMUnit);
			::GetTextExtentPoint(mdc, sz, wcslen(sz), &tSize);
		}
		wUsage = tSize.cx+ tSize.cy / 4;
		mWidth += wUsage;
		wHeight = tSize.cy;
		mHeight += tSize.cy * 2;
	}
	SelectObject(mdc, oldFont);
	ReleaseDC(hMain, mdc);
	ottop = -1;
	otleft = -1;
	AdjustWindowPos();
}
void AdjustWindowPos()//设置信息窗口位置大小
{	
	if (IsWindow(hTaskBar) == FALSE)
		OpenTaskBar();
	if (TraySave.bMonitorFloat)
	{
		RECT ScreenRect;
		GetScreenRect(hTaskBar, &ScreenRect, FALSE);
		if (TraySave.dMonitorPoint.x + mWidth > ScreenRect.right)
			TraySave.dMonitorPoint.x = ScreenRect.right - mWidth;
		if (TraySave.dMonitorPoint.y + wHeight*2 > ScreenRect.bottom)
			TraySave.dMonitorPoint.y = ScreenRect.bottom - wHeight * 2;
		SetWindowPos(hTaskBar, HWND_TOPMOST, TraySave.dMonitorPoint.x, TraySave.dMonitorPoint.y, mWidth, wHeight * 2, SWP_NOACTIVATE);
		VTray = FALSE;
		return;
	}
	RECT rrc,trc;
	GetWindowRect(hReBarWnd, &rrc);
	GetWindowRect(hTaskWnd, &trc);	
	if (rrc.right - rrc.left > rrc.bottom - rrc.top)
		VTray = FALSE;
	else
		VTray = TRUE;
	if(VTray==FALSE)
	{		
		int nleft;
		if (TraySave.bMonitorLeft)
			nleft = trc.left - rrc.left;
		else
			nleft = trc.right - trc.left - mWidth + (trc.left - rrc.left);
		int h = wHeight*2;
		int ntop;
		BOOL sTray = FALSE;
		if (rrc.bottom - rrc.top < h)
		{
			sTray = TRUE;
			h = rrc.bottom - rrc.top - 2;
			ntop = 1;
		}
		else
			ntop = (trc.bottom - trc.top - h) / 2;
		if (nleft != otleft||ottop!=ntop)
		{
			HDC hdc = GetDC(hTaskBar);
			RECT crc;
			GetClientRect(hTaskBar, &crc);
			HBRUSH hb = CreateSolidBrush(RGB(0, 0, 0));
			FillRect(hdc, &crc, hb);
			DeleteObject(hb);
			ReleaseDC(hTaskBar, hdc);
			otleft = nleft;
			ottop = ntop;
			MoveWindow(hTaskBar, nleft,ntop, mWidth, h, FALSE);
		}
	}
	else
	{
		int ntop;		
		if (TraySave.bMonitorLeft)
			ntop = trc.top - rrc.top;
		else
			ntop = trc.bottom - trc.top - mHeight + (trc.top - rrc.top);
		int nleft = 2;
		int w = trc.right - trc.left - 4;
		if (ntop != ottop||otleft!=w)
		{
			HDC hdc = GetDC(hTaskBar);
			RECT crc;
			GetClientRect(hTaskBar, &crc);
			HBRUSH hb = CreateSolidBrush(RGB(0, 0, 0));
			FillRect(hdc, &crc, hb);
			DeleteObject(hb);
			ReleaseDC(hTaskBar, hdc);
			ottop = ntop;
			otleft = w;
			MoveWindow(hTaskBar, nleft, ntop, w, mHeight, FALSE);
		}
	}
}
DWORD dwIPSize = 0;
DWORD dwMISize = 0;
INT_PTR CALLBACK TaskTipsProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)//提示信息窗口过程
{
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_MOUSEMOVE:
	{
		POINT pt;
		pt.x= GET_X_LPARAM(lParam);
		pt.y= GET_Y_LPARAM(lParam);
		RECT rc;
		GetClientRect(hDlg, &rc);
		rc.top = nTraffic * wTipsHeight;
		rc.bottom = (nTraffic+6) * wTipsHeight;
		rc.left = rc.right * 100 / 160;
		rc.right = rc.right * 100 / 148;
		if (PtInRect(&rc, pt))
		{
			inTipsProcessX = TRUE;
			::InvalidateRect(hDlg, NULL, TRUE);
		}
		else
		{
			inTipsProcessX = FALSE;
		}
	}
		break;
	case WM_LBUTTONDOWN:
	{
		POINT pt;
		pt.x = GET_X_LPARAM(lParam);
		pt.y = GET_Y_LPARAM(lParam);
		if(pt.y<nTraffic* wTipsHeight)
			RunProcess(szNetCpl);
		else if (pt.y < (nTraffic + 6) * wTipsHeight)
		{
			RECT rc;
			GetClientRect(hDlg, &rc);
			rc.left = rc.right * 100 / 160;
			rc.right = rc.right * 100 / 148;
			if (PtInRect(&rc, pt))
			{
				int x=(pt.y / wTipsHeight) - nTraffic;
				DWORD pid;
				if (x < 3)
					pid=ppcu[x]->dwProcessID;
				else
					pid=ppmu[x-3]->dwProcessID;
				HANDLE hProc= OpenProcess(PROCESS_TERMINATE, FALSE, pid);
				if (hProc)
				{
					TerminateProcess(hProc, 0);
					CloseHandle(hProc);
					inTipsProcessX = FALSE;
					GetCursorPos(&pt);
					SetCursorPos(pt.x + 88, pt.y);
				}
			}
			else
				RunProcess(szTaskmgr);
		}
		else
			RunProcess(szPowerCpl);
		return TRUE;
	}
		break;
	case WM_MOUSELEAVE:
	{
		POINT pt;
		GetCursorPos(&pt);
		if (WindowFromPoint(pt) != hTaskBar)
		{
			if (pProcessTime != NULL)
			{
				delete[]pProcessTime;
				pProcessTime = NULL;
			}
			ShowWindow(hTaskTips, SW_HIDE);
			SetTimer(hMain, 11, 1000, NULL);
		}
	}
		break;
	case WM_ERASEBKGND:
		HDC hdc = (HDC)wParam;//BeginPaint(hDlg, &ps);
		RECT rc,crc;
		GetClientRect(hDlg, &rc);
		crc = rc;
		HDC mdc = CreateCompatibleDC(hdc);
		HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, rc.right - rc.left, rc.bottom - rc.top);
		HBITMAP oldBmp = (HBITMAP)SelectObject(mdc, hMemBmp);
//		if (bErasebkgnd)
		{
			TraySave.TipsFont.lfHeight = TraySave.TipsFontSize;
			HFONT hTipsFont = CreateFontIndirect(&TraySave.TipsFont); //创建字体
			HFONT oldFont = (HFONT)SelectObject(mdc, hTipsFont);
			WCHAR sz[64];
			SetBkMode(mdc, TRANSPARENT);
			COLORREF rgb;
			rgb = RGB(192, 192, 192);
			SetTextColor(mdc, rgb);
			rc.bottom = wTipsHeight;
			HBRUSH hb= CreateSolidBrush(RGB(22, 22, 22));
			for (int i=0;i<nTraffic/2+4;i++)
			{
				FillRect(mdc, &rc, hb);
				OffsetRect(&rc, 0, wTipsHeight * 2);
			}
			DeleteObject(hb);
			HPEN hp = CreatePen(PS_DOT, 1, RGB(98, 98, 98));
			HPEN oldpen=(HPEN)SelectObject(mdc,hp);
			MoveToEx(mdc, crc.right*10/23,0,NULL);
			LineTo(mdc, crc.right*10/23, wTipsHeight *nTraffic);
			MoveToEx(mdc, crc.right*7/10, 0, NULL);
			LineTo(mdc, crc.right*7/10, wTipsHeight *nTraffic);
			MoveToEx(mdc, crc.right*85/100, 0, NULL);			
			LineTo(mdc, crc.right*85/100, wTipsHeight * nTraffic);

			MoveToEx(mdc, crc.right*100/124, wTipsHeight * nTraffic, NULL);
			LineTo(mdc, crc.right*100/124, wTipsHeight * (nTraffic+6));
			MoveToEx(mdc, crc.right*100/148, wTipsHeight * nTraffic, NULL);
			LineTo(mdc, crc.right*100/148, wTipsHeight * (nTraffic + 6));
			MoveToEx(mdc, crc.right*100/160, wTipsHeight * nTraffic, NULL);
			LineTo(mdc, crc.right*100/160, wTipsHeight * (nTraffic + 6));
			MoveToEx(mdc, 0, wTipsHeight * nTraffic, NULL);
			LineTo(mdc, crc.right, wTipsHeight * nTraffic);
			MoveToEx(mdc, 0, wTipsHeight * (nTraffic+3), NULL);
			LineTo(mdc, crc.right, wTipsHeight * (nTraffic+3));
			MoveToEx(mdc, 0, wTipsHeight * (nTraffic + 6), NULL);
			LineTo(mdc, crc.right, wTipsHeight * (nTraffic + 6));
			SelectObject(mdc,oldpen);
			DeleteObject(hp);
			rc.bottom = wTipsHeight;
			rc.top = 0;
//			OffsetRect(&rc, 0, DPI(16)*3);
			//PIP_ADAPTER_INFO pai = &ipinfo[0];
//			PIP_ADAPTER_ADDRESSES paa = &piaa[0];
			for (int i = 0; i < nTraffic; i++)
			{
				rc.left = 2;				
				DrawText(mdc, traffic[i].FriendlyName, (int)wcslen(traffic[i].FriendlyName), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				rc.left = crc.right*10/23;
				rc.right = crc.right*7/10;
				DrawText(mdc, traffic[i].IP4, (int)wcslen(traffic[i].IP4), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);				
				float f_in_byte = (float)traffic[i].in_byte;
				if (traffic[i].in_byte < 1000)
					swprintf_s(sz, 16, L"↓:%db", traffic[i].in_byte);
				else if (traffic[i].in_byte < 1000000)
				{
					f_in_byte /= 1000;
					if (f_in_byte >= 100)
						swprintf_s(sz, 16, L"↓:%.fk", f_in_byte);
					else if (f_in_byte >= 10)
						swprintf_s(sz, 16, L"↓:%.1fk", f_in_byte);
					else
						swprintf_s(sz, 16, L"↓:%.2fk", f_in_byte);
				}
				else if (traffic[i].in_byte < 1000000000)
				{
					f_in_byte /= 1000000;
					if (f_in_byte >= 100)
						swprintf_s(sz, 16, L"↓:%.fm", f_in_byte);
					else if (f_in_byte >= 10)
						swprintf_s(sz, 16, L"↓:%.1fm", f_in_byte);
					else
						swprintf_s(sz, 16, L"↓:%.2fm", f_in_byte);
				}
				else
				{
					f_in_byte /= 1000000000;
					if (f_in_byte >= 100)
						swprintf_s(sz, 16, L"↓:%.fG", f_in_byte);
					else if (f_in_byte >= 10)
						swprintf_s(sz, 16, L"↓:%.1fG", f_in_byte);
					else
						swprintf_s(sz, 16, L"↓:%.2fG", f_in_byte);
				}
				rc.left = crc.right*7/10+2;
				rc.right += crc.right;				
				DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				float f_out_byte = (float)traffic[i].out_byte;
				if (traffic[i].out_byte < 1000)
					swprintf_s(sz, 16, L"↑:%db", traffic[i].out_byte);
				else if (traffic[i].out_byte < 1000000)
				{
					f_out_byte /= 1000;
					if (f_out_byte >= 100)
						swprintf_s(sz, 16, L"↑:%.fk", f_out_byte);
					else if (f_out_byte >= 10)
						swprintf_s(sz, 16, L"↑:%.1fk", f_out_byte);
					else
						swprintf_s(sz, 16, L"↑:%.2fk", f_out_byte);
				}
				else if (traffic[i].out_byte < 1000000000)
				{
					f_out_byte /= 1000000;
					if (f_out_byte >= 100)
						swprintf_s(sz, 16, L"↑:%.fm", f_out_byte);
					else if (f_out_byte >= 10)
						swprintf_s(sz, 16, L"↑:%.1fm", f_out_byte);
					else
						swprintf_s(sz, 16, L"↑:%.2fm", f_out_byte);
				}
				else
				{
					f_out_byte /= 1000000000;
					if (f_out_byte >= 100)
						swprintf_s(sz, 16, L"↑:%.fg", f_out_byte);
					else if (f_out_byte >= 10)
						swprintf_s(sz, 16, L"↑:%.1fg", f_out_byte);
					else
						swprintf_s(sz, 16, L"↑:%.2fg", f_out_byte);
				}
				rc.left = crc.right * 85 / 100+2;
				DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				OffsetRect(&rc, 0, wTipsHeight);
			}
			rc.left = 2;
			rc.right = crc.right-2;
			POINT pt;
			GetCursorPos(&pt);
			ScreenToClient(hDlg, &pt);
			for (int i = 0; i < 3; i++)
			{
				SetTextColor(mdc, RGB(192, 192, 0));
				DrawText(mdc, ppcu[i]->szExe, (int)wcslen(ppcu[i]->szExe), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				swprintf_s(sz, 16, L"%.2f%%", ppcu[i]->fCpuUsage);
				DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
				RECT cr = rc;
				cr.left = crc.right*100/148;
				cr.right = crc.right*8/10;
				swprintf_s(sz, 16, L"%d", ppcu[i]->dwProcessID);
				DrawText(mdc, sz, (int)wcslen(sz), &cr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
				cr.left = crc.right * 100 / 160;
				cr.right = crc.right * 100 / 148;
				if(PtInRect(&cr, pt))
					SetTextColor(mdc, RGB(255, 255, 255));					
				DrawText(mdc, L"X", 1, &cr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);				
				OffsetRect(&rc, 0, wTipsHeight);
			}
			for (int i = 0; i < 3; i++)
			{
				SetTextColor(mdc, RGB(0, 192, 192));
				DrawText(mdc, ppmu[i]->szExe, (int)wcslen(ppmu[i]->szExe), &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				float fMemUsage = (float)ppmu[i]->dwMemUsage;
				if (fMemUsage >= 1048576000)
				{
					fMemUsage /= 1073741824;
					swprintf_s(sz, 16, L"%.2fGB", fMemUsage);
				}
				else
				{
					fMemUsage /= 1048576;
					swprintf_s(sz, 16, L"%.2fMB", fMemUsage);
				}				
				DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
				RECT cr = rc;
				cr.left = crc.right*100/148;
				cr.right = crc.right*8/10;
				swprintf_s(sz, 16, L"%d", ppmu[i]->dwProcessID);
				DrawText(mdc, sz, (int)wcslen(sz), &cr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
				cr.left = crc.right * 100 / 160;
				cr.right = crc.right * 100 / 148;
				if (PtInRect(&cr, pt))
					SetTextColor(mdc, RGB(255, 255, 255));
				DrawText(mdc, L"X", 1, &cr, DT_CENTER | DT_VCENTER | DT_SINGLELINE);				
				OffsetRect(&rc, 0, wTipsHeight);
			}
			SetTextColor(mdc, RGB(192, 192, 192));
/*
			HBRUSH hb;
			hb=CreateSolidBrush(RGB(0,38,0));
			FillRect(mdc, &rc, hb);
			DeleteObject(hb);
*/
			rc.left = 2;
			rc.right -= 2;
			PROCESSOR_POWER_INFORMATION *pi = new PROCESSOR_POWER_INFORMATION[dNumProcessor];			
			if (CallNtPowerInformation(ProcessorInformation, NULL, 0, &pi[0], sizeof PROCESSOR_POWER_INFORMATION * dNumProcessor) == 0)
			{
				swprintf_s(sz, 63, L"%d个逻辑处理器 当前频率%.2fGHz 最大频率%.2fGHz", dNumProcessor, ((float)pi[0].CurrentMhz) / 1000, ((float)pi[0].MaxMhz) / 1000);
			}
			delete[]pi;
			DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
			OffsetRect(&rc, 0, wTipsHeight);
			float availPage,totalPage,avail, total;
			availPage = (float)MemoryStatusEx.ullAvailPageFile;
			availPage/= 1073741824;
			totalPage = (float)MemoryStatusEx.ullTotalPageFile;
			totalPage/= 1073741824;
			avail = (float)MemoryStatusEx.ullAvailPhys;
			avail/= 1073741824;
			total = (float)MemoryStatusEx.ullTotalPhys;
			total /= 1073741824;
			swprintf_s(sz, 63, L"虚拟内存:%.2f/%.2fGB,可用内存:%.2f/%.2fGB",availPage,totalPage, avail,total);
			DrawText(mdc, sz, (int)wcslen(sz), &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
			DeleteObject(hTipsFont);
			SelectObject(mdc, oldFont);
		}
		GetClientRect(hDlg, &rc);
		BitBlt(hdc, 0, 0, rc.right - rc.left, rc.bottom - rc.top, mdc, 0, 0, SRCCOPY);
		SelectObject(mdc, oldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(mdc);
		return TRUE;
		break;
	}
	return (INT_PTR)FALSE;
}
int GetScreenRect(HWND hWnd, LPRECT lpRect, BOOL bTray)//获取窗口所在的屏幕大小可减去任务栏
{
	HMONITOR hMon = MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST);
	MONITORINFO mi;
	mi.cbSize = sizeof mi;
	GetMonitorInfo(hMon, &mi);
	if (bTray)
	{
		RECT TrayRect;
		if (mi.rcMonitor.left == 0 && mi.rcMonitor.top == 0)
		{
			HWND hTrayWnd = ::FindWindow(szShellTray, NULL);
			GetWindowRect(hTrayWnd, &TrayRect);
		}
		else
		{
			HWND hSecondaryTray;
			hSecondaryTray = FindWindow(szSecondaryTray, NULL);
			while (hSecondaryTray)
			{
				GetWindowRect(hSecondaryTray, &TrayRect);
				POINT pt;
				pt.x = TrayRect.left;
				pt.y = TrayRect.top;
				if (PtInRect(lpRect, pt))
					break;
				hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
			}
		}
		RECT dRect;
		SubtractRect(&dRect, &mi.rcMonitor, &TrayRect);
		CopyRect(lpRect, &dRect);
	}
	else
		CopyRect(lpRect, &mi.rcMonitor);
	return 0;
}
void GetProcessCpuUsage()//获取进程CPU占用前三
{
	if(!inTipsProcessX)
	{
		ppcu[0] = &pcu[0];
		ppcu[1] = &pcu[1];
		ppcu[2] = &pcu[2];
		ZeroMemory(pcu, sizeof pcu);
		pcu[0].fCpuUsage = 0;
		pcu[1].fCpuUsage = 0;
		pcu[2].fCpuUsage = 0;
	}
	DWORD dCurID = GetCurrentProcessId();
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	HANDLE hs = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hs != INVALID_HANDLE_VALUE)
	{
		BOOL ret = Process32First(hs, &pe);
		while (ret)
		{
			if (pe.th32ProcessID != dCurID)
			{
				HANDLE hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
				if (hProc)
				{
					int n = -1;
					for (int i = 0; i < nProcess+31; i++)
					{
						if (pProcessTime[i].dwProcessID == pe.th32ProcessID)
						{
							n = i;
							break;
						}
						else if (n == -1 && pProcessTime[i].dwProcessID == NULL)
							n = i;
					}
					FILETIME CreateTime, ExitTime, KernelTime, UserTime;
					if (GetProcessTimes(hProc, &CreateTime, &ExitTime, &KernelTime, &UserTime))
					{
						float nProcCpuPercent = 0;
						BOOL bRetCode = FALSE;
						FILETIME CreateTime, ExitTime, KernelTime, UserTime;
						LARGE_INTEGER lgKernelTime;
						LARGE_INTEGER lgUserTime;
						LARGE_INTEGER lgCurTime;

						bRetCode = GetProcessTimes(hProc, &CreateTime, &ExitTime, &KernelTime, &UserTime);
						if (bRetCode)
						{
							lgKernelTime.HighPart = KernelTime.dwHighDateTime;
							lgKernelTime.LowPart = KernelTime.dwLowDateTime;

							lgUserTime.HighPart = UserTime.dwHighDateTime;
							lgUserTime.LowPart = UserTime.dwLowDateTime;

							lgCurTime.QuadPart = (lgKernelTime.QuadPart + lgUserTime.QuadPart) / 10000;
							if (pProcessTime[n].g_slgProcessTimeOld.QuadPart == 0)
								nProcCpuPercent = 0;
							else
								nProcCpuPercent = (float)((lgCurTime.QuadPart - pProcessTime[n].g_slgProcessTimeOld.QuadPart) * 100 / 1000);
							pProcessTime[n].g_slgProcessTimeOld = lgCurTime;
							pProcessTime[n].dwProcessID = pe.th32ProcessID;
							nProcCpuPercent = nProcCpuPercent / dNumProcessor;
						}
						else
						{
							nProcCpuPercent = 0;
						}
						if (nProcCpuPercent > 100)
							nProcCpuPercent = 0;
						if (!inTipsProcessX)
						{
							PROCESSCPUUSAGE* ppc;
							if (ppcu[0]->fCpuUsage <= nProcCpuPercent)
							{
								ppc = ppcu[2];
								ppcu[2] = ppcu[1];
								ppcu[1] = ppcu[0];
								ppcu[0] = ppc;
								ppcu[0]->dwProcessID = pe.th32ProcessID;
								ppcu[0]->fCpuUsage = nProcCpuPercent;
								wcsncpy_s(ppcu[0]->szExe, 25, pe.szExeFile, 24);
							}
							else if (ppcu[1]->fCpuUsage <= nProcCpuPercent)
							{
								ppc = ppcu[2];
								ppcu[2] = ppcu[1];
								ppcu[1] = ppc;
								ppcu[1]->dwProcessID = pe.th32ProcessID;
								ppcu[1]->fCpuUsage = nProcCpuPercent;
								wcsncpy_s(ppcu[1]->szExe, 25, pe.szExeFile, 24);
							}
							else if (ppcu[2]->fCpuUsage <= nProcCpuPercent)
							{
								ppcu[2]->dwProcessID = pe.th32ProcessID;
								ppcu[2]->fCpuUsage = nProcCpuPercent;
								wcsncpy_s(ppcu[2]->szExe, 25, pe.szExeFile, 24);
							}
						}
					}
					CloseHandle(hProc);
				}
			}
			ret = Process32Next(hs, &pe);
		}
		CloseHandle(hs);
	}

}
int GetProcessMemUsage()//获取进程内存占用前三
{
	if(!inTipsProcessX)
	{
		ppmu[0] = &pmu[0];
		ppmu[1] = &pmu[1];
		ppmu[2] = &pmu[2];
		ZeroMemory(pmu, sizeof pmu);
		pmu[0].dwMemUsage = 0;
		pmu[1].dwMemUsage = 0;
		pmu[2].dwMemUsage = 0;
	}
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	int n = 0;
	HANDLE hs = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hs != INVALID_HANDLE_VALUE)
	{
		BOOL ret = Process32First(hs, &pe);		
		while (ret)
		{
			++n;			
			if (wcscmp(pe.szExeFile, L"Memory Compression") != 0&& !inTipsProcessX)
			{
				HANDLE hProc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
				if (hProc)
				{
					PROCESS_MEMORY_COUNTERS_EX pmc;
					if (GetProcessMemoryInfo(hProc, (PPROCESS_MEMORY_COUNTERS)&pmc, sizeof(pmc)))
					{
						//QueryWorkingSet()
						PROCESSMEMORYUSAGE* ppm;
						if (ppmu[0]->dwMemUsage <= pmc.WorkingSetSize)
						{
							ppm = ppmu[2];
							ppmu[2] = ppmu[1];
							ppmu[1] = ppmu[0];
							ppmu[0] = ppm;
							ppmu[0]->dwProcessID = pe.th32ProcessID;
							ppmu[0]->dwMemUsage = pmc.WorkingSetSize;
							wcsncpy_s(ppmu[0]->szExe, 25, pe.szExeFile, 24);

						}
						else if (ppmu[1]->dwMemUsage <= pmc.WorkingSetSize)
						{
							ppm = ppmu[2];
							ppmu[2] = ppmu[1];
							ppmu[1] = ppm;
							ppmu[1]->dwProcessID = pe.th32ProcessID;
							ppmu[1]->dwMemUsage = pmc.WorkingSetSize;
							wcsncpy_s(ppmu[1]->szExe, 25, pe.szExeFile, 24);
						}
						else if (ppmu[2]->dwMemUsage <= pmc.WorkingSetSize)
						{
							ppmu[2]->dwProcessID = pe.th32ProcessID;
							ppmu[2]->dwMemUsage = pmc.WorkingSetSize;
							wcsncpy_s(ppmu[2]->szExe, 25, pe.szExeFile, 24);
						}
					}
					CloseHandle(hProc);
				}
			}
			ret = Process32Next(hs, &pe);
		}
		CloseHandle(hs);
	}
	return n;
}
void DrawTraffic(HDC mdc, LPRECT lpRect, DWORD dwByte,BOOL bInOut)
{
	WCHAR szInS[] = L"↓:";
	WCHAR szInS2[] = L"";
	WCHAR szOutS[] = L"↑:";
	WCHAR szOutS2[] = L"";
	WCHAR *szT;
	if (bInOut)
	{
		if (TraySave.iMonitorSimple == 1)
			szT = szInS;
		else if (TraySave.iMonitorSimple == 2)
			szT = szInS2;
		else
			szT = TraySave.szTrafficIn;
	}
	else
	{
		if (TraySave.iMonitorSimple == 1)
			szT = szOutS;
		else if (TraySave.iMonitorSimple == 2)
			szT = szOutS2;
		else
			szT = TraySave.szTrafficOut;
	}
	WCHAR sz[24];
	COLORREF rgb;
	if (dwByte < TraySave.dNumValues[0])
		rgb = TraySave.cMonitorColor[1];
	else if (dwByte < TraySave.dNumValues[1])
		rgb = TraySave.cMonitorColor[2];
	else
		rgb = TraySave.cMonitorColor[3];
	SetTextColor(mdc, rgb);
	if (HIWORD(TraySave.iUnit))
		dwByte *= 8;
	float f_byte = (float)dwByte;
	if (dwByte < 1000&&LOWORD(TraySave.iUnit)==0)
		swprintf_s(sz, 16, L"%s%dB", szT, dwByte);
	else if ((dwByte < 1024000||(dwByte<1000000&& HIWORD(TraySave.iUnit)))&& LOWORD(TraySave.iUnit) !=2)
	{
		if (HIWORD(TraySave.iUnit))
			f_byte /= 1000;
		else
			f_byte /= 1024;
		if (f_byte >= 100)
			swprintf_s(sz, 16, L"%s%.fK",szT, f_byte);
		else if (f_byte >= 10)
			swprintf_s(sz, 16, L"%s%.1fK",szT, f_byte);
		else
			swprintf_s(sz, 16, L"%s%.2fK",szT, f_byte);
	}
	else if (dwByte < 1048576000||(dwByte<1000000000&&HIWORD(TraySave.iUnit)))
	{
		if (HIWORD(TraySave.iUnit))
			f_byte /= 1000000;
		else
			f_byte /= 1048576;
		if (f_byte >= 100)
			swprintf_s(sz, 16, L"%s%.fM",szT, f_byte);
		else if (f_byte >= 10)
			swprintf_s(sz, 16, L"%s%.1fM", szT, f_byte);
		else
			swprintf_s(sz, 16, L"%s%.2fM", szT, f_byte);
	}
	else
	{
		if (HIWORD(TraySave.iUnit))
			f_byte /= 1000000000;
		else
			f_byte /= 1073741824;
		if (f_byte >= 100)
			swprintf_s(sz, 16, L"%s%.fG", szT, f_byte);
		else if (f_byte >= 10)
			swprintf_s(sz, 16, L"%s%.1fG", szT, f_byte);
		else
			swprintf_s(sz, 16, L"%s%.2fG", szT, f_byte);
	}
	if (HIWORD(TraySave.iUnit))
		_wcslwr_s(sz,16);
	if(VTray)
		DrawText(mdc, sz, (int)wcslen(sz), lpRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	else
		DrawText(mdc, sz, (int)wcslen(sz), lpRect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}
BOOL bEvent = FALSE;//
int iGetAddressTime=10;//10秒一次获取网卡信息
INT_PTR CALLBACK TaskBarProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)//任务栏信息窗口过程
{
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		if (LOWORD(wParam) >= IDC_SELECT_ALL && LOWORD(wParam) <= IDC_SELECT_ALL+99)
		{
			if (LOWORD(wParam) == IDC_SELECT_ALL)
				TraySave.AdpterName[0] = L'\0';
			else
			{
				int x = LOWORD(wParam) - IDC_SELECT_ALL;
				PIP_ADAPTER_ADDRESSES paa;
				paa = &piaa[0];
				int n = 1;
				while (paa)
				{
					if (paa->IfType != IF_TYPE_SOFTWARE_LOOPBACK && paa->IfType != IF_TYPE_TUNNEL)
					{
						if (n == x)
						{
							strncpy_s(TraySave.AdpterName,39, paa->AdapterName, 38);
							break;
						}
						n++;
					}
					paa = paa->Next;
				}
			}
			WriteReg();
			m_last_in_bytes = 0;
			m_last_out_bytes = 0;
			s_in_byte = 0;
			s_out_byte = 0;
		}
		break;
	case WM_MOUSEMOVE:
		if (bEvent==FALSE&&TraySave.bMonitorTips)
		{
			TRACKMOUSEEVENT csTME;
			csTME.cbSize = sizeof(csTME);
			csTME.dwFlags = TME_LEAVE | TME_HOVER;
			csTME.hwndTrack = hTaskBar;// 指定要 追踪 的窗口
			csTME.dwHoverTime = 300;  // 鼠标在按钮上停留超过 10ms ，才认为状态为 HOVER
			TrackMouseEvent(&csTME);
			bEvent = TRUE;
		}
		break;
	case WM_MOUSEHOVER:
	{
		if (!IsWindowVisible(hTaskTips))
		{
			if (!IsWindow(hTaskTips))
			{
				hTaskTips = ::CreateDialog(hInst, MAKEINTRESOURCE(IDD_TIPS), NULL, (DLGPROC)TaskTipsProc);
				SetLayeredWindowAttributes(hTaskTips, 0, 255, LWA_ALPHA);
			}
			nProcess = GetProcessMemUsage();
			if (pProcessTime == NULL)
			{
				pProcessTime = new PROCESSTIME[nProcess + 32];
				ZeroMemory(pProcessTime, sizeof(PROCESSTIME)*(nProcess + 32));
			}
			GetProcessCpuUsage();
			HDC mdc = GetDC(hMain);
			TraySave.TipsFont.lfHeight = DPI(TraySave.TipsFontSize);
			HFONT hTipsFont = CreateFontIndirect(&TraySave.TipsFont); //创建字体
			HFONT oldFont = (HFONT)SelectObject(mdc, hTipsFont);
			SIZE tSize;
			::GetTextExtentPoint(mdc, L"虚拟内存虚拟内存虚拟内存虚拟内存虚拟内存虚拟内存虚拟内存虚拟内存", 32, &tSize);
			SelectObject(mdc, oldFont);
			DeleteObject(hTipsFont);
			::ReleaseDC(hMain, mdc);
			int x, y, w, h;
			w = tSize.cx;
			wTipsHeight = tSize.cy;
			h = wTipsHeight *(nTraffic + 8);
			RECT wrc, src;
			GetWindowRect(hDlg, &wrc);
			GetScreenRect(hDlg, &src, TRUE);
			if (wrc.bottom + h > src.bottom)
				y = wrc.top - h;
			else
				y = wrc.bottom;
			if (wrc.right - (wrc.right - wrc.left) / 2 + w / 2 > src.right)
				x = src.right - w;
			else if (wrc.right - (wrc.right - wrc.left) / 2 - w / 2 < src.left)
				x = src.left;
			else
				x = wrc.right - (wrc.right - wrc.left) / 2 - w / 2;
			SetWindowPos(hTaskTips, HWND_TOPMOST, x, y, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW);
			HRGN hRgn = CreateRoundRectRgn(0, 0, w + 1, h + 1, 3, 3);
			SetWindowRgn(hTaskTips, hRgn, FALSE);
		}
	}
	break;
	case WM_MOUSELEAVE:
		if (TraySave.bMonitorFloat)
		{
			RECT wrc;
			GetWindowRect(hDlg, &wrc);
			TraySave.dMonitorPoint.x = wrc.left;
			TraySave.dMonitorPoint.y = wrc.top;
			WriteReg();
			bTaskBarMoveing = FALSE;
//			SetTimer(hDlg, 6, 100, NULL);
		}
		POINT pt;
		GetCursorPos(&pt);
		if (WindowFromPoint(pt) != hTaskTips)
		{
			if (pProcessTime != NULL)
			{
				delete[]pProcessTime;
				pProcessTime = NULL;
			}
			DestroyWindow(hTaskTips);
//			ShowWindow(hTaskTips, SW_HIDE);
			SetTimer(hMain, 11, 1000, NULL);
		}
		TRACKMOUSEEVENT csTME;
		csTME.cbSize = sizeof(csTME);
		csTME.dwFlags = TME_LEAVE ;
		csTME.hwndTrack = hTaskTips;// 指定要 追踪 的窗口
		csTME.dwHoverTime = 100;  // 鼠标在按钮上停留超过 10ms ，才认为状态为 HOVER
		TrackMouseEvent(&csTME);
		bEvent = FALSE;
		break;
	case  WM_RBUTTONDOWN:
	{
		POINT pt;
		GetCursorPos(&pt);
		ScreenToClient(hDlg, &pt);
		if (TraySave.bMonitorTraffic && pt.x < wTraffic && pt.y < wHeight*2)
		{

			HMENU hMenu = LoadMenu(hInst, MAKEINTRESOURCEW(IDR_MENU));
			HMENU subMenu = GetSubMenu(hMenu, 0);
			PIP_ADAPTER_ADDRESSES paa;
			paa = &piaa[0];
			int n = 1;
			CheckMenuRadioItem(subMenu, IDC_SELECT_ALL, IDC_SELECT_ALL + 99, IDC_SELECT_ALL, MF_BYCOMMAND);
			while (paa)
			{
				if (paa->IfType != IF_TYPE_SOFTWARE_LOOPBACK && paa->IfType != IF_TYPE_TUNNEL)
				{
					AppendMenu(subMenu, MF_BYCOMMAND, IDC_SELECT_ALL + n, paa->FriendlyName);
					if (strncmp(paa->AdapterName, TraySave.AdpterName, 38) == 0)
						CheckMenuRadioItem(subMenu, IDC_SELECT_ALL, IDC_SELECT_ALL + 99, IDC_SELECT_ALL + n, MF_BYCOMMAND);
					n++;
				}
				paa = paa->Next;
			}
			POINT point;
			GetCursorPos(&point);
			SetTimer(hDlg, 5, 1200, NULL);
			TrackPopupMenu(subMenu, TPM_LEFTALIGN, point.x, point.y, NULL, hDlg, NULL);
			DestroyMenu(hMenu);
		}
		else
			OpenSetting();
		return TRUE;
	}
		break;
	case WM_LBUTTONDOWN:
	{
		if (TraySave.bMonitorFloat)
		{
//			KillTimer(hDlg, 6);
			bTaskBarMoveing = TRUE;
			PostMessage(hDlg, WM_NCLBUTTONDOWN, HTCAPTION, lParam);			
		}
		return TRUE;
/*
		else
			RunProcess(szNetCpl);
*/
	}
		break;
	case WM_LBUTTONUP:
		if (!TraySave.bMonitorFloat)
		{
			ShowWindow(hDlg, SW_HIDE);
			SetTimer(hDlg, 9, 100, NULL);
			return TRUE;
		}
		break;
	case WM_TIMER:
		if (wParam == 9)
		{
			KillTimer(hDlg, wParam);
			POINT pt;
			GetCursorPos(&pt);
			mouse_event(MOUSEEVENTF_LEFTDOWN, pt.x, pt.y, 0, 0);
			mouse_event(MOUSEEVENTF_LEFTUP, pt.x, pt.y, 0, 0);
			ShowWindow(hDlg, SW_SHOWNOACTIVATE);
		}
		else if (wParam == 5)////////////////////////////////////////////////光标移出弹出式菜单自动隐藏菜单
		{

			HWND hMenu = FindWindow(L"#32768", NULL);
			POINT pt;
			GetCursorPos(&pt);
			if (WindowFromPoint(pt) != hMenu)
			{
				KillTimer(hDlg, wParam);
				PostMessage(hMenu, WM_CLOSE, NULL, NULL);
			}
		}
		else if (wParam == 3)
		{
			if (IsWindowVisible(hTaskTips))
			{
				nProcess = GetProcessMemUsage();
				GetProcessCpuUsage();
			}
			if (TraySave.bMonitorUsage)
			{
				iCPU = GetCPUUseRate();
				GlobalMemoryStatusEx(&MemoryStatusEx);
			}
			if (TraySave.bMonitorTemperature)
			{
				if (bRing0)
				{
					iTemperature1 = GetCpuTemp(1);
					iTemperature2 = GetCpuTemp(dNumProcessor);
				}
				int iATITemperature = 0;
				int iNVTemperature = 0;
				if (hNVDLL)
				{
					NV_GPU_THERMAL_SETTINGS currentTemp;//获取温度的数据结构
					currentTemp.version = NV_GPU_THERMAL_SETTINGS_VER;//一定要设置，不然调用获取温度函数时候会出错
					for (int GpuIndex = 0; GpuIndex < 4; GpuIndex++)
					{
						if (NvAPI_GPU_GetThermalSettings(hPhysicalGpu[GpuIndex], 15, &currentTemp) == 0)
						{
							iNVTemperature = currentTemp.sensor[0].currentTemp;
							break;
						}
					}
				}
				if (hATIDLL)
				{
					adlTemperature.iSize = sizeof(ADLTemperature);
					ADL_Overdrive5_Temperature_Get(0, 0, &adlTemperature);
					iATITemperature = adlTemperature.iTemperature / 1000;
				}
				if (iATITemperature != 0 || iNVTemperature != 0)
				{
					if (iATITemperature > iNVTemperature)
						iTemperature2 = iATITemperature;
					else
						iTemperature2 = iNVTemperature;
				}
			}
			if (TraySave.bMonitorTraffic)
			{
				if (hIphlpapi == NULL)
				{
					hIphlpapi = LoadLibrary(L"iphlpapi.dll");
					if (hIphlpapi)
					{
						GetAdaptersAddressesT = (pfnGetAdaptersAddresses)GetProcAddress(hIphlpapi, "GetAdaptersAddresses");
						GetIfTableT = (pfnGetIfTable)GetProcAddress(hIphlpapi, "GetIfTable");
					}
				}
				if (hIphlpapi)
				{
					PIP_ADAPTER_ADDRESSES paa;
					if (iGetAddressTime == 10)
					{
						//				DWORD odwIPSize = dwIPSize;
						dwIPSize = 0;
						if (GetAdaptersAddressesT(AF_INET, 0, 0, piaa, &dwIPSize) == ERROR_BUFFER_OVERFLOW)
						{
							//					if (dwIPSize != odwIPSize)
							{

								free(piaa);
								int n = 0;
								piaa = (PIP_ADAPTER_ADDRESSES)malloc(dwIPSize);
								if (GetAdaptersAddressesT(AF_INET, 0, 0, piaa, &dwIPSize) == ERROR_SUCCESS)
								{
									paa = &piaa[0];
									while (paa)
									{
										if (paa->IfType != IF_TYPE_SOFTWARE_LOOPBACK && paa->IfType != IF_TYPE_TUNNEL)
										{
											++n;
										}
										paa = paa->Next;
									}
									if (n != nTraffic)
									{
										free(traffic);
										nTraffic = n;
										traffic = (TRAFFIC*)malloc(nTraffic * sizeof TRAFFIC);
									}
								}
							}
						}
						iGetAddressTime = 0;
					}
					else
						iGetAddressTime++;
					/*
								PIP_ADAPTER_INFO pai;
								if (GetAdaptersInfo(ipinfo, &dwIPSize) == ERROR_BUFFER_OVERFLOW)
								{
									free(ipinfo);
									ipinfo = (PIP_ADAPTER_INFO)malloc(dwIPSize);
									GetAdaptersInfo(ipinfo, &dwIPSize);
									pai = &ipinfo[0];
									nTraffic = 0;
									while (pai)
									{
										++nTraffic;
										pai = pai->Next;
									}
									free(traffic);
									traffic = (TRAFFIC*)malloc(nTraffic * sizeof TRAFFIC);
								}
					*/
					if (GetIfTableT(mi, &dwMISize, FALSE) == ERROR_INSUFFICIENT_BUFFER)
					{
						free(mi);
						mi = (MIB_IFTABLE*)malloc(dwMISize);
						GetIfTableT(mi, &dwMISize, FALSE);
					}
					DWORD m_in_bytes = 0;
					DWORD m_out_bytes = 0;
					for (DWORD i = 0; i < mi->dwNumEntries; i++)
					{
						int l = 0;
						paa = &piaa[0];
						while (paa)
						{
							if (paa->IfType != IF_TYPE_SOFTWARE_LOOPBACK && paa->IfType != IF_TYPE_TUNNEL)
							{
								if (paa->IfIndex == mi->table[i].dwIndex)
								{
									traffic[l].in_byte = (mi->table[i].dwInOctets - traffic[l].in_bytes) * 8;
									traffic[l].out_byte = (mi->table[i].dwOutOctets - traffic[l].out_bytes) * 8;
									traffic[l].in_bytes = mi->table[i].dwInOctets;
									traffic[l].out_bytes = mi->table[i].dwOutOctets;

									PIP_ADAPTER_UNICAST_ADDRESS pUnicast = paa->FirstUnicastAddress;
									//							char IP[130];
									while (pUnicast)
									{
										if (AF_INET == pUnicast->Address.lpSockaddr->sa_family)// IPV4 地址，使用 IPV4 转换
										{
											void* pAddr = &((sockaddr_in*)pUnicast->Address.lpSockaddr)->sin_addr;
											byte* bp = (byte*)pAddr;
											swprintf_s(traffic[l].IP4, 16, L"%d.%d.%d.%d", bp[0], bp[1], bp[2], bp[3]);
											break;
										}
										//								else if (AF_INET6 == pUnicast->Address.lpSockaddr->sa_family)// IPV6 地址，使用 IPV6 转换
										//									inet_ntop(PF_INET6, &((sockaddr_in6*)pUnicast->Address.lpSockaddr)->sin6_addr, IP, sizeof(IP));
										pUnicast = pUnicast->Next;
									}
									//							MultiByteToWideChar(CP_ACP, 0, IP, 15, traffic[l].IP4, 15);
									traffic[l].FriendlyName = paa->FriendlyName;
									if (wcslen(paa->FriendlyName) > 19)
									{
										paa->FriendlyName[16] = L'.';
										paa->FriendlyName[17] = L'.';
										paa->FriendlyName[18] = L'.';
										paa->FriendlyName[19] = L'\0';
									}
									//							wcsncpy_s(traffic[l].FriendlyName, 24, paa->FriendlyName,24);
									if (TraySave.AdpterName[0] == L'\0' || strncmp(paa->AdapterName, TraySave.AdpterName, 38) == 0)
									{
										m_in_bytes += mi->table[i].dwInOctets;
										m_out_bytes += mi->table[i].dwOutOctets;
									}
								}
								++l;
							}
							paa = paa->Next;
						}
					}
					if (m_last_in_bytes != 0)
					{
						s_in_byte = m_in_bytes - m_last_in_bytes;
						s_out_byte = m_out_bytes - m_last_out_bytes;
					}
					m_last_out_bytes = m_out_bytes;
					m_last_in_bytes = m_in_bytes;
				}
			}
			else
			{
				if (hIphlpapi)
				{
					FreeLibrary(hIphlpapi);
					hIphlpapi = NULL;
				}
			}
			if (TraySave.bSound)
			{
				if ((TraySave.dNumValues[8] != 0 && (s_in_byte > TraySave.dNumValues[8] || s_out_byte > TraySave.dNumValues[8]))
					|| (TraySave.dNumValues[9] != 0 && ((DWORD)iTemperature1 > TraySave.dNumValues[9] || (DWORD)iTemperature2 > TraySave.dNumValues[9]))
					|| (TraySave.dNumValues[10] != 0 && (DWORD)iCPU > TraySave.dNumValues[10])
					|| (TraySave.dNumValues[11] != 0 && MemoryStatusEx.dwMemoryLoad > TraySave.dNumValues[11]))
				{
					MessageBeep(MB_ICONHAND);
					//PlaySound((LPCWSTR)SND_ALIAS_SYSTEMQUESTION, NULL, SND_ASYNC | SND_ALIAS_ID);
				}
			}
			::InvalidateRect(hTaskBar, NULL, TRUE);			
		}
	case WM_ERASEBKGND:
	{		
		//		PAINTSTRUCT ps;
		HDC hdc = (HDC)wParam;//BeginPaint(hDlg, &ps);		
		RECT rc;
		GetClientRect(hDlg, &rc);
		HDC mdc = CreateCompatibleDC(hdc);
		HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, rc.right - rc.left, rc.bottom - rc.top);
		HBITMAP oldBmp = (HBITMAP)SelectObject(mdc, hMemBmp);
		if (TraySave.cMonitorColor[0] != 0)
		{
			HBRUSH hb=CreateSolidBrush(TraySave.cMonitorColor[0]);
			FillRect(mdc, &rc, hb);
			DeleteObject(hb);
		}
//		if (bErasebkgnd)
		{
			if (VTray)
			{
/*
				int s = (rc.right - rc.left - DPI(54)) / 2;
				rc.left += s;
				rc.right -= s;
*/
			}
			else
			{
				InflateRect(&rc, -1, 0);
			}
			HFONT oldFont = (HFONT)SelectObject(mdc, hFont);
			WCHAR sz[16];
			SetBkMode(mdc, TRANSPARENT);
			COLORREF rgb;
			if (TraySave.bMonitorTraffic)
			{
				RECT crc = rc;
				if (VTray)
				{
					crc.bottom = wHeight;
					DrawTraffic(mdc, &crc, s_out_byte,FALSE);
					OffsetRect(&crc, 0, wHeight);
					DrawTraffic(mdc, &crc, s_in_byte,TRUE);
				}
				else
				{
					crc.bottom /= 2;
					DrawTraffic(mdc, &crc, s_out_byte,FALSE);
					OffsetRect(&crc, 0, crc.bottom);
					DrawTraffic(mdc, &crc, s_in_byte,TRUE);
				}
			}
			if (TraySave.bMonitorTemperature)
			{
				RECT crc = rc;
				if (VTray)
				{
					if (TraySave.bMonitorTraffic)
						crc.top = wHeight * 2;
					crc.bottom = crc.top + wHeight;
				}
				else
				{

					if (TraySave.bMonitorTraffic)
						crc.left = wTraffic;
					else
						crc.left = 0;
					crc.bottom /= 2;
				}
				if (bRing0)
				{
					if (iTemperature1 <= TraySave.dNumValues[2])
						rgb = TraySave.cMonitorColor[4];
					else if (iTemperature1 <= TraySave.dNumValues[3])
						rgb = TraySave.cMonitorColor[5];
					else
						rgb = TraySave.cMonitorColor[6];
					SetTextColor(mdc, rgb);
					if(TraySave.iMonitorSimple==1)
						swprintf_s(sz, 16, L"%.2d℃", iTemperature1);
					else if (TraySave.iMonitorSimple == 2)
						swprintf_s(sz, 16, L"%.2d", iTemperature1);
					else
						swprintf_s(sz, 16, L"%s%.2d%s",TraySave.szTemperatureCPU, iTemperature1, TraySave.szTemperatureCPUUnit);
						
					if(VTray)
						DrawText(mdc, sz, (int)wcslen(sz), &crc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
					else
						DrawText(mdc, sz, (int)wcslen(sz), &crc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
				}
				if (bRing0)
				{
					if (VTray)
						OffsetRect(&crc, 0, wHeight);
					else
						OffsetRect(&crc, 0, crc.bottom - crc.top);
				}
				else
				{
					if (VTray)
					{
//						crc.bottom += wHeight;
					}
					else
						crc.bottom += (crc.bottom - crc.top);
				}
				if (iTemperature2 <= TraySave.dNumValues[2])
					rgb = TraySave.cMonitorColor[4];
				else if (iTemperature2 <= TraySave.dNumValues[3])
					rgb = TraySave.cMonitorColor[5];
				else
					rgb = TraySave.cMonitorColor[6];
				SetTextColor(mdc, rgb);
				if(TraySave.iMonitorSimple==0)
					swprintf_s(sz, 16, L"%s%.2d%s",TraySave.szTemperatureGPU, iTemperature2, TraySave.szTemperatureGPUUnit);
				else if (TraySave.iMonitorSimple == 1)
					swprintf_s(sz, 16, L"%.2d℃", iTemperature2);
				else
					swprintf_s(sz, 16, L"%.2d", iTemperature2);
				if (VTray)
					DrawText(mdc, sz, (int)wcslen(sz), &crc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
				else
					DrawText(mdc, sz, (int)wcslen(sz), &crc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

			}
			if (TraySave.bMonitorUsage)
			{
				if (iCPU <= TraySave.dNumValues[4])
					rgb = TraySave.cMonitorColor[4];
				else if (iCPU <= TraySave.dNumValues[5])
					rgb = TraySave.cMonitorColor[5];
				else
					rgb = TraySave.cMonitorColor[6];
				SetTextColor(mdc, rgb);
				/*
							if(bRing0)
								swprintf_s(sz, 16, L"%.2d%%", iCPU);
							else
				*/
				if(TraySave.iMonitorSimple==1)
					swprintf_s(sz, 16, L"%.2d%%", iCPU);
				else if (TraySave.iMonitorSimple == 2)
					swprintf_s(sz, 16, L"%.2d", iCPU);
				else
					swprintf_s(sz, 16, L"%s%.2d%s",TraySave.szUsageCPU, iCPU, TraySave.szUsageCPUUnit);
				
				size_t sLen = wcslen(sz);
				RECT crc = rc;
				if (VTray)
				{
					if (TraySave.bMonitorTraffic)
						crc.top = wHeight * 2;
					if (TraySave.bMonitorTemperature)
					{
						crc.top += wHeight;
						if (bRing0)
							crc.top += wHeight;
					}
					crc.bottom = crc.top + wHeight;
					DrawText(mdc, sz, (int)sLen, &crc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
				}
				else
				{
					crc.bottom /= 2;
					DrawText(mdc, sz, (int)sLen, &crc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
				}				
				/*
							if(bRing0)
								swprintf_s(sz, 16, L"%.2d%%", MemoryStatusEx.dwMemoryLoad);
							else
				*/
				if(TraySave.iMonitorSimple==1)
					swprintf_s(sz, 16, L"%.2d%%", MemoryStatusEx.dwMemoryLoad);
				else if (TraySave.iMonitorSimple == 2)
					swprintf_s(sz, 16, L"%.2d", MemoryStatusEx.dwMemoryLoad);
				else
					swprintf_s(sz, 16,L"%s%.2d%s",TraySave.szUsageMEM, MemoryStatusEx.dwMemoryLoad, TraySave.szUsageMEMUnit);
				sLen = wcslen(sz);
				if (MemoryStatusEx.dwMemoryLoad <= TraySave.dNumValues[6])
					rgb = TraySave.cMonitorColor[4];
				else if (MemoryStatusEx.dwMemoryLoad <= TraySave.dNumValues[7])
					rgb = TraySave.cMonitorColor[5];
				else
					rgb = TraySave.cMonitorColor[6];
				SetTextColor(mdc, rgb);
				if (VTray)
				{
					OffsetRect(&crc, 0, wHeight);
					DrawText(mdc, sz, (int)sLen, &crc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
				}
				else
				{
					OffsetRect(&crc, 0, crc.bottom);
					DrawText(mdc, sz, (int)sLen, &crc, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
				}
			}
			SelectObject(mdc, oldFont);
		}
//		GetClientRect(hDlg, &rc);
		InflateRect(&rc, 1, 0);
		BitBlt(hdc, 0, 0, rc.right - rc.left, rc.bottom - rc.top, mdc, 0, 0, SRCCOPY);
		SelectObject(mdc, oldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(mdc);
		//		EndPaint(hDlg, &ps);
		
		return TRUE;
	}
	break;
	}
	return FALSE;
}
INT_PTR CALLBACK MainProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)//主窗口过程
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
/*
	case WM_ENDSESSION:
		if (lParam == ENDSESSION_LOGOFF)
		{
			DestroyWindow(hTray);
			RunProcess(NULL);
			return TRUE;
		}
		break;
*/
	case WM_TRAYS:
		OpenSetting();
		break;
	case WM_DPICHANGED:
	{
		iDPI = LOWORD(wParam);		
		SetTimer(hDlg, 8, 1000, NULL);
	}
	break;
	case WM_CLOSE:
	{
		KillTimer(hDlg, 6);
		KillTimer(hDlg, 3);
		SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
		HWND hSecondaryTray;
		hSecondaryTray = FindWindow(szSecondaryTray, NULL);
		while (hSecondaryTray)
		{
			HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
			SendMessage(hSReBarWnd, WM_SETREDRAW, TRUE, 0);
			ShowWindow(hSReBarWnd, SW_SHOWNOACTIVATE);
			hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
		}
		PostQuitMessage(0);
	}
		break;		
	case WM_TIMER:
	{
		if (wParam == 8)
		{
			KillTimer(hDlg, wParam);
			SetWH();
		}
		else if (wParam == 11)//释放内存
		{
			KillTimer(hDlg, wParam);
			SetTimer(hDlg, wParam, 60000, NULL);
			HANDLE hProcess = GetCurrentProcess();
			SetProcessWorkingSetSize(hProcess, -1, -1);
			EmptyWorkingSet(hProcess);
		}
		else if (wParam == 6)//处理任务栏图标与信息窗口
		{
			hTray = FindWindow(szShellTray, NULL);
			hReBarWnd = FindWindowEx(hTray, 0, L"ReBarWindow32", NULL);
			hTaskWnd = FindWindowEx(hReBarWnd, NULL, L"MSTaskSwWClass", NULL);
			HWND hTaskListWnd = FindWindowEx(hTaskWnd, NULL, L"MSTaskListWClass", NULL);
			if (TraySave.bMonitor)
			{
				if(!bTaskBarMoveing)
					AdjustWindowPos();				
				if(IsWindowVisible(hTaskTips))
					::InvalidateRect(hTaskTips, NULL, TRUE);
			}
			SetTaskBarPos(hTaskListWnd, hTray, hTaskWnd, hReBarWnd,TRUE);
			HWND hSecondaryTray;
			hSecondaryTray = FindWindow(szSecondaryTray, NULL);
			while (hSecondaryTray)
			{
				HWND hSReBarWnd = FindWindowEx(hSecondaryTray, 0, L"WorkerW", NULL);
				if (hSReBarWnd)
				{
					HWND hSTaskListWnd = FindWindowEx(hSReBarWnd, NULL, L"MSTaskListWClass", NULL);
					if (hSTaskListWnd)
					{
						SetTaskBarPos(hSTaskListWnd, hSecondaryTray, hSReBarWnd, hSReBarWnd,FALSE);						
					}
				}
				hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
			}
		}
		else if (wParam == 3)//处理任务栏风格
		{
			
			{
				HWND hTray = FindWindow(szShellTray, NULL);
				if (hTray)
				{
					if (iProject == 0)
						iWindowMode = 0;
					else if(iProject == 1)
						iWindowMode = 1;
					else
					{
						iWindowMode = 0;
						EnumWindows(IsZoomedFunc, (LPARAM)MonitorFromWindow(hTray, MONITOR_DEFAULTTONEAREST));
					}
					SetWindowCompositionAttribute(hTray, TraySave.aMode[iWindowMode], TraySave.dAlphaColor[iWindowMode]);
					LONG_PTR exStyle = GetWindowLongPtr(hTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hTray, 0, (BYTE)TraySave.bAlpha[iWindowMode], LWA_ALPHA);
				}
				HWND hSecondaryTray = FindWindow(szSecondaryTray, NULL);
				while (hSecondaryTray)
				{
					if (iProject == 0)
						iWindowMode = 0;
					else if (iProject == 1)
						iWindowMode = 1;
					else
					{
						iWindowMode = 0;
						EnumWindows(IsZoomedFunc, (LPARAM)MonitorFromWindow(hSecondaryTray, MONITOR_DEFAULTTONEAREST));
					}
					SetWindowCompositionAttribute(hSecondaryTray, TraySave.aMode[iWindowMode], TraySave.dAlphaColor[iWindowMode]);
					LONG_PTR exStyle = GetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE);
					exStyle |= WS_EX_LAYERED;
					SetWindowLongPtr(hSecondaryTray, GWL_EXSTYLE, exStyle);
					SetLayeredWindowAttributes(hSecondaryTray, 0, (BYTE)TraySave.bAlpha[iWindowMode], LWA_ALPHA);
					hSecondaryTray = FindWindowEx(NULL, hSecondaryTray, szSecondaryTray, NULL);
				}
			}
			if (TraySave.aMode[0] == ACCENT_DISABLED&& TraySave.aMode[1]== ACCENT_DISABLED)//默认则关闭定时器
				KillTimer(hDlg, 3);
		}
	}
	break;
	case WM_IAWENTRAY://////////////////////////////////////////////////////////////////////////////////通知栏左右键处理
	{
		if (wParam == WM_IAWENTRAY)
		{
			if (lParam == WM_LBUTTONDOWN || lParam == WM_RBUTTONDOWN)
			{
				RunProcess(NULL);
			}
		}
		break;
	}
	break;
	}
	return FALSE;
}
INT_PTR CALLBACK SettingProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)//设置窗口过程
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR)lParam)->code)
		{
		case NM_CLICK:
		case NM_RETURN:
		{
			HWND g_hLink = GetDlgItem(hDlg, IDC_SYSLINK);
			PNMLINK pNMLink = (PNMLINK)lParam;
			LITEM item = pNMLink->item;
			if ((((LPNMHDR)lParam)->hwndFrom == g_hLink) && (item.iLink == 0))
			{
				CloseHandle(ShellExecute(NULL, L"open", L"https://gitee.com/cgbsmy/TrayS", NULL, NULL, SW_SHOW));
				//mailto:cgbsmy@live.com?subject=TrayS
			}
			else
			{
				CloseHandle(ShellExecute(NULL, L"open", L"https://www.52pojie.cn/thread-1182669-1-1.html", NULL, NULL, SW_SHOW));
			}
			break;
		}
		}
		break;
	case WM_HSCROLL://////////////////////////////////////////////////////////////////////////////////透明度处理
	{
		HWND hSlider = GetDlgItem(hDlg, IDC_SLIDER_ALPHA);
		HWND hSliderB = GetDlgItem(hDlg, IDC_SLIDER_ALPHA_B);
		if (hSlider == (HWND)lParam)
		{
			TraySave.bAlpha[iProject] = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA, TBM_GETPOS, 0, 0);
		}
		else if (hSliderB == (HWND)lParam)
		{
			DWORD bAlphaB= (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
			bAlphaB = bAlphaB << 24;
			TraySave.dAlphaColor[iProject] = bAlphaB + (TraySave.dAlphaColor[iProject] & 0xffffff);
		}
		SetTimer(hDlg, 3, 500, NULL);
		break;
	}
	case WM_TIMER:
		if (wParam == 3)
		{
			KillTimer(hDlg, wParam);
			WriteReg();
		}
		break;
    case WM_COMMAND:
		if (HIWORD(wParam) == EN_CHANGE&&!bSettingInit)
		{
			if (LOWORD(wParam) >= IDC_EDIT1 && LOWORD(wParam) <= IDC_EDIT12)
			{
				int index = LOWORD(wParam) - IDC_EDIT1;
				TraySave.dNumValues[index] = GetDlgItemInt(hDlg, LOWORD(wParam), NULL, 0);
				if (index == 0 || index == 1 || index == 8)
					TraySave.dNumValues[index] *= 1048576;
				SetTimer(hDlg, 3, 500, NULL);
			}
			else if (LOWORD(wParam) == IDC_EDIT_TIME)
			{
				TraySave.FlushTime = GetDlgItemInt(hDlg, LOWORD(wParam), NULL, 0);
				if (TraySave.aMode[0] != ACCENT_DISABLED || TraySave.aMode[1] != ACCENT_DISABLED)
					SetTimer(hMain, 3, TraySave.FlushTime, NULL);
				SetTimer(hDlg, 3, 500, NULL);
			}
			else if (LOWORD(wParam) >= IDC_EDIT14 && LOWORD(wParam) <= IDC_EDIT23)
			{
				GetDlgItemText(hDlg, IDC_EDIT14, TraySave.szTrafficOut, 8);
				GetDlgItemText(hDlg, IDC_EDIT15, TraySave.szTrafficIn, 8);
				GetDlgItemText(hDlg, IDC_EDIT16, TraySave.szTemperatureCPU, 8);
				GetDlgItemText(hDlg, IDC_EDIT17, TraySave.szTemperatureGPU, 8);
				GetDlgItemText(hDlg, IDC_EDIT18, TraySave.szTemperatureCPUUnit, 4);
				GetDlgItemText(hDlg, IDC_EDIT19, TraySave.szTemperatureGPUUnit, 4);
				GetDlgItemText(hDlg, IDC_EDIT20, TraySave.szUsageCPU, 8);
				GetDlgItemText(hDlg, IDC_EDIT21, TraySave.szUsageMEM, 8);
				GetDlgItemText(hDlg, IDC_EDIT22, TraySave.szUsageCPUUnit, 4);
				GetDlgItemText(hDlg, IDC_EDIT23, TraySave.szUsageMEMUnit, 4);
				SetTimer(hDlg, 3, 1500, NULL);
				if(TraySave.iMonitorSimple==0)
					SetWH();
			}
		}
		else if (LOWORD(wParam) >= IDC_RADIO_DEFAULT && LOWORD(wParam) <= IDC_RADIO_ACRYLIC)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_DEFAULT))
				TraySave.aMode[iProject] = ACCENT_DISABLED;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_TRANSPARENT))
				TraySave.aMode[iProject] = ACCENT_ENABLE_TRANSPARENTGRADIENT;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_BLURBEHIND))
				TraySave.aMode[iProject] = ACCENT_ENABLE_BLURBEHIND;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_ACRYLIC))
				TraySave.aMode[iProject] = ACCENT_ENABLE_ACRYLICBLURBEHIND;
			WriteReg();
			if (TraySave.aMode[0] != ACCENT_DISABLED || TraySave.aMode[1] != ACCENT_DISABLED)
				SetTimer(hMain, 3, TraySave.FlushTime, NULL);
			else
				KillTimer(hMain, 3);

		}
		else if (LOWORD(wParam) >= IDC_RADIO_LEFT && LOWORD(wParam) <= IDC_RADIO_RIGHT)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_LEFT))
			{
				TraySave.iPos = 0;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_CENTER))
			{
				TraySave.iPos = 1;
			}
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_RIGHT))
			{
				TraySave.iPos = 2;
			}
			WriteReg();			
			if (TraySave.iPos || TraySave.bMonitor)
				SetTimer(hMain, 6, 1000, NULL);
			else
				KillTimer(hMain, 6);
		}
		else if (LOWORD(wParam) >= IDC_RADIO_BYTE && LOWORD(wParam) <= IDC_RADIO_MB)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_AUTO))
				TraySave.iUnit = 0;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_KB))
				TraySave.iUnit = 1;
			else if (IsDlgButtonChecked(hDlg, IDC_RADIO_MB))
				TraySave.iUnit = 2;
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_BIT))
				TraySave.iUnit |= 0x10000;
			WriteReg();
		}		
		if (LOWORD(wParam) == IDC_RADIO_NORMAL || LOWORD(wParam) == IDC_RADIO_MAXIMIZE)
		{
			if (IsDlgButtonChecked(hDlg, IDC_RADIO_NORMAL))
				iProject = 0;
			else
				iProject = 1;
			if (TraySave.aMode[iProject] == ACCENT_DISABLED)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_DEFAULT);
			else if (TraySave.aMode[iProject] == ACCENT_ENABLE_TRANSPARENTGRADIENT)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_TRANSPARENT);
			else if (TraySave.aMode[iProject] == ACCENT_ENABLE_BLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_BLURBEHIND);
			else if (TraySave.aMode[iProject] == ACCENT_ENABLE_ACRYLICBLURBEHIND)
				CheckRadioButton(hSetting, IDC_RADIO_DEFAULT, IDC_RADIO_ACRYLIC, IDC_RADIO_ACRYLIC);
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA, TBM_SETPOS, TRUE, TraySave.bAlpha[iProject]);
			BYTE bAlphaB = TraySave.dAlphaColor[iProject] >> 24;
			SendDlgItemMessage(hSetting, IDC_SLIDER_ALPHA_B, TBM_SETPOS, TRUE, bAlphaB);
			::InvalidateRect(GetDlgItem(hSetting, IDC_BUTTON_COLOR), NULL, FALSE);
		}
		else if (LOWORD(wParam) == IDC_CHECK_SOUND)
		{
			TraySave.bSound= IsDlgButtonChecked(hDlg, IDC_CHECK_SOUND);
			WriteReg();
		}
		else if (LOWORD(wParam) == IDC_CHECK_TIPS)
		{
			TraySave.bMonitorTips = IsDlgButtonChecked(hDlg, IDC_CHECK_TIPS);
			WriteReg();
		}
		else if (LOWORD(wParam) == IDC_CHECK_TRAYICON)
		{
			TraySave.bTrayIcon = IsDlgButtonChecked(hDlg, IDC_CHECK_TRAYICON);
			WriteReg();
			DestroyWindow(hTaskBar);
			if (TraySave.bTrayIcon)
				Shell_NotifyIcon(NIM_ADD, &nid);
			else
				Shell_NotifyIcon(NIM_DELETE, &nid);
			if (TraySave.bMonitor)
				OpenTaskBar();
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR)
		{
			TraySave.bMonitor = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR);
			WriteReg();
			if (TraySave.bMonitor)
			{
				OpenTaskBar();
			}
			else
			{
				DestroyWindow(hTaskBar);
				if (TraySave.iPos == 0)
					KillTimer(hMain, 6);
			}
		}
		else if (LOWORD(wParam) == IDC_CHECK_TRAFFIC)
		{
			TraySave.bMonitorTraffic = IsDlgButtonChecked(hDlg, IDC_CHECK_TRAFFIC);
			WriteReg();
			SetWH();
		}
		else if (LOWORD(wParam) == IDC_CHECK_TEMPERATURE)
		{
			TraySave.bMonitorTemperature = IsDlgButtonChecked(hDlg, IDC_CHECK_TEMPERATURE);
			if (TraySave.bMonitorTemperature)
				LoadTemperatureDLL();
			else
				FreeTemperatureDLL();
			WriteReg();
			SetWH();
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR_SIMPLE)
		{
			TraySave.iMonitorSimple = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR_SIMPLE);
			WriteReg();
			SetWH();
		}
		else if (LOWORD(wParam) == IDC_CHECK_USAGE)
		{
			TraySave.bMonitorUsage = IsDlgButtonChecked(hDlg, IDC_CHECK_USAGE);
			WriteReg();
			SetWH();
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR_PDH)
		{
			TraySave.bMonitorPDH = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR_PDH);
			WriteReg();
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR_LEFT)
		{
			TraySave.bMonitorLeft = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR_LEFT);
			WriteReg();
		}
		else if (LOWORD(wParam) == IDC_CHECK_MONITOR_FLOAT)
		{
		TraySave.bMonitorFloat = IsDlgButtonChecked(hDlg, IDC_CHECK_MONITOR_FLOAT);
			WriteReg();
			DestroyWindow(hTaskBar);
			DestroyWindow(hTaskTips);
			OpenTaskBar();
		}
		else if (LOWORD(wParam) == IDC_CHECK_TRANSPARENT)
		{
		TraySave.bMonitorTransparent = IsDlgButtonChecked(hDlg, IDC_CHECK_TRANSPARENT);
			WriteReg();
		}
		else if (LOWORD(wParam) == IDC_CHECK_AUTORUN)
		{
			if (IsDlgButtonChecked(hDlg, IDC_CHECK_AUTORUN))
				AutoRun(TRUE, TRUE);
			else
				AutoRun(TRUE, FALSE);
		}
		else if (LOWORD(wParam) == IDC_RESTORE_DEFAULT)
		{
			DeleteFile(szTraySave);
//			RegDeleteKey(HKEY_CURRENT_USER, szSubKey);
			SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0);
		}
		else if(LOWORD(wParam) == IDCANCEL)
        {
//			SendMessage(hMain, WM_TRAYS + 1, FALSE, NULL);
//			SendMessage(hMain, WM_TIMER, 11, 0);
//			SendMessage(hReBarWnd, WM_SETREDRAW, TRUE, 0);
			FreeTemperatureDLL();
			CloseHandle(hMutex);
			hMutex = NULL;
			SendMessage(hMain, WM_CLOSE, NULL, NULL);			
			DestroyWindow(hDlg);			
			RunProcess(NULL);
			PostQuitMessage(0);
			
            return (INT_PTR)TRUE;
        }
		else if (LOWORD(wParam) == IDC_CLOSE)
		{
			FreeTemperatureDLL();
			CloseHandle(hMutex);
			hMutex = NULL;
			SendMessage(hMain, WM_CLOSE, NULL, NULL);
			DestroyWindow(hDlg);
			PostQuitMessage(0);			
		}
		else if (LOWORD(wParam) == IDC_BUTTON_FONT|| LOWORD(wParam)==IDC_BUTTON_TIPS_FONT)
		{
#define CF_SCREENFONTS             0x00000001
#define CF_PRINTERFONTS            0x00000002
#define CF_BOTH                    (CF_SCREENFONTS | CF_PRINTERFONTS)
#define CF_SHOWHELP                0x00000004L
#define CF_ENABLEHOOK              0x00000008L
#define CF_ENABLETEMPLATE          0x00000010L
#define CF_ENABLETEMPLATEHANDLE    0x00000020L
#define CF_INITTOLOGFONTSTRUCT     0x00000040L
#define CF_USESTYLE                0x00000080L
#define CF_EFFECTS                 0x00000100L
#define CF_APPLY                   0x00000200L
#define CF_ANSIONLY                0x00000400L
#if(WINVER >= 0x0400)
#define CF_SCRIPTSONLY             CF_ANSIONLY
#endif /* WINVER >= 0x0400 */
#define CF_NOVECTORFONTS           0x00000800L
#define CF_NOOEMFONTS              CF_NOVECTORFONTS
#define CF_NOSIMULATIONS           0x00001000L
#define CF_LIMITSIZE               0x00002000L
#define CF_FIXEDPITCHONLY          0x00004000L
#define CF_WYSIWYG                 0x00008000L // must also have CF_SCREENFONTS & CF_PRINTERFONTS
#define CF_FORCEFONTEXIST          0x00010000L
#define CF_SCALABLEONLY            0x00020000L
#define CF_TTONLY                  0x00040000L
#define CF_NOFACESEL               0x00080000L
#define CF_NOSTYLESEL              0x00100000L
#define CF_NOSIZESEL               0x00200000L
#if(WINVER >= 0x0400)
#define CF_SELECTSCRIPT            0x00400000L
#define CF_NOSCRIPTSEL             0x00800000L
#define CF_NOVERTFONTS             0x01000000L
#endif /* WINVER >= 0x0400 */
#if(WINVER >= 0x0601)
#define CF_INACTIVEFONTS           0x02000000L
#endif /* WINVER >= 0x0601 */

		// these are extra nFontType bits that are added to what is returned to the
		// EnumFonts callback routine

#define SIMULATED_FONTTYPE    0x8000
#define PRINTER_FONTTYPE      0x4000
#define SCREEN_FONTTYPE       0x2000
#define BOLD_FONTTYPE         0x0100
#define ITALIC_FONTTYPE       0x0200
#define REGULAR_FONTTYPE      0x0400
		typedef UINT_PTR(CALLBACK* LPCFHOOKPROC) (HWND, UINT, WPARAM, LPARAM);
		typedef struct tagCHOOSEFONTW {
			DWORD           lStructSize;
			HWND            hwndOwner;          // caller's window handle
			HDC             hDC;                // printer DC/IC or NULL
			LPLOGFONTW      lpLogFont;          // ptr. to a LOGFONT struct
			INT             iPointSize;         // 10 * size in points of selected font
			DWORD           Flags;              // enum. type flags
			COLORREF        rgbColors;          // returned text color
			LPARAM          lCustData;          // data passed to hook fn.
			LPCFHOOKPROC    lpfnHook;           // ptr. to hook function
			LPCWSTR         lpTemplateName;     // custom template name
			HINSTANCE       hInstance;          // instance handle of.EXE that
												//   contains cust. dlg. template
			LPWSTR          lpszStyle;          // return the style field here
												// must be LF_FACESIZE or bigger
			WORD            nFontType;          // same value reported to the EnumFonts
												//   call back with the extra FONTTYPE_
												//   bits added
			WORD            ___MISSING_ALIGNMENT__;
			INT             nSizeMin;           // minimum pt size allowed &
			INT             nSizeMax;           // max pt size allowed if
												//   CF_LIMITSIZE is used
		} CHOOSEFONT;
			TraySave.TraybarFont.lfHeight = TraySave.TraybarFontSize;
			TraySave.TipsFont.lfHeight = TraySave.TipsFontSize;
			CHOOSEFONT cf;
			cf.lStructSize = sizeof cf;
			cf.hwndOwner = hDlg;
			cf.hDC = NULL;
			if(LOWORD(wParam)==IDC_BUTTON_FONT)
				cf.lpLogFont = &TraySave.TraybarFont;
			else
				cf.lpLogFont = &TraySave.TipsFont;
			cf.Flags = CF_SCREENFONTS| CF_INITTOLOGFONTSTRUCT| CF_EFFECTS;
			cf.nFontType = SCREEN_FONTTYPE;
			cf.rgbColors = RGB(0, 0, 0);
			typedef BOOL(WINAPI* pfnChooseFont)(CHOOSEFONT *lpcf);
			HMODULE hComdlg32 = LoadLibrary(L"comdlg32.dll");
			if (hComdlg32)
			{
				pfnChooseFont ChooseFont = (pfnChooseFont)GetProcAddress(hComdlg32, "ChooseFontW");
				if (ChooseFont)
				{
					if (ChooseFont(&cf))
					{
						if (LOWORD(wParam) == IDC_BUTTON_FONT)
						{
							TraySave.TraybarFontSize = TraySave.TraybarFont.lfHeight;
							otleft = -1;
							SetWH();
							AdjustWindowPos();
						}
						else
							TraySave.TipsFontSize = TraySave.TipsFont.lfHeight;
						WriteReg();
					}
				}
				FreeLibrary(hComdlg32);
			}			
		}
		else if (LOWORD(wParam) == IDC_BUTTON_COLOR||(LOWORD(wParam)>=IDC_BUTTON_COLOR_BACKGROUND&&LOWORD(wParam)<=IDC_BUTTON_COLOR_HIGH))
		{
			CHOOSECOLOR stChooseColor;
			stChooseColor.lStructSize = sizeof(CHOOSECOLOR);
			stChooseColor.hwndOwner = hDlg;
			if (LOWORD(wParam) == IDC_BUTTON_COLOR)
			{
				stChooseColor.rgbResult = TraySave.dAlphaColor[iProject];
				stChooseColor.lpCustColors = (LPDWORD)&TraySave.dAlphaColor[iProject];
			}
			else
			{
				stChooseColor.rgbResult = TraySave.cMonitorColor[LOWORD(wParam) - IDC_BUTTON_COLOR_BACKGROUND];
				stChooseColor.lpCustColors = TraySave.cMonitorColor;
			}
			stChooseColor.Flags = CC_RGBINIT | CC_FULLOPEN;
			stChooseColor.lCustData = 0;
			stChooseColor.lpfnHook = NULL;
			stChooseColor.lpTemplateName = NULL;
			typedef BOOL(WINAPI* pfnChooseColor)(LPCHOOSECOLOR lpcc);
			HMODULE hComdlg32 = LoadLibrary(L"comdlg32.dll");
			if (hComdlg32)
			{
				pfnChooseColor ChooseColor = (pfnChooseColor)GetProcAddress(hComdlg32, "ChooseColorW");
				if (ChooseColor)
				{
					if (ChooseColor(&stChooseColor))
					{
						if (LOWORD(wParam) == IDC_BUTTON_COLOR)
						{
							TraySave.dAlphaColor[iProject] = stChooseColor.rgbResult;
							DWORD bAlphaB = (int)SendDlgItemMessage(hDlg, IDC_SLIDER_ALPHA_B, TBM_GETPOS, 0, 0);
							bAlphaB = bAlphaB << 24;
							TraySave.dAlphaColor[iProject] = bAlphaB + (TraySave.dAlphaColor[iProject] & 0xffffff);
						}
						else
						{
							TraySave.cMonitorColor[LOWORD(wParam - IDC_BUTTON_COLOR_BACKGROUND)] = stChooseColor.rgbResult;
						}
						::InvalidateRect(GetDlgItem(hMain, LOWORD(wParam)), NULL, FALSE);
					}
				}
				FreeLibrary(hComdlg32);
			}
			WriteReg();
//			SendMessage(hMain, WM_TRAYS, NULL, NULL);
		}
        break;
    }
    return (INT_PTR)FALSE;
}
typedef BOOL(WINAPI*pfnSetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
BOOL SetWindowCompositionAttribute(HWND hWnd, ACCENT_STATE mode, DWORD AlphaColor)//设置窗口WIN10风格
{
	if (mode == ACCENT_DISABLED)
	{
		if (bAccentNormal==FALSE)
		{
			SendMessage(hWnd, WM_THEMECHANGED, 0, 0);
			bAccentNormal = TRUE;
		}
		return TRUE;
	}
	bAccentNormal = FALSE;
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnSetWindowCompositionAttribute setWindowCompositionAttribute = (pfnSetWindowCompositionAttribute)GetProcAddress(hUser, "SetWindowCompositionAttribute");
		if (setWindowCompositionAttribute)
		{
			ACCENT_POLICY accent = { mode, 2, AlphaColor, 0 };
			_WINDOWCOMPOSITIONATTRIBDATA data;
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = &accent;
			data.cbData = sizeof(accent);
			ret = setWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
typedef BOOL(WINAPI*pfnGetWindowCompositionAttribute)(HWND, struct _WINDOWCOMPOSITIONATTRIBDATA*);
/*
BOOL GetWindowCompositionAttribute(HWND hWnd, ACCENT_POLICY * accent)
{
	BOOL ret = FALSE;
	HMODULE hUser = GetModuleHandle(L"user32.dll");
	if (hUser)
	{
		pfnGetWindowCompositionAttribute getWindowCompositionAttribute = (pfnGetWindowCompositionAttribute)GetProcAddress(hUser, "GetWindowCompositionAttribute");
		if (getWindowCompositionAttribute)
		{
			_WINDOWCOMPOSITIONATTRIBDATA data;
			ACCENT_POLICY acc[2];
			data.Attrib = WCA_ACCENT_POLICY;
			data.pvData = acc;
			data.cbData = sizeof ACCENT_POLICY * 2;
			ret = getWindowCompositionAttribute(hWnd, &data);
		}
	}
	return ret;
}
*/
BOOL AutoRun(BOOL GetSet, BOOL bAuto)//读取、设置开机启动、关闭开机启动
{
	BOOL ret = FALSE;
	WCHAR sFileName[MAX_PATH];
	GetModuleFileName(NULL, sFileName, MAX_PATH);
	if (IsUserAdmin())
	{
		if (GetSet)
		{
			HKEY pKey;
			RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
			if (pKey)
			{
				RegDeleteValue(pKey, szAppName);
				RegCloseKey(pKey);
			}
			RegOpenKeyEx(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
			if (pKey)
			{
				RegDeleteValue(pKey, szAppName);
				RegCloseKey(pKey);
			}
			if (bAuto)
			{
				InstallService();
			}
			else
			{
				if (IsServiceInstalled())
					UninstallService();
			}
		}
		else
		{
			return IsServiceInstalled();
		}
	}
	else
	{
		HKEY pKey;
		RegOpenKeyEx(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", NULL, KEY_ALL_ACCESS, &pKey);
		if (pKey)
		{
			if (GetSet)
			{
				if (bAuto)
				{
					RegSetValueEx(pKey, szAppName, NULL, REG_SZ, (BYTE*)sFileName, (DWORD)wcslen(sFileName) * 2);
				}
				else
				{
					RegDeleteValue(pKey, szAppName);
				}
				ret = TRUE;
			}
			else
			{
				WCHAR nFileName[MAX_PATH];
				DWORD cbData = MAX_PATH * sizeof WCHAR;
				DWORD dType = REG_SZ;
				if (RegQueryValueEx(pKey, szAppName, NULL, &dType, (LPBYTE)nFileName, &cbData) == ERROR_SUCCESS)
				{
					if (wcscmp(sFileName, nFileName) == 0)
						ret = TRUE;
					else
						ret = FALSE;
				}
			}
			RegCloseKey(pKey);
		}
	}
	return ret;
}
INT_PTR CALLBACK ColorButtonProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)//颜色按钮控件右键处理
{
	switch (message)
	{
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		RECT rc;
		GetClientRect(hWnd, &rc);
		HBRUSH hb;
		int id = GetDlgCtrlID(hWnd);
		if (id >= IDC_BUTTON_COLOR_BACKGROUND && id <= IDC_BUTTON_COLOR_HIGH)
		{
			hb= CreateSolidBrush(TraySave.cMonitorColor[id-IDC_BUTTON_COLOR_BACKGROUND]);
		}
		else
			hb = CreateSolidBrush(TraySave.dAlphaColor[iProject]&0xffffff);
		FillRect(hdc, &rc, hb);
		DeleteObject(hb);
		EndPaint(hWnd, &ps);
		return TRUE;
	}
	}
	return CallWindowProc(oldColorButtonPoroc, hWnd, message, wParam, lParam);
}
BOOL EnableDebugPrivilege(BOOL bEnableDebugPrivilege)//DEBUG提权
{
	HANDLE hToken;
	TOKEN_PRIVILEGES tp;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		if (LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tp.Privileges[0].Luid))
		{
			tp.PrivilegeCount = 1;
			if (bEnableDebugPrivilege)
				tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			else
				tp.Privileges[0].Attributes = 0;
			if (AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL))
			{
				::CloseHandle(hToken);
				return TRUE;
			}
		}
		CloseHandle(hToken);
	}
	return FALSE;
}
/*
int DrawShadowText(HDC hDC, LPCTSTR lpString,int nCount, LPRECT lpRect, UINT uFormat)
{
	COLORREF cColor = GetTextColor(hDC);
	return DrawShadowText(hDC, lpString, nCount, lpRect, uFormat, cColor, RGB(0, 0, 0), 1, 1);
//	return DrawText(hDC, lpString,nCount, lpRect, uFormat);
}
*/